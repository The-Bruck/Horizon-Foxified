#!/usr/bin/env python3
"""Builds one copy-paste-able error report from build logs.
usage: make_error_report.py <logs_dir> <out_file> <step=outcome> ..."""
import os, re, subprocess, sys, glob

MAX_CHARS = 14000
PATTERNS = [
    (re.compile(r"^e: "), 4),                       # Kotlin compiler error
    (re.compile(r"^error(\[E\d+\])?:"), 8),         # rustc / cargo
    (re.compile(r"^\s*-->\s"), 0),
    (re.compile(r"panicked at"), 4),
    (re.compile(r"^test .* FAILED"), 0),
    (re.compile(r"^FAILURE:"), 6),
    (re.compile(r"What went wrong"), 6),
    (re.compile(r"Execution failed for task"), 4),
    (re.compile(r"^> Task .* FAILED"), 0),
    (re.compile(r"(?i)could not (resolve|find|determine)"), 3),
    (re.compile(r"(?i)(SDK|NDK) .*(not found|missing|not set)"), 2),
    (re.compile(r"(?i)linker .* not found|cannot find -l|ld: error"), 3),
    (re.compile(r"(?i)^error: no such command"), 2),
    (re.compile(r"No android/ \+ rust-core"), 0),
]

def extract(lines):
    keep = set()
    for i, l in enumerate(lines):
        for pat, ctx in PATTERNS:
            if pat.search(l):
                keep.update(range(max(0, i - 1), min(len(lines), i + ctx + 1)))
                break
    out, prev = [], -2
    for i in sorted(keep):
        if i != prev + 1 and out:
            out.append("   ...")
        out.append(lines[i].rstrip())
        prev = i
    return out

def sh(cmd):
    try:
        return subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=20).stdout.strip().splitlines()[0]
    except Exception:
        return "unavailable"

def main():
    logs, outp, outcomes = sys.argv[1], sys.argv[2], dict(a.split("=", 1) for a in sys.argv[3:])
    failed = [s for s, o in outcomes.items() if o not in ("success", "skipped")]
    rep = ["HMC BUILD ERROR REPORT", "=" * 22,
           "step outcomes: " + ", ".join(f"{s}={o}" for s, o in outcomes.items()),
           f"rustc: {sh('rustc --version')} | java: {sh('java -version 2>&1')} | ndk: {os.environ.get('ANDROID_NDK_HOME', 'unset')}",
           f"commit: {os.environ.get('GITHUB_SHA', '?')[:10]}", ""]
    if not failed:
        rep.append("No failed steps.")
    for step in failed:
        path = os.path.join(logs, f"{step}.log")
        rep.append(f"----- FAILED STEP: {step} -----")
        if not os.path.exists(path):
            rep += ["(no log captured: the step failed before running its command)", ""]
            continue
        lines = open(path, errors="replace").read().splitlines()
        errs = extract(lines)
        if errs:
            rep.append("[extracted errors]")
            rep += errs[:160]
        rep.append("[last 25 lines of log]")
        rep += [l.rstrip() for l in lines[-25:]]
        rep.append("")
    text = "\n".join(rep)
    if len(text) > MAX_CHARS:
        text = text[:MAX_CHARS] + "\n... [truncated: full logs are in the build-logs artifact]"
    open(outp, "w").write(text + "\n")
    print(text)

main()
