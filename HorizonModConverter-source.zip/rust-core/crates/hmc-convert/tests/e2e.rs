use hmc_convert::project::Project;
use hmc_convert::validate::validate_hmod;
use hmc_convert::{analyze_path, convert, ConvertOptions, Control};
use hmc_core::{Class, HmcError, Jar, Limits};
use std::io::Write;
use std::path::PathBuf;

fn fixture() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../../tests/fixtures/ruby-1.0.0.jar")
}
fn tmpdir(n: &str) -> PathBuf {
    let d = std::env::temp_dir().join(format!("hmc-test-{n}-{}", std::process::id()));
    let _ = std::fs::remove_dir_all(&d);
    std::fs::create_dir_all(&d).unwrap();
    d
}

#[test]
fn analysis_of_real_class_files() {
    let a = analyze_path(&fixture(), Limits::default()).unwrap();
    assert_eq!(a.meta.mod_id, "ruby");
    assert_eq!(a.version.minecraft.as_deref(), Some("1.21.1"));
    assert!(a.version.supported, "{:?}", a.version);
    assert!(a.code.mod_entry_points.iter().any(|(c, v)| c.ends_with("RubyMod") && v == "ruby"));
    assert_eq!(a.code.event_handlers.len(), 2);
    // one handler maps to a real catalog hook, the other has none
    let stop = a.handler_mappings.iter().find(|h| h.method == "onStop").unwrap();
    assert_eq!(stop.event.hook.as_deref(), Some("server_stopping"));
    let foo = a.handler_mappings.iter().find(|h| h.method == "onFoo").unwrap();
    assert!(foo.event.hook.is_none());
    assert_eq!(a.code.mixin_classes.len(), 1);
    assert!(a.code.classes.get("com/example/ruby/MachineBlock").unwrap().iter().any(|(k, beh)| format!("{k:?}") == "Block" && *beh));
    assert!(a.code.classes.get("com/example/ruby/PlainBlock").unwrap().iter().all(|(_, beh)| !*beh));
    assert!(a.code.classes.contains_key("com/example/ruby/MachineEntity"));
    assert!(!a.code.networking_classes.is_empty());
    assert!(a.rejected_entries.iter().any(|r| r.contains("evil")));
}

#[test]
fn converts_and_validates() {
    let out = tmpdir("convert");
    let o = convert(&fixture(), &out, &ConvertOptions::default(), &Control::none()).unwrap();
    assert!(o.hmod_path.exists());
    let adapter = hmc_convert::adapter::adapter_for("26.3").unwrap();
    let v = validate_hmod(std::fs::File::open(&o.hmod_path).unwrap(), adapter.as_ref());
    assert!(v.ok(), "{:?}", v.errors);
    assert_eq!(v.blocks, 3);
    assert_eq!(v.items, 1);

    let mut jar = Jar::new(std::fs::File::open(&o.hmod_path).unwrap(), Limits::default()).unwrap();
    let names: Vec<String> = jar.entries.iter().map(|e| e.name.clone()).collect();
    let has = |n: &str| names.iter().any(|x| x == n);
    // carried
    assert!(has("assets/ruby/textures/item/ruby.png"));
    assert!(has("data/minecraft/tags/block/mineable/pickaxe.json"));
    assert!(has("data/c/tags/item/gems/ruby.json"));
    assert!(has("assets/ruby/licenses/license.txt"));
    // generated
    assert!(has("data/ruby/horizon/block/ruby_door.json"));
    assert!(has("data/ruby/horizon/item/ruby.json"));
    assert!(has("assets/ruby/items/ruby.json"));
    assert!(has("data/ruby/horizon/creative_tab/ruby.json"));
    // refused
    assert!(!has("assets/ruby/textures/block/BadName.png"));
    assert!(!has("assets/ruby/textures/block/corrupt.png"));
    assert!(!has("data/ruby/recipe/machine_recipe.json"));
    assert!(!has("data/ruby/recipe/conditional.json"));
    assert!(!has("data/minecraft/recipe/override.json"));
    assert!(!has("data/neoforge/loot_modifiers/global_loot_modifiers.json"));
    assert!(!has("assets/ruby/shaders/x.fsh"));
    assert!(!names.iter().any(|n| n.contains("worldgen")), "worldgen must be opt-in");
    assert!(!names.iter().any(|n| n.contains("evil")));

    let door: serde_json::Value = serde_json::from_slice(&jar.read("data/ruby/horizon/block/ruby_door.json").unwrap()).unwrap();
    assert_eq!(door["template"], "minecraft:oak_door");
    let machine: serde_json::Value = serde_json::from_slice(&jar.read("data/ruby/horizon/block/machine.json").unwrap()).unwrap();
    assert_eq!(machine["state_properties"]["lit"]["type"], "boolean");
    let r: serde_json::Value = serde_json::from_slice(&jar.read("data/ruby/recipe/ruby_block.json").unwrap()).unwrap();
    assert_eq!(r["key"]["R"], "ruby:ruby");
    let m = jar.read_string("horizon-mod.toml").unwrap();
    assert!(m.contains("api = \"0.2\"") && m.contains("side = \"both\"") && m.contains("registries"), "{m}");

    // report is honest: manual/unsupported entries exist; no percentage
    let rep = &o.report;
    assert!(rep.count(Class::RequiresManualPorting) > 0 && rep.count(Class::Unsupported) > 0);
    assert!(rep.verdict().contains("limitations"));
    let md = rep.to_markdown();
    assert!(!md.contains('%'));
    assert!(md.contains("NOT run: Horizon's own loader"));
    assert!(md.contains("geolib"));
    // scaffold exists and is labelled as a stub
    let ev = std::fs::read_to_string(o.project_dir.join("native-port/src/events.rs")).unwrap();
    assert!(ev.contains("server_stopping") && ev.contains("STUB"));
    // project reload
    let p = Project::load(&o.project_dir).unwrap();
    assert_eq!(p.report.mod_id, "ruby");
}

#[test]
fn output_is_deterministic() {
    let (a, b) = (tmpdir("det-a"), tmpdir("det-b"));
    let x = convert(&fixture(), &a, &ConvertOptions::default(), &Control::none()).unwrap();
    let y = convert(&fixture(), &b, &ConvertOptions::default(), &Control::none()).unwrap();
    assert_eq!(std::fs::read(x.hmod_path).unwrap(), std::fs::read(y.hmod_path).unwrap());
}

#[test]
fn worldgen_opt_in_rewrites_block_states() {
    let out = tmpdir("wg");
    let o = ConvertOptions { carry_worldgen: true, ..Default::default() };
    let r = convert(&fixture(), &out, &o, &Control::none()).unwrap();
    let mut jar = Jar::new(std::fs::File::open(&r.hmod_path).unwrap(), Limits::default()).unwrap();
    let v: serde_json::Value = serde_json::from_slice(&jar.read("data/ruby/worldgen/configured_feature/ore.json").unwrap()).unwrap();
    assert_eq!(v["config"]["targets"][0]["state"]["id"], "ruby:ruby_block");
    assert!(r.report.findings.iter().any(|f| f.category == "worldgen" && f.class == Class::PartiallyConverted));
}

#[test]
fn cancellation_leaves_no_package() {
    use std::sync::atomic::AtomicBool;
    let out = tmpdir("cancel");
    let flag = AtomicBool::new(true);
    let ctl = Control { cancel: Some(&flag), progress: None };
    assert!(convert(&fixture(), &out, &ConvertOptions::default(), &ctl).is_err());
    assert!(!out.join("ruby/ruby.hmod").exists());
}

#[test]
fn refuses_non_neoforge_and_unsupported_versions() {
    let dir = tmpdir("refuse");
    let mk = |name: &str, files: &[(&str, &str)]| {
        let p = dir.join(name);
        let mut w = zip::ZipWriter::new(std::fs::File::create(&p).unwrap());
        for (n, d) in files {
            w.start_file(*n, zip::write::FileOptions::default()).unwrap();
            w.write_all(d.as_bytes()).unwrap();
        }
        w.finish().unwrap();
        p
    };
    let fabric = mk("f.jar", &[("fabric.mod.json", r#"{"id":"fab","version":"1"}"#)]);
    assert!(matches!(convert(&fabric, &dir.join("o"), &ConvertOptions::default(), &Control::none()), Err(HmcError::Unsupported(_))));
    let old = mk("o.jar", &[("META-INF/neoforge.mods.toml", "[[mods]]\nmodId=\"old\"\n[[dependencies.old]]\nmodId=\"minecraft\"\nversionRange=\"[1.20.4]\"\n")]);
    let e = convert(&old, &dir.join("o"), &ConvertOptions::default(), &Control::none()).unwrap_err();
    assert!(e.to_string().contains("not supported"), "{e}");
    let junk = dir.join("junk.jar");
    std::fs::write(&junk, b"not a zip").unwrap();
    assert!(convert(&junk, &dir.join("o"), &ConvertOptions::default(), &Control::none()).is_err());
}

/// Authoritative check: runs Horizon's own `cargo-horizon-mod check` when HORIZON_MOD_CHECK
/// points at a built binary (CI builds it from horizon-rust/horizon). Skipped otherwise.
#[test]
fn horizon_authoritative_check() {
    let Ok(bin) = std::env::var("HORIZON_MOD_CHECK") else {
        eprintln!("HORIZON_MOD_CHECK not set: authoritative check skipped");
        return;
    };
    for wg in [false, true] {
        let out = tmpdir(if wg { "auth-wg" } else { "auth" });
        let o = ConvertOptions { carry_worldgen: wg, ..Default::default() };
        let r = convert(&fixture(), &out, &o, &Control::none()).unwrap();
        let res = std::process::Command::new(&bin).arg("check").arg(&r.hmod_path).output().unwrap();
        assert!(res.status.success(), "{}", String::from_utf8_lossy(&res.stderr));
    }
}

/// The generated scaffold must at least be syntactically valid Rust.
#[test]
fn scaffold_is_valid_rust_syntax() {
    let out = tmpdir("scaffold");
    let o = convert(&fixture(), &out, &ConvertOptions::default(), &Control::none()).unwrap();
    let lib = o.project_dir.join("native-port/src/lib.rs");
    let Ok(st) = std::process::Command::new("rustc")
        .args(["--edition", "2021", "--crate-type", "lib", "--emit=metadata", "-A", "warnings", "-o"])
        .arg(out.join("scaffold.rmeta"))
        .arg(&lib)
        .output()
    else {
        eprintln!("rustc not found: skipped");
        return;
    };
    assert!(st.status.success(), "{}", String::from_utf8_lossy(&st.stderr));
}
