//! Target version adapters: everything specific to one Horizon release lives behind this trait.
use crate::rules::{MigrationRule, RULES_1_21_1_TO_HORIZON_26_3};

pub trait TargetAdapter: Send + Sync {
    fn id(&self) -> &'static str;
    fn display_name(&self) -> &'static str;
    /// Value of `api` in `horizon-mod.toml` for content mods.
    fn manifest_api(&self) -> &'static str;
    fn game_version(&self) -> &'static str;
    /// Source Minecraft versions this adapter has migration rules for.
    fn supported_sources(&self) -> &'static [&'static str];
    fn rules(&self) -> &'static [MigrationRule];
    /// Vanilla templates this adapter may emit in declarations.
    fn emitted_templates(&self) -> &'static [&'static str];
}

pub struct Horizon26_3;

impl TargetAdapter for Horizon26_3 {
    fn id(&self) -> &'static str {
        "horizon-26.3"
    }
    fn display_name(&self) -> &'static str {
        "Horizon 26.3 (content mods API 0.2)"
    }
    fn manifest_api(&self) -> &'static str {
        "0.2"
    }
    fn game_version(&self) -> &'static str {
        "26.3"
    }
    fn supported_sources(&self) -> &'static [&'static str] {
        &["1.21.1"]
    }
    fn rules(&self) -> &'static [MigrationRule] {
        RULES_1_21_1_TO_HORIZON_26_3
    }
    fn emitted_templates(&self) -> &'static [&'static str] {
        &[
            "minecraft:stone", "minecraft:oak_door", "minecraft:oak_trapdoor", "minecraft:stone_stairs",
            "minecraft:stone_slab", "minecraft:oak_log", "minecraft:oak_fence", "minecraft:cobblestone_wall",
            "minecraft:oak_fence_gate", "minecraft:stone_button", "minecraft:stone_pressure_plate",
            "minecraft:wheat", "minecraft:beetroots", "minecraft:glass_pane", "minecraft:diamond",
        ]
    }
}

pub fn adapter_for(target: &str) -> Option<Box<dyn TargetAdapter>> {
    match target {
        "26.3" | "horizon-26.3" => Some(Box::new(Horizon26_3)),
        _ => None,
    }
}

pub fn available_targets() -> Vec<&'static str> {
    vec!["horizon-26.3"]
}
