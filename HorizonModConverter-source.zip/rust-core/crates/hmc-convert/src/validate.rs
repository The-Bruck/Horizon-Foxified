//! Validation of a produced `.hmod` against the rules documented in Horizon's
//! docs/api/mod-files.md and docs/mods.md. This is HMC's own check: it mirrors the
//! documented rules but is NOT Horizon's loader. Run `cargo horizon-mod check` for the
//! authoritative result.
use crate::adapter::TargetAdapter;
use hmc_core::path::{is_resource_char, valid_mod_id};
use hmc_core::{Jar, Limits};
use serde::Serialize;
use serde_json::Value;
use std::collections::BTreeSet;
use std::io::{Read, Seek};

#[derive(Debug, Default, Serialize)]
pub struct ValidationResult {
    pub errors: Vec<String>,
    pub warnings: Vec<String>,
    pub checks: Vec<String>,
    pub files: usize,
    pub blocks: usize,
    pub items: usize,
}

impl ValidationResult {
    pub fn ok(&self) -> bool {
        self.errors.is_empty()
    }
}

const MANIFEST_KEYS: &[&str] =
    &["id", "name", "version", "description", "authors", "api", "side", "capabilities", "namespaces", "experimental"];
const BLOCK_KEYS: &[&str] = &[
    "template", "properties", "shapes", "collision_shapes", "state_properties", "default_state", "item", "components",
    "connects_to", "thickness", "wood_type", "wall_block",
];
const ITEM_KEYS: &[&str] = &["template", "max_stack_size", "rarity", "components", "crafting_remainder"];
const PROP_KEYS: &[&str] =
    &["hardness", "explosion_resistance", "light", "requires_tool", "friction", "map_color", "sounds", "random_ticks", "render_shape", "occludes"];

fn content_path_ok(path: &str) -> bool {
    // `assets/` or `data/`, then at least two parts of [a-z0-9_.-]
    let parts: Vec<&str> = path.split('/').collect();
    parts.len() >= 3
        && (parts[0] == "assets" || parts[0] == "data")
        && parts[1..].iter().all(|p| !p.is_empty() && p.bytes().all(is_resource_char))
}

fn template_ok(t: &str) -> bool {
    t.strip_prefix("minecraft:").is_some_and(|p| {
        !p.is_empty() && p.bytes().all(|b| b.is_ascii_lowercase() || b.is_ascii_digit() || b"_./-".contains(&b))
    })
}

pub fn validate_hmod<R: Read + Seek>(reader: R, adapter: &dyn TargetAdapter) -> ValidationResult {
    let mut r = ValidationResult::default();
    let mut jar = match Jar::new(reader, Limits::default()) {
        Ok(j) => j,
        Err(e) => {
            r.errors.push(format!("package cannot be read: {e}"));
            return r;
        }
    };
    r.checks.push("zip readable; entry names relative, '/'-separated, no '..' or ':'; size, count and ratio limits".into());
    if !jar.rejected.is_empty() {
        r.errors.push(format!("entries rejected by the archive reader: {:?}", jar.rejected));
    }
    r.files = jar.entries.len();

    // Manifest
    let manifest = match jar.read_string("horizon-mod.toml") {
        Ok(s) => s,
        Err(e) => {
            r.errors.push(format!("horizon-mod.toml: {e}"));
            return r;
        }
    };
    let m: toml::Value = match manifest.parse() {
        Ok(v) => v,
        Err(e) => {
            r.errors.push(format!("horizon-mod.toml does not parse: {e}"));
            return r;
        }
    };
    let tbl = m.as_table().cloned().unwrap_or_default();
    for k in tbl.keys() {
        if !MANIFEST_KEYS.contains(&k.as_str()) {
            r.errors.push(format!("horizon-mod.toml: unknown key {k:?} (Horizon refuses unknown keys)"));
        }
    }
    let id = tbl.get("id").and_then(|v| v.as_str()).unwrap_or("").to_string();
    if !valid_mod_id(&id) {
        r.errors.push(format!("manifest id {id:?} does not match [a-z0-9_]{{1,64}}"));
    }
    for k in ["name", "version"] {
        if tbl.get(k).and_then(|v| v.as_str()).map_or(true, |s| s.is_empty()) {
            r.errors.push(format!("manifest {k} missing or empty"));
        }
    }
    if tbl.get("api").and_then(|v| v.as_str()) != Some(adapter.manifest_api()) {
        r.errors.push(format!("manifest api must be {:?} for {}", adapter.manifest_api(), adapter.display_name()));
    }
    let caps: Vec<&str> =
        tbl.get("capabilities").and_then(|c| c.as_array()).map(|a| a.iter().filter_map(|x| x.as_str()).collect()).unwrap_or_default();
    if !caps.contains(&"registries") {
        r.errors.push("manifest must list capability \"registries\" (cargo horizon-mod build refuses otherwise)".into());
    }
    if tbl.get("side").and_then(|v| v.as_str()) != Some("both") {
        r.warnings.push("manifest side is not \"both\": a client-only mod is never compared with a server".into());
    }
    let mut namespaces: BTreeSet<String> = BTreeSet::new();
    namespaces.insert(id.clone());
    if let Some(a) = tbl.get("namespaces").and_then(|v| v.as_array()) {
        for n in a.iter().filter_map(|x| x.as_str()) {
            if matches!(n, "minecraft" | "c" | "horizon") {
                r.errors.push(format!("namespace {n:?} cannot be listed"));
            }
            namespaces.insert(n.to_string());
        }
    }
    r.checks.push("manifest: parsed, no unknown keys, id pattern, api, capability registries, namespaces".into());

    // Entries
    let names: Vec<String> = jar.entries.iter().map(|e| e.name.clone()).collect();
    let nameset: BTreeSet<&str> = names.iter().map(|s| s.as_str()).collect();
    let mut total: u64 = 0;
    for e in &jar.entries {
        total += e.size;
    }
    if total > 512 * 1024 * 1024 {
        r.errors.push("content exceeds 512 MiB".into());
    }
    let mut blocks = BTreeSet::new();
    let mut items = BTreeSet::new();
    for name in &names {
        if name == "horizon-mod.toml" {
            continue;
        }
        if !(name.starts_with("assets/") || name.starts_with("data/")) {
            r.errors.push(format!("{name}: top-level entry other than horizon-mod.toml, assets/, data/"));
            continue;
        }
        if !content_path_ok(name) {
            r.errors.push(format!("{name}: path not of the form assets|data/<part>/<part>... with [a-z0-9_.-] parts"));
            continue;
        }
        let parts: Vec<&str> = name.split('/').collect();
        let (root, ns) = (parts[0], parts[1]);
        let allowed = namespaces.contains(ns)
            || (root == "data" && (ns == "minecraft" || ns == "c") && parts.get(2) == Some(&"tags"))
            || (root == "assets" && ns == "minecraft" && parts.get(2) == Some(&"atlases"));
        if !allowed {
            r.errors.push(format!("{name}: outside the mod's namespaces {:?}", namespaces));
            continue;
        }
        if name.ends_with(".json") || name.ends_with(".mcmeta") {
            let text = match jar.read_string(name) {
                Ok(t) => t,
                Err(e) => {
                    r.errors.push(format!("{name}: {e}"));
                    continue;
                }
            };
            let v: Value = match serde_json::from_str(&text) {
                Ok(v) => v,
                Err(e) => {
                    r.errors.push(format!("{name}: invalid JSON: {e}"));
                    continue;
                }
            };
            // declarations
            let decl = |kind: &str| -> Option<String> {
                let pre = format!("data/{id}/horizon/{kind}/");
                name.strip_prefix(&pre).and_then(|n| n.strip_suffix(".json")).map(String::from)
            };
            if let Some(b) = decl("block") {
                check_decl(&mut r, name, &v, BLOCK_KEYS, adapter);
                if let Some(p) = v.get("properties").and_then(|p| p.as_object()) {
                    for k in p.keys() {
                        if !PROP_KEYS.contains(&k.as_str()) {
                            r.errors.push(format!("{name}: unknown block property {k:?}"));
                        }
                    }
                }
                if let Some(sp) = v.get("state_properties").and_then(|p| p.as_object()) {
                    let mut states: u64 = 1;
                    for (k, d) in sp {
                        let ident = |s: &str| !s.is_empty() && s.bytes().all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == b'_');
                        if !ident(k) {
                            r.errors.push(format!("{name}: state property name {k:?} invalid"));
                        }
                        match d.get("type").and_then(|t| t.as_str()) {
                            Some("boolean") => states = states.saturating_mul(2),
                            Some("enum") => {
                                let vals = d.get("values").and_then(|v| v.as_array()).cloned().unwrap_or_default();
                                if vals.is_empty() || vals.iter().any(|x| x.as_str().map_or(true, |s| !ident(s))) {
                                    r.errors.push(format!("{name}: enum property {k:?} has invalid values"));
                                }
                                states = states.saturating_mul(vals.len().max(1) as u64);
                            }
                            _ => r.errors.push(format!("{name}: state property {k:?} has no valid type")),
                        }
                    }
                    if states > (1 << 20) {
                        r.errors.push(format!("{name}: {states} declared state combinations exceed 2^20"));
                    }
                }
                blocks.insert(b);
            } else if let Some(i) = decl("item") {
                check_decl(&mut r, name, &v, ITEM_KEYS, adapter);
                items.insert(i);
            } else if let Some(t) = name.strip_prefix(&format!("data/{id}/horizon/creative_tab/")) {
                let ok = v.get("title").is_some_and(|x| x.is_string())
                    && v.get("icon").is_some_and(|x| x.is_string())
                    && v.get("items").is_some_and(|x| x.is_array());
                if !ok || v.as_object().map_or(true, |o| o.len() != 3) {
                    r.errors.push(format!("{name}: creative tab needs exactly title, icon, items ({t})"));
                }
            }
            // recipes: 26.3 shapes
            if let Some(rest) = name.strip_prefix(&format!("data/{ns}/recipe/")) {
                if v.get("type").and_then(|t| t.as_str()).is_none() {
                    r.errors.push(format!("{name}: recipe without type ({rest})"));
                }
                check_no_legacy_ingredients(&mut r, name, &v);
            }
        }
    }
    r.checks.push("every path: content form, resource characters, namespace fence (own namespaces, data/{minecraft,c}/tags, assets/minecraft/atlases)".into());
    r.checks.push("every .json/.mcmeta parses; block/item/creative-tab declarations use only keys Horizon accepts; state property rules and 2^20 state limit".into());
    r.checks.push("recipes: no legacy {item}/{tag} ingredient objects remain".into());

    // Every declared block should bind a blockstate.
    for b in &blocks {
        if !nameset.contains(format!("assets/{id}/blockstates/{b}.json").as_str()) {
            r.warnings.push(format!("block {b}: no assets/{id}/blockstates/{b}.json (it would draw as the missing model)"));
        }
    }
    r.blocks = blocks.len();
    r.items = items.len();
    r
}

fn check_decl(r: &mut ValidationResult, name: &str, v: &Value, keys: &[&str], adapter: &dyn TargetAdapter) {
    let Some(o) = v.as_object() else {
        r.errors.push(format!("{name}: declaration is not an object"));
        return;
    };
    for k in o.keys() {
        if !keys.contains(&k.as_str()) {
            r.errors.push(format!("{name}: unknown key {k:?}"));
        }
    }
    match o.get("template").and_then(|t| t.as_str()) {
        Some(t) if template_ok(t) => {
            if !adapter.emitted_templates().contains(&t) {
                r.warnings.push(format!("{name}: template {t} was not generated by HMC; existence in Horizon's vanilla tables is not verified here"));
            }
        }
        _ => r.errors.push(format!("{name}: template missing or not a minecraft: id")),
    }
}

fn check_no_legacy_ingredients(r: &mut ValidationResult, name: &str, v: &Value) {
    fn legacy(v: &Value) -> bool {
        match v {
            Value::Object(o) => o.get("item").is_some_and(|x| x.is_string()) && o.len() == 1 || o.values().any(legacy),
            Value::Array(a) => a.iter().any(legacy),
            _ => false,
        }
    }
    // The only legit {"item": ..} shapes are inside results (renamed to id) so none should remain.
    if legacy(v) {
        r.errors.push(format!("{name}: contains a legacy {{\"item\": ..}} object"));
    }
}
