//! The conversion pipeline: NeoForge JAR -> Horizon `.hmod` (+ report, project, scaffold).
use crate::adapter::{adapter_for, TargetAdapter};
use crate::analysis::{analyze_jar, categorize, Analysis};
use crate::gameplay::*;
use crate::project::Project;
use crate::rustgen::{self, DeclaredContent};
use crate::validate::validate_hmod;
use hmc_bytecode::FeatureClass;
use hmc_core::path::is_resource_char;
use hmc_core::{Class, Finding, HmcError, Jar, Limits, Report, Result};
use hmc_meta::{DepKind, Loader};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::collections::{BTreeMap, BTreeSet};
use std::fs::File;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::Instant;

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(default)]
pub struct ConvertOptions {
    pub target: String,
    /// Convert even when source version detection is unsupported or conflicting.
    pub override_source: bool,
    /// Carry worldgen/structure data (block-state rewrite only; unvalidated).
    pub carry_worldgen: bool,
    pub generate_creative_tab: bool,
    pub write_native_scaffold: bool,
    pub limits: Limits,
}

impl Default for ConvertOptions {
    fn default() -> Self {
        ConvertOptions {
            target: "horizon-26.3".into(),
            override_source: false,
            carry_worldgen: false,
            generate_creative_tab: true,
            write_native_scaffold: true,
            limits: Limits::default(),
        }
    }
}

#[derive(Clone, Debug)]
pub struct Progress {
    pub stage: String,
    pub done: u64,
    pub total: u64,
}

#[derive(Default)]
pub struct Control<'a> {
    pub cancel: Option<&'a AtomicBool>,
    pub progress: Option<&'a (dyn Fn(Progress) + Sync)>,
}

impl<'a> Control<'a> {
    pub fn none() -> Control<'static> {
        Control { cancel: None, progress: None }
    }
    fn cancelled(&self) -> bool {
        self.cancel.is_some_and(|c| c.load(Ordering::Relaxed))
    }
    fn tick(&self, stage: &str, done: u64, total: u64) {
        if let Some(p) = self.progress {
            p(Progress { stage: stage.into(), done, total });
        }
    }
}

#[derive(Debug)]
pub struct ConvertOutcome {
    pub hmod_path: PathBuf,
    pub project_dir: PathBuf,
    pub report: Report,
}

#[derive(Serialize)]
struct HManifest<'a> {
    id: &'a str,
    name: &'a str,
    version: &'a str,
    description: &'a str,
    authors: &'a [String],
    api: &'a str,
    side: &'a str,
    capabilities: &'a [&'a str],
    #[serde(skip_serializing_if = "<[String]>::is_empty")]
    namespaces: &'a [String],
}

/// Aggregates many similar per-file events into one finding each.
#[derive(Default)]
struct Agg(Vec<(String, Class, String, u64, Vec<String>)>);
impl Agg {
    fn add(&mut self, cat: &str, class: Class, reason: impl Into<String>, example: &str) {
        let reason = reason.into();
        if let Some(e) = self.0.iter_mut().find(|e| e.0 == cat && e.1 == class && e.2 == reason) {
            e.3 += 1;
            if e.4.len() < 3 {
                e.4.push(example.to_string());
            }
        } else {
            self.0.push((cat.into(), class, reason, 1, vec![example.to_string()]));
        }
    }
    fn into_findings(self) -> Vec<Finding> {
        self.0
            .into_iter()
            .map(|(cat, class, reason, n, ex)| Finding::new(&cat, reason, class, format!("{n} file(s), e.g. {}", ex.join(", "))))
            .collect()
    }
}

fn peak_rss_kb() -> Option<u64> {
    let s = std::fs::read_to_string("/proc/self/status").ok()?;
    s.lines().find(|l| l.starts_with("VmHWM:"))?.split_whitespace().nth(1)?.parse().ok()
}

pub fn sha256_file(p: &Path) -> Result<String> {
    use std::io::Read;
    let mut f = File::open(p)?;
    let mut h = Sha256::new();
    let mut buf = [0u8; 64 * 1024];
    loop {
        let n = f.read(&mut buf)?;
        if n == 0 {
            break;
        }
        h.update(&buf[..n]);
    }
    Ok(h.finalize().iter().map(|b| format!("{b:02x}")).collect())
}

fn put<W: Write + std::io::Seek>(w: &mut zip::ZipWriter<W>, name: &str, data: &[u8]) -> Result<()> {
    let o = zip::write::FileOptions::default()
        .compression_method(zip::CompressionMethod::Deflated)
        .last_modified_time(zip::DateTime::default())
        .unix_permissions(0o644);
    w.start_file(name, o)?;
    w.write_all(data)?;
    Ok(())
}

fn stem<'a>(name: &'a str, prefix: &str) -> Option<&'a str> {
    name.strip_prefix(prefix).and_then(|n| n.strip_suffix(".json")).filter(|n| !n.contains('/'))
}

pub fn convert(src: &Path, out_root: &Path, opts: &ConvertOptions, ctl: &Control) -> Result<ConvertOutcome> {
    let t_total = Instant::now();
    let adapter: Box<dyn TargetAdapter> =
        adapter_for(&opts.target).ok_or_else(|| HmcError::Unsupported(format!("unknown target {:?}", opts.target)))?;

    ctl.tick("analyze", 0, 1);
    let size = std::fs::metadata(src)?.len();
    let mut jar = Jar::open(src, opts.limits.clone())?;
    let file_name = src.file_name().map(|s| s.to_string_lossy().into_owned()).unwrap_or_default();
    let analysis = analyze_jar(&mut jar, &file_name, size)?;
    if ctl.cancelled() {
        return Err(HmcError::Unsupported("cancelled".into()));
    }

    if analysis.meta.loader != Loader::NeoForge {
        return Err(HmcError::Unsupported(format!(
            "source loader is {:?}; only NeoForge sources are supported",
            analysis.meta.loader
        )));
    }
    if !analysis.version.supported && !opts.override_source {
        return Err(HmcError::Unsupported(format!(
            "source version not supported or ambiguous (minecraft {:?}, conflicts {:?}); supported: {:?}. Use override_source to force.",
            analysis.version.minecraft, analysis.version.conflicts, adapter.supported_sources()
        )));
    }
    let id = analysis.meta.mod_id.clone();
    if !hmc_core::path::valid_mod_id(&id) {
        return Err(HmcError::Unsupported(format!("mod id {id:?} does not match Horizon's [a-z0-9_]{{1,64}}")));
    }

    let own: BTreeSet<String> = analysis.own_namespaces().into_iter().collect();
    let extra_ns: Vec<String> = own.iter().filter(|n| **n != id).cloned().collect();

    let proj_dir = out_root.join(&id);
    std::fs::create_dir_all(&proj_dir)?;
    let hmod_final = proj_dir.join(format!("{id}.hmod"));
    let hmod_tmp = proj_dir.join(format!("{id}.hmod.tmp"));

    let mut report = Report {
        mod_name: analysis.meta.display_name.clone(),
        mod_id: id.clone(),
        source: format!(
            "{:?} Minecraft {} (NeoForge {})",
            analysis.meta.loader,
            analysis.version.minecraft.clone().unwrap_or_else(|| "unknown".into()),
            analysis.version.neoforge.clone().unwrap_or_else(|| "unknown".into())
        ),
        target: adapter.display_name().to_string(),
        ..Default::default()
    };
    for c in &analysis.version.conflicts {
        report.warnings.push(format!("version indicators disagree: {c}"));
    }
    for n in &analysis.version.notes {
        report.warnings.push(n.clone());
    }
    for r in &analysis.rejected_entries {
        report.warnings.push(format!("archive entry rejected: {r}"));
    }

    // ------------------------------------------------------------ carry pass
    let t_carry = Instant::now();
    let mut zipw = zip::ZipWriter::new(File::create(&hmod_tmp)?);
    let mut names: Vec<String> = jar.entries.iter().map(|e| e.name.clone()).collect();
    names.sort();
    let total = names.len() as u64;
    let mut agg = Agg::default();
    let mut carried: BTreeMap<&'static str, u64> = BTreeMap::new();
    let mut upgraded_recipes = 0u64;
    let mut state_rewrites = 0u64;
    let mut blockstates: BTreeMap<String, Value> = BTreeMap::new();
    let mut item_models: BTreeMap<String, Value> = BTreeMap::new();
    let mut item_defs: BTreeSet<String> = BTreeSet::new();
    let mut secondary_blockstates = 0u64;
    let mut written: BTreeSet<String> = BTreeSet::new();

    for (i, name) in names.iter().enumerate() {
        if ctl.cancelled() {
            drop(zipw);
            let _ = std::fs::remove_file(&hmod_tmp);
            return Err(HmcError::Unsupported("cancelled".into()));
        }
        if i % 64 == 0 {
            ctl.tick("carry", i as u64, total);
        }
        let Some((cat, ns)) = categorize(name) else {
            let upper = name.to_ascii_uppercase();
            if !name.contains('/')
                && ["LICENSE", "LICENCE", "COPYING", "NOTICE"].iter().any(|p| upper.starts_with(p))
            {
                if let Ok(b) = jar.read_limited(name, 1024 * 1024) {
                    let safe: String = name.to_ascii_lowercase().chars().map(|c| if is_resource_char(c as u8) && c.is_ascii() { c } else { '_' }).collect();
                    let dest = format!("assets/{id}/licenses/{safe}.txt");
                    put(&mut zipw, &dest, &b)?;
                    written.insert(dest);
                    *carried.entry("license_files").or_default() += 1;
                }
            }
            continue;
        };
        let rest = name.splitn(3, '/').nth(2).unwrap_or("");
        let root = name.split('/').next().unwrap_or("");

        let allowed = match (root, ns) {
            ("data", "minecraft") | ("data", "c") => rest.starts_with("tags/"),
            ("assets", "minecraft") => rest.starts_with("atlases/"),
            _ => own.contains(ns),
        };
        if !allowed {
            let why = if ns == "minecraft" {
                "overrides a vanilla file (Horizon allows only tags and atlases there)".to_string()
            } else {
                format!("namespace `{ns}` is not one of the mod's own namespaces")
            };
            agg.add("namespaces", Class::Unsupported, why, name);
            continue;
        }
        if !name.bytes().all(|b| is_resource_char(b) || b == b'/') {
            agg.add("assets", Class::Unsupported, "file name outside Horizon's resource characters [a-z0-9_.-]", name);
            continue;
        }

        let bytes = match jar.read(name) {
            Ok(b) => b,
            Err(e) => {
                agg.add(cat, Class::Unsupported, format!("unreadable: {e}"), name);
                continue;
            }
        };
        let is_json = name.ends_with(".json") || name.ends_with(".mcmeta");
        let mut out: Option<Vec<u8>> = None;

        match cat {
            "shaders" => {
                agg.add(cat, Class::Unsupported, "shader files: Horizon uses its own .hshader packs", name);
                continue;
            }
            "legacy_plural_recipes" | "legacy_plural_loot_tables" => {
                agg.add(cat, Class::Unsupported, "pre-1.21 plural folder name, not read by a 1.21+ game", name);
                continue;
            }
            "neoforge_data" if !rest.starts_with("neoforge/biome_modifier/") => {
                agg.add(cat, Class::Unsupported, "NeoForge-specific data (loot modifiers, data maps, ...) has no Horizon equivalent", name);
                continue;
            }
            "worldgen" | "structures" | "neoforge_data" if !opts.carry_worldgen => {
                agg.add(cat, Class::RequiresManualPorting, "worldgen/structure data not carried (opt in with carry_worldgen; unvalidated)", name);
                continue;
            }
            _ => {}
        }

        if name.ends_with(".png") {
            if let Err(e) = crate::png::validate_png(&bytes) {
                agg.add("textures", Class::Unsupported, format!("invalid PNG ({e})"), name);
                continue;
            }
        } else if name.ends_with(".ogg") && !bytes.starts_with(b"OggS") {
            agg.add("sounds", Class::Unsupported, "not an Ogg file", name);
            continue;
        }

        if is_json {
            let mut v: Value = match serde_json::from_slice(&bytes) {
                Ok(v) => v,
                Err(e) => {
                    agg.add(cat, Class::Unsupported, format!("invalid JSON ({e})"), name);
                    continue;
                }
            };
            if root == "data" && uses_loader_types(&v) {
                agg.add(cat, Class::Unsupported, "uses neoforge:/forge: types or conditions that Horizon cannot evaluate", name);
                continue;
            }
            match cat {
                "recipes" => match upgrade_recipe(&v) {
                    Ok(n) => {
                        upgraded_recipes += 1;
                        out = Some(serde_json::to_vec_pretty(&n).unwrap());
                    }
                    Err(why) => {
                        agg.add("recipes", Class::Unsupported, format!("recipe skipped: {why}"), name);
                        continue;
                    }
                },
                "worldgen" | "structures" | "neoforge_data" => {
                    state_rewrites += rewrite_block_states(&mut v);
                    out = Some(serde_json::to_vec_pretty(&v).unwrap());
                    agg.add(cat, Class::PartiallyConverted, "carried with block-state rewrite only; not validated against Horizon's worldgen loader", name);
                }
                "blockstates" => {
                    if ns == id {
                        if let Some(s) = stem(name, &format!("assets/{id}/blockstates/")) {
                            blockstates.insert(s.to_string(), v);
                        }
                    } else {
                        secondary_blockstates += 1;
                    }
                }
                "models" => {
                    if ns == id {
                        if let Some(s) = stem(name, &format!("assets/{id}/models/item/")) {
                            item_models.insert(s.to_string(), v);
                        }
                    }
                }
                "item_definitions" => {
                    if let Some(s) = stem(name, &format!("assets/{ns}/items/")) {
                        if ns == id {
                            item_defs.insert(s.to_string());
                        }
                    }
                }
                _ => {}
            }
        }
        let data = out.as_deref().unwrap_or(&bytes);
        put(&mut zipw, name, data)?;
        written.insert(name.clone());
        let key: &'static str = match cat {
            "textures" => "textures",
            "models" => "models",
            "blockstates" => "blockstates",
            "item_definitions" => "item_definitions",
            "lang" => "lang_files",
            "sounds" | "sound_definitions" => "sound_files",
            "particles" => "particles",
            "recipes" => "recipes",
            "loot_tables" => "loot_tables",
            "tags" => "tags",
            "advancements" => "advancements",
            "fonts" => "fonts",
            "atlases" => "atlases",
            _ => "other_files",
        };
        *carried.entry(key).or_default() += 1;
    }
    report.counters.insert("carry_ms".into(), t_carry.elapsed().as_millis() as u64);

    // ------------------------------------------------- registry declarations
    ctl.tick("declare", 0, 1);
    let t_gen = Instant::now();
    let mut declared = DeclaredContent { blocks: vec![], items: vec![] };
    let mut seen_in_code = 0u64;
    let mut tab_items: Vec<String> = Vec::new();
    let block_names: BTreeSet<String> = blockstates.keys().cloned().collect();

    for (name, bs) in &blockstates {
        match plan_block(name, bs, item_models.contains_key(name)) {
            Ok(p) => {
                let dest = format!("data/{id}/horizon/block/{name}.json");
                put(&mut zipw, &dest, &serde_json::to_vec_pretty(&p.json).unwrap())?;
                written.insert(dest);
                if analysis.code.strings.contains(name) {
                    seen_in_code += 1;
                }
                report.push(Finding::new("blocks", format!("{id}:{name}"), Class::PartiallyConverted, p.partial.join("; ")));
                if item_models.contains_key(name) {
                    tab_items.push(format!("{id}:{name}"));
                }
                declared.blocks.push((name.clone(), p.template));
            }
            Err(why) => {
                report.push(Finding::new("blocks", format!("{id}:{name}"), Class::Unsupported, format!("not declared: {why}")));
            }
        }
    }
    if secondary_blockstates > 0 {
        report.push(Finding::new(
            "blocks",
            "blocks in secondary namespaces",
            Class::RequiresManualPorting,
            format!("{secondary_blockstates} blockstate file(s) carried but not declared: Horizon declares blocks under the mod id `{id}` only"),
        ));
    }
    for (name, model) in &item_models {
        if !block_names.contains(name) {
            let (decl, notes) = plan_item(model);
            let dest = format!("data/{id}/horizon/item/{name}.json");
            put(&mut zipw, &dest, &serde_json::to_vec_pretty(&decl).unwrap())?;
            written.insert(dest);
            if analysis.code.strings.contains(name) {
                seen_in_code += 1;
            }
            report.push(Finding::new("items", format!("{id}:{name}"), Class::PartiallyConverted, notes.join("; ")));
            tab_items.push(format!("{id}:{name}"));
            declared.items.push(name.clone());
        }
        if !item_defs.contains(name) {
            let dest = format!("assets/{id}/items/{name}.json");
            if !written.contains(&dest) {
                put(&mut zipw, &dest, &serde_json::to_vec_pretty(&item_definition(&id, name)).unwrap())?;
                written.insert(dest);
                *carried.entry("item_definitions_generated").or_default() += 1;
            }
        }
    }
    if opts.generate_creative_tab && !tab_items.is_empty() {
        tab_items.sort();
        let tab = serde_json::json!({"title": analysis.meta.display_name, "icon": tab_items[0], "items": tab_items});
        let dest = format!("data/{id}/horizon/creative_tab/{id}.json");
        put(&mut zipw, &dest, &serde_json::to_vec_pretty(&tab).unwrap())?;
        report.push(Finding::new("items", "creative tab", Class::AutomaticallyConverted, "generated a creative tab listing the declared items (not present in the source mod)"));
    }

    // manifest
    let caps = ["registries"];
    let manifest = toml::to_string(&HManifest {
        id: &id,
        name: &analysis.meta.display_name,
        version: &analysis.meta.version,
        description: &analysis.meta.description,
        authors: &analysis.meta.authors,
        api: adapter.manifest_api(),
        side: "both",
        capabilities: &caps,
        namespaces: &extra_ns,
    })
    .map_err(|e| HmcError::Parse(e.to_string()))?;
    put(&mut zipw, "horizon-mod.toml", manifest.as_bytes())?;
    zipw.finish()?;
    report.counters.insert("generate_ms".into(), t_gen.elapsed().as_millis() as u64);

    // ------------------------------------------------------------ validation
    ctl.tick("validate", 0, 1);
    let t_val = Instant::now();
    let vres = validate_hmod(File::open(&hmod_tmp)?, adapter.as_ref());
    report.counters.insert("validate_ms".into(), t_val.elapsed().as_millis() as u64);
    if !vres.ok() {
        let _ = std::fs::remove_file(&hmod_tmp);
        return Err(HmcError::Validation(vres.errors));
    }
    std::fs::rename(&hmod_tmp, &hmod_final)?;
    report.validation = vres.checks.clone();
    report.validation.push("NOT run: Horizon's own loader or `cargo horizon-mod check`; run it before publishing".into());
    for w in &vres.warnings {
        report.warnings.push(w.clone());
    }

    // -------------------------------------------------------------- findings
    for (k, n) in &carried {
        report.bump(&format!("carried_{k}"), *n);
    }
    report.bump("recipes_upgraded", upgraded_recipes);
    report.bump("worldgen_block_states_rewritten", state_rewrites);
    report.bump("blocks_declared", declared.blocks.len() as u64);
    report.bump("items_declared", declared.items.len() as u64);
    report.bump("declared_names_seen_in_code_constants", seen_in_code);
    let mut cf = Vec::new();
    for (k, label, class, note) in [
        ("textures", "textures", Class::AutomaticallyConverted, "carried; PNG structure and CRCs verified"),
        ("models", "models", Class::AutomaticallyConverted, "carried unchanged; JSON parses (model geometry not re-validated)"),
        ("blockstates", "blockstates", Class::AutomaticallyConverted, "carried unchanged; JSON parses"),
        ("item_definitions_generated", "item definitions", Class::AutomaticallyConverted, "generated from item models (rule item-model-definitions)"),
        ("lang_files", "language files", Class::AutomaticallyConverted, "carried; JSON parses"),
        ("sound_files", "sounds", Class::AutomaticallyConverted, "carried; Ogg header checked"),
        ("particles", "particles", Class::AutomaticallyConverted, "carried; JSON parses"),
        ("loot_tables", "loot tables", Class::AutomaticallyConverted, "carried; JSON parses, no loader-specific types"),
        ("tags", "tags", Class::AutomaticallyConverted, "carried; JSON parses, no loader-specific types"),
        ("advancements", "advancements", Class::PartiallyConverted, "carried as-is; 26.3 advancement schema not verified"),
        ("fonts", "fonts", Class::PartiallyConverted, "carried as-is; not verified"),
        ("atlases", "atlases", Class::AutomaticallyConverted, "carried; JSON parses"),
        ("other_files", "other files", Class::PartiallyConverted, "carried as-is; not verified"),
        ("license_files", "license files", Class::AutomaticallyConverted, "kept under assets/<id>/licenses/"),
    ] {
        if let Some(n) = carried.get(k) {
            cf.push(Finding::new("assets", label, class, format!("{n} file(s) {note}")));
        }
    }
    if upgraded_recipes > 0 {
        cf.push(Finding::new("recipes", "recipes", Class::AutomaticallyConverted, format!("{upgraded_recipes} recipe(s) rewritten to the 26.3 ingredient/result shape (rules recipe-ingredient-strings, recipe-result-id)")));
    }
    for f in cf.into_iter().rev() {
        report.findings.insert(0, f);
    }
    report.findings.extend(agg.into_findings());
    code_findings(&analysis, &mut report);

    // scaffold
    if opts.write_native_scaffold {
        let needs = !analysis.handler_mappings.is_empty()
            || analysis.code.classes.values().flatten().any(|(k, b)| *b || !matches!(k, FeatureClass::Block | FeatureClass::Item));
        if needs {
            let dir = proj_dir.join("native-port");
            for (rel, text) in rustgen::generate(&analysis, &declared) {
                let p = hmc_core::path::safe_join(&dir, &rel)?;
                if let Some(parent) = p.parent() {
                    std::fs::create_dir_all(parent)?;
                }
                std::fs::write(p, text)?;
            }
            report.outputs.push("native-port/: editable Rust porting scaffold (stubs; NOT compiled, NOT a valid native bundle)".into());
            report.validation.push("native-port/ scaffold: not compiled against Horizon, not validated; no .hnmod was produced".into());
        }
    }

    let hmod_hash = sha256_file(&hmod_final)?;
    report.outputs.insert(0, format!("{id}.hmod ({} entries, sha256 {hmod_hash})", vres.files));
    for (k, v) in &analysis.timings_ms {
        report.counters.insert(format!("analysis_{k}"), *v);
    }
    report.counters.insert("total_ms".into(), t_total.elapsed().as_millis() as u64);
    if let Some(r) = peak_rss_kb() {
        report.counters.insert("peak_rss_kb".into(), r);
    }

    std::fs::write(proj_dir.join("report.md"), report.to_markdown())?;
    std::fs::write(proj_dir.join("report.json"), serde_json::to_string_pretty(&report).unwrap())?;
    std::fs::write(proj_dir.join("analysis.json"), serde_json::to_string_pretty(&analysis).unwrap())?;
    Project {
        format: 1,
        source_path: src.to_string_lossy().into_owned(),
        source_sha256: sha256_file(src)?,
        options: opts.clone(),
        created_unix: std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0),
        hmod_file: format!("{id}.hmod"),
        report: report.clone(),
    }
    .save(&proj_dir)?;
    ctl.tick("done", 1, 1);
    Ok(ConvertOutcome { hmod_path: hmod_final, project_dir: proj_dir, report })
}

/// Findings derived from static bytecode analysis and metadata.
fn code_findings(a: &Analysis, r: &mut Report) {
    let c = &a.code;
    r.counters.insert("classes_analyzed".into(), (c.total_classes - c.unparsable_classes.len()) as u64);
    for u in &c.unparsable_classes {
        r.warnings.push(format!("class not analyzed: {u}"));
    }
    let mut by_kind: BTreeMap<FeatureClass, (Vec<String>, Vec<String>)> = BTreeMap::new();
    for (class, kinds) in &c.classes {
        for (k, beh) in kinds {
            let e = by_kind.entry(k.clone()).or_default();
            if *beh {
                e.0.push(class.replace('/', "."));
            } else {
                e.1.push(class.replace('/', "."));
            }
        }
    }
    let list = |v: &[String]| {
        let mut s = v.iter().take(5).cloned().collect::<Vec<_>>().join(", ");
        if v.len() > 5 {
            s.push_str(&format!(" (+{} more)", v.len() - 5));
        }
        s
    };
    for (k, (beh, plain)) in &by_kind {
        let all: Vec<String> = beh.iter().chain(plain.iter()).cloned().collect();
        match k {
            FeatureClass::Block | FeatureClass::Item => {
                if !beh.is_empty() {
                    r.push(Finding::new("code", format!("custom {k:?} classes with behaviour"), Class::RequiresManualPorting, format!("{} class(es) override methods in Java; declared content uses vanilla templates instead: {}", beh.len(), list(beh))));
                }
            }
            FeatureClass::BlockEntity => r.push(Finding::new("code", "block entities", Class::RequiresManualPorting, format!("needs a native mod (block_entity* hooks): {}", list(&all)))),
            FeatureClass::Menu | FeatureClass::Screen => r.push(Finding::new("code", format!("{k:?} classes"), Class::RequiresManualPorting, format!("menu type data plus native screen hooks needed: {}", list(&all)))),
            FeatureClass::MobEffect => r.push(Finding::new("code", "mob effects", Class::RequiresManualPorting, format!("declare data/<id>/horizon/mob_effect/<n>.json by hand (category and colour are read from Java constructors, which HMC does not evaluate): {}", list(&all)))),
            FeatureClass::Entity => r.push(Finding::new("code", "custom entities", Class::Unsupported, format!("content mods only support thrown-item projectile entity types; no entity API in documented Horizon: {}", list(&all)))),
            FeatureClass::Renderer => r.push(Finding::new("code", "custom renderers / models", Class::Unsupported, format!("client renderers have no content-mod representation: {}", list(&all)))),
            FeatureClass::CustomRecipe => r.push(Finding::new("code", "custom recipe types/serializers", Class::Unsupported, format!("recipe-type registry is on Horizon's roadmap, not available: {}", list(&all)))),
            FeatureClass::Worldgen => r.push(Finding::new("code", "custom worldgen features/structures", Class::Unsupported, format!("Java-defined worldgen types are refused by Horizon's loader: {}", list(&all)))),
            FeatureClass::EnchantmentEffect => r.push(Finding::new("code", "custom enchantment effects", Class::Unsupported, list(&all))),
        }
    }
    for h in &a.handler_mappings {
        match &h.event.hook {
            Some(hook) => r.push(Finding::new("code", format!("{}.{}", h.class.replace('/', "."), h.method), Class::RequiresManualPorting, format!("event {} maps to Horizon hook `{hook}` (present in the bundled catalog); body must be ported by hand", h.event.event))),
            None => r.push(Finding::new("code", format!("{}.{}", h.class.replace('/', "."), h.method), Class::Unsupported, format!("event {} has no matching hook in the catalog snapshot (naming rule would suggest `{}`, unverified)", h.event.event, h.fallback_suggestion))),
        }
    }
    if !c.mixin_classes.is_empty() {
        let targets: BTreeSet<String> = c.mixin_classes.iter().flat_map(|(_, t)| t.iter().cloned()).collect();
        r.push(Finding::new("code", "Mixins", Class::Unsupported, format!("{} mixin class(es) patch Minecraft Java classes that Horizon does not have; each would need a named hook. Targets: {}", c.mixin_classes.len(), targets.into_iter().take(6).collect::<Vec<_>>().join(", "))));
    }
    if !a.meta.mixin_configs.is_empty() {
        r.push(Finding::new("code", "mixin configs", Class::Unsupported, a.meta.mixin_configs.join(", ")));
    }
    if !a.meta.access_transformers.is_empty() {
        r.push(Finding::new("code", "access transformers", Class::Unsupported, "patch Java member access; meaningless in Horizon"));
    }
    if !c.networking_classes.is_empty() {
        r.push(Finding::new("code", "networking", Class::Unsupported, format!("mod networking is not available to Horizon mods yet: {} class(es)", c.networking_classes.len())));
    }
    if !c.capability_classes.is_empty() {
        r.push(Finding::new("code", "capabilities (energy/item/fluid handlers)", Class::Unsupported, format!("{} class(es)", c.capability_classes.len())));
    }
    if !c.config_classes.is_empty() {
        r.push(Finding::new("code", "configuration", Class::RequiresManualPorting, format!("Horizon native mods can use Game::native_config_dir(); {} class(es)", c.config_classes.len())));
    }
    if !c.native_methods.is_empty() {
        r.push(Finding::new("code", "JNI native methods", Class::Unsupported, c.native_methods.join(", ")));
    }
    if !c.reflection_users.is_empty() {
        r.warnings.push(format!("{} class(es) use reflection; behaviour cannot be determined statically", c.reflection_users.len()));
    }
    if !c.other_library_refs.is_empty() {
        r.push(Finding::new("dependencies", "bundled/third-party libraries", Class::Unsupported, c.other_library_refs.iter().take(8).cloned().collect::<Vec<_>>().join(", ")));
    }
    if !a.embedded_jars.is_empty() {
        r.push(Finding::new("dependencies", "embedded (JarJar) jars", Class::Unsupported, format!("{} nested jar(s) not read: {}", a.embedded_jars.len(), a.embedded_jars.join(", "))));
    }
    for d in &a.meta.dependencies {
        if matches!(d.mod_id.as_str(), "minecraft" | "neoforge" | "forge" | "javafml") {
            continue;
        }
        let class = if d.kind == DepKind::Required { Class::RequiresManualPorting } else { Class::PartiallyConverted };
        r.push(Finding::new("dependencies", d.mod_id.clone(), class, format!("{:?} dependency {}; its features are not available unless that mod is also converted", d.kind, d.version_range.clone().unwrap_or_default())));
    }
    if c.minecraft_refs + c.neoforge_refs > 0 {
        r.counters.insert("minecraft_classes_referenced".into(), c.minecraft_refs as u64);
        r.counters.insert("neoforge_classes_referenced".into(), c.neoforge_refs as u64);
    }
    r.warnings.push("event listeners registered via addListener(...)/method references and registrations computed at runtime are not detectable by the static analyzer".into());
}
