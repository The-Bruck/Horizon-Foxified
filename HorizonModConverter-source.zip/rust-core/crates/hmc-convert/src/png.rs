//! Structural PNG validation (signature, chunk walk, CRCs, IHDR sanity).
#[derive(Debug, PartialEq, Eq)]
pub struct PngInfo {
    pub width: u32,
    pub height: u32,
    pub has_alpha: bool,
}

fn crc32(data: &[u8]) -> u32 {
    static TABLE: std::sync::OnceLock<[u32; 256]> = std::sync::OnceLock::new();
    let t = TABLE.get_or_init(|| {
        let mut t = [0u32; 256];
        for n in 0..256u32 {
            let mut c = n;
            for _ in 0..8 {
                c = if c & 1 != 0 { 0xEDB8_8320 ^ (c >> 1) } else { c >> 1 };
            }
            t[n as usize] = c;
        }
        t
    });
    let mut c = 0xFFFF_FFFFu32;
    for &b in data {
        c = t[((c ^ b as u32) & 0xFF) as usize] ^ (c >> 8);
    }
    c ^ 0xFFFF_FFFF
}

pub fn validate_png(d: &[u8]) -> Result<PngInfo, String> {
    const SIG: [u8; 8] = [0x89, b'P', b'N', b'G', 0x0D, 0x0A, 0x1A, 0x0A];
    if d.len() < 8 + 25 || d[..8] != SIG {
        return Err("not a PNG".into());
    }
    let mut p = 8usize;
    let mut info: Option<PngInfo> = None;
    let mut saw_idat = false;
    let mut saw_iend = false;
    let mut first = true;
    let mut has_trns = false;
    while p + 12 <= d.len() {
        let len = u32::from_be_bytes([d[p], d[p + 1], d[p + 2], d[p + 3]]) as usize;
        let ty = &d[p + 4..p + 8];
        let end = p.checked_add(12).and_then(|x| x.checked_add(len)).ok_or("chunk overflow")?;
        if end > d.len() {
            return Err("truncated chunk".into());
        }
        let body = &d[p + 8..p + 8 + len];
        let crc = u32::from_be_bytes([d[end - 4], d[end - 3], d[end - 2], d[end - 1]]);
        if crc32(&d[p + 4..p + 8 + len]) != crc {
            return Err(format!("CRC mismatch in {}", String::from_utf8_lossy(ty)));
        }
        if first {
            if ty != b"IHDR" || len != 13 {
                return Err("first chunk is not IHDR".into());
            }
            let w = u32::from_be_bytes([body[0], body[1], body[2], body[3]]);
            let h = u32::from_be_bytes([body[4], body[5], body[6], body[7]]);
            let (depth, color) = (body[8], body[9]);
            if w == 0 || h == 0 || w > 16384 || h > 16384 {
                return Err(format!("implausible dimensions {w}x{h}"));
            }
            let ok = match color {
                0 => matches!(depth, 1 | 2 | 4 | 8 | 16),
                2 | 4 | 6 => matches!(depth, 8 | 16),
                3 => matches!(depth, 1 | 2 | 4 | 8),
                _ => false,
            };
            if !ok {
                return Err(format!("invalid bit depth {depth} / color type {color}"));
            }
            info = Some(PngInfo { width: w, height: h, has_alpha: matches!(color, 4 | 6) });
            first = false;
        }
        match ty {
            b"IDAT" => saw_idat = true,
            b"tRNS" => has_trns = true,
            b"IEND" => {
                saw_iend = true;
                break;
            }
            _ => {}
        }
        p = end;
    }
    if !saw_idat {
        return Err("no IDAT".into());
    }
    if !saw_iend {
        return Err("no IEND".into());
    }
    let mut i = info.ok_or("no IHDR")?;
    i.has_alpha |= has_trns;
    Ok(i)
}

/// Build a tiny valid PNG (for tests): `w`x`h` RGBA, stored (uncompressed) deflate.
pub fn make_png(w: u32, h: u32) -> Vec<u8> {
    fn chunk(out: &mut Vec<u8>, ty: &[u8; 4], body: &[u8]) {
        out.extend((body.len() as u32).to_be_bytes());
        out.extend(ty);
        out.extend(body);
        let mut c = ty.to_vec();
        c.extend(body);
        out.extend(crc32(&c).to_be_bytes());
    }
    let mut out = vec![0x89, b'P', b'N', b'G', 0x0D, 0x0A, 0x1A, 0x0A];
    let mut ihdr = Vec::new();
    ihdr.extend(w.to_be_bytes());
    ihdr.extend(h.to_be_bytes());
    ihdr.extend([8, 6, 0, 0, 0]);
    chunk(&mut out, b"IHDR", &ihdr);
    // raw scanlines: filter byte + 4 bytes per pixel
    let raw: Vec<u8> = (0..h).flat_map(|_| std::iter::once(0u8).chain(std::iter::repeat(0xFF).take(w as usize * 4))).collect();
    // zlib stored block(s)
    let mut z = vec![0x78, 0x01];
    let mut rest = &raw[..];
    while !rest.is_empty() {
        let n = rest.len().min(65535);
        let last = n == rest.len();
        z.push(last as u8);
        z.extend((n as u16).to_le_bytes());
        z.extend((!(n as u16)).to_le_bytes());
        z.extend(&rest[..n]);
        rest = &rest[n..];
    }
    let (mut a, mut b) = (1u32, 0u32);
    for &x in &raw {
        a = (a + x as u32) % 65521;
        b = (b + a) % 65521;
    }
    z.extend(((b << 16) | a).to_be_bytes());
    chunk(&mut out, b"IDAT", &z);
    chunk(&mut out, b"IEND", &[]);
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn valid_and_corrupt() {
        let p = make_png(16, 16);
        let i = validate_png(&p).unwrap();
        assert_eq!((i.width, i.height, i.has_alpha), (16, 16, true));
        let mut bad = p.clone();
        bad[20] ^= 0xFF; // corrupt IHDR body
        assert!(validate_png(&bad).is_err());
        assert!(validate_png(b"hello world, definitely not a png file at all....").is_err());
        assert!(validate_png(&p[..p.len() - 6]).is_err());
    }
}
