//! Gameplay data conversion: blocks, items, recipes, worldgen block states.
use serde_json::{json, Map, Value};
use std::collections::{BTreeMap, BTreeSet};

// ---------------------------------------------------------------- recipes

fn upgrade_ingredient(v: &Value) -> Result<Value, String> {
    match v {
        Value::String(_) => Ok(v.clone()),
        Value::Array(a) => {
            let mut out = Vec::new();
            for x in a {
                match upgrade_ingredient(x)? {
                    Value::String(s) => out.push(Value::String(s)),
                    _ => return Err("nested ingredient list".into()),
                }
            }
            Ok(Value::Array(out))
        }
        Value::Object(o) => {
            if o.contains_key("type") || o.keys().any(|k| k.contains(':')) {
                return Err(format!("custom ingredient type {:?}", o.get("type")));
            }
            if o.len() != 1 {
                return Err("ingredient object with unexpected keys".into());
            }
            if let Some(Value::String(s)) = o.get("item") {
                Ok(Value::String(s.clone()))
            } else if let Some(Value::String(s)) = o.get("tag") {
                Ok(Value::String(format!("#{s}")))
            } else {
                Err("unrecognised ingredient object".into())
            }
        }
        _ => Err("ingredient is not a string, object or array".into()),
    }
}

fn upgrade_result(v: &Value, legacy_count: Option<&Value>) -> Result<Value, String> {
    match v {
        Value::String(s) => {
            let mut o = Map::new();
            o.insert("id".into(), json!(s));
            if let Some(c) = legacy_count {
                o.insert("count".into(), c.clone());
            }
            Ok(Value::Object(o))
        }
        Value::Object(o) => {
            let mut out = Map::new();
            for (k, val) in o {
                if k == "item" {
                    out.insert("id".into(), val.clone());
                } else {
                    out.insert(k.clone(), val.clone());
                }
            }
            if !matches!(out.get("id"), Some(Value::String(_))) {
                return Err("result without item id".into());
            }
            Ok(Value::Object(out))
        }
        _ => Err("result is not an object or string".into()),
    }
}

/// Upgrade a 1.21.1 recipe to the 26.3 shape (rules `recipe-*`). `Err` means the recipe
/// cannot be represented and must be skipped (with the reason reported).
pub fn upgrade_recipe(src: &Value) -> Result<Value, String> {
    let obj = src.as_object().ok_or("recipe is not an object")?;
    if obj.keys().any(|k| k.starts_with("neoforge:") || k.starts_with("forge:") || k == "conditions") {
        return Err("has neoforge:conditions".into());
    }
    let ty = obj.get("type").and_then(|t| t.as_str()).ok_or("recipe without type")?;
    let name = ty.strip_prefix("minecraft:").ok_or_else(|| format!("custom recipe type {ty}"))?;
    let mut out = obj.clone();
    let legacy_count = obj.get("count").cloned();
    let ing = |out: &mut Map<String, Value>, key: &str| -> Result<(), String> {
        if let Some(v) = out.get(key).cloned() {
            out.insert(key.into(), upgrade_ingredient(&v).map_err(|e| format!("{key}: {e}"))?);
        }
        Ok(())
    };
    match name {
        "crafting_shaped" => {
            if let Some(Value::Object(k)) = out.get("key").cloned() {
                let mut nk = Map::new();
                for (c, v) in k {
                    nk.insert(c, upgrade_ingredient(&v).map_err(|e| format!("key: {e}"))?);
                }
                out.insert("key".into(), Value::Object(nk));
            }
            let r = obj.get("result").ok_or("no result")?;
            out.insert("result".into(), upgrade_result(r, None)?);
        }
        "crafting_shapeless" => {
            if let Some(Value::Array(a)) = out.get("ingredients").cloned() {
                let mut n = Vec::new();
                for v in a {
                    n.push(upgrade_ingredient(&v).map_err(|e| format!("ingredients: {e}"))?);
                }
                out.insert("ingredients".into(), Value::Array(n));
            }
            let r = obj.get("result").ok_or("no result")?;
            out.insert("result".into(), upgrade_result(r, None)?);
        }
        "smelting" | "blasting" | "smoking" | "campfire_cooking" | "stonecutting" => {
            ing(&mut out, "ingredient")?;
            let r = obj.get("result").ok_or("no result")?;
            out.insert("result".into(), upgrade_result(r, legacy_count.as_ref())?);
            if legacy_count.is_some() && matches!(r, Value::String(_)) {
                out.remove("count");
            }
        }
        "smithing_transform" => {
            for k in ["template", "base", "addition"] {
                ing(&mut out, k)?;
            }
            let r = obj.get("result").ok_or("no result")?;
            out.insert("result".into(), upgrade_result(r, None)?);
        }
        "smithing_trim" => {
            for k in ["template", "base", "addition"] {
                ing(&mut out, k)?;
            }
        }
        // crafting_special_* and other fieldless vanilla types carry unchanged.
        t if t.starts_with("crafting_special_") || t == "crafting_decorated_pot" => {}
        other => return Err(format!("unknown vanilla recipe type minecraft:{other}")),
    }
    Ok(Value::Object(out))
}

// ------------------------------------------------------- worldgen rewrite

/// `{"Name":..,"Properties":{..}}` -> `{"id":..,"properties":{..}}` (rule `worldgen-blockstate-shape`).
pub fn rewrite_block_states(v: &mut Value) -> u64 {
    let mut n = 0;
    match v {
        Value::Object(o) => {
            let is_state = o.contains_key("Name")
                && o.keys().all(|k| k == "Name" || k == "Properties")
                && matches!(o.get("Name"), Some(Value::String(_)));
            if is_state {
                let name = o.remove("Name").unwrap();
                let props = o.remove("Properties");
                o.insert("id".into(), name);
                if let Some(p) = props {
                    o.insert("properties".into(), p);
                }
                n += 1;
            }
            for (_, x) in o.iter_mut() {
                n += rewrite_block_states(x);
            }
        }
        Value::Array(a) => {
            for x in a {
                n += rewrite_block_states(x);
            }
        }
        _ => {}
    }
    n
}

/// Does a JSON document name any neoforge:/forge: type or condition?
pub fn uses_loader_types(v: &Value) -> bool {
    match v {
        Value::String(s) => s.starts_with("neoforge:") || s.starts_with("forge:"),
        Value::Array(a) => a.iter().any(uses_loader_types),
        Value::Object(o) => o.iter().any(|(k, x)| k.starts_with("neoforge:") || k.starts_with("forge:") || uses_loader_types(x)),
        _ => false,
    }
}

// ----------------------------------------------------------------- blocks

#[derive(Clone, Debug)]
pub struct BlockPlan {
    pub name: String,
    pub json: Value,
    pub template: String,
    /// Why this block is only partially converted (always at least the registry-numbers caveat).
    pub partial: Vec<String>,
    pub states: u64,
}

pub fn blockstate_properties(v: &Value) -> BTreeMap<String, BTreeSet<String>> {
    let mut props: BTreeMap<String, BTreeSet<String>> = BTreeMap::new();
    if let Some(Value::Object(variants)) = v.get("variants") {
        for key in variants.keys() {
            if key.is_empty() || key == "normal" {
                continue;
            }
            for pair in key.split(',') {
                if let Some((k, val)) = pair.split_once('=') {
                    props.entry(k.to_string()).or_default().insert(val.to_string());
                }
            }
        }
    }
    fn when(w: &Value, props: &mut BTreeMap<String, BTreeSet<String>>) {
        if let Value::Object(o) = w {
            for (k, v) in o {
                if k == "OR" || k == "AND" {
                    if let Value::Array(a) = v {
                        for x in a {
                            when(x, props);
                        }
                    }
                } else if let Some(s) = match v {
                    Value::String(s) => Some(s.clone()),
                    Value::Bool(b) => Some(b.to_string()),
                    _ => None,
                } {
                    for part in s.split('|') {
                        props.entry(k.clone()).or_default().insert(part.trim_start_matches('!').to_string());
                    }
                }
            }
        }
    }
    if let Some(Value::Array(parts)) = v.get("multipart") {
        for p in parts {
            if let Some(w) = p.get("when") {
                when(w, &mut props);
            }
        }
    }
    props
}

fn valid_state_ident(s: &str) -> bool {
    !s.is_empty() && s.bytes().all(|b| b.is_ascii_lowercase() || b.is_ascii_digit() || b == b'_')
}

fn infer_template(name: &str, props: &BTreeMap<String, BTreeSet<String>>) -> Option<&'static str> {
    let keys: Vec<&str> = props.keys().map(|s| s.as_str()).collect();
    let vals = |k: &str| props.get(k);
    let subset = |k: &str, allowed: &[&str]| vals(k).map(|s| s.iter().all(|v| allowed.contains(&v.as_str()))).unwrap_or(false);
    Some(match keys.as_slice() {
        ["facing", "half", "hinge", "open", "powered"] => "minecraft:oak_door",
        ["facing", "half", "open", "powered", "waterlogged"] => "minecraft:oak_trapdoor",
        ["facing", "half", "shape", "waterlogged"] => "minecraft:stone_stairs",
        ["type", "waterlogged"] if subset("type", &["bottom", "top", "double"]) => "minecraft:stone_slab",
        ["axis"] if subset("axis", &["x", "y", "z"]) => "minecraft:oak_log",
        ["east", "north", "south", "waterlogged", "west"] => {
            if name.contains("pane") { "minecraft:glass_pane" } else { "minecraft:oak_fence" }
        }
        ["east", "north", "south", "up", "waterlogged", "west"] => "minecraft:cobblestone_wall",
        ["facing", "in_wall", "open", "powered"] => "minecraft:oak_fence_gate",
        ["face", "facing", "powered"] => "minecraft:stone_button",
        ["powered"] if subset("powered", &["true", "false"]) => "minecraft:stone_pressure_plate",
        ["age"] => {
            let max = props["age"].iter().filter_map(|v| v.parse::<u32>().ok()).max().unwrap_or(0);
            match max {
                3 => "minecraft:beetroots",
                7 => "minecraft:wheat",
                _ => return None,
            }
        }
        _ => return None,
    })
}

/// Plan one block declaration from its blockstate file. `has_item_model`: a
/// `models/item/<name>.json` exists, so the block has an item.
pub fn plan_block(name: &str, blockstate: &Value, has_item_model: bool) -> Result<BlockPlan, String> {
    let props = blockstate_properties(blockstate);
    let mut partial = vec![
        "hardness, resistance, light, sounds and behaviour are defined in Java and were not read; template values apply".to_string(),
    ];
    let mut obj = Map::new();
    let (template, declared): (String, bool) = match infer_template(name, &props) {
        Some(t) => (t.to_string(), false),
        None => ("minecraft:stone".to_string(), !props.is_empty()),
    };
    obj.insert("template".into(), json!(template));
    let mut states: u64 = 1;
    if declared {
        let mut sp = Map::new();
        for (k, vs) in &props {
            if !valid_state_ident(k) || vs.iter().any(|v| !valid_state_ident(v)) {
                return Err(format!("state property {k:?} has a name or value outside [a-z0-9_]"));
            }
            states = states.saturating_mul(vs.len() as u64);
            if vs.len() == 2 && vs.contains("true") && vs.contains("false") {
                sp.insert(k.clone(), json!({"type": "boolean"}));
            } else {
                let mut values: Vec<&String> = vs.iter().collect();
                if values.iter().all(|v| v.bytes().all(|b| b.is_ascii_digit())) {
                    values.sort_by_key(|v| v.parse::<u64>().unwrap_or(0));
                }
                sp.insert(k.clone(), json!({"type": "enum", "values": values}));
            }
        }
        if states > (1 << 20) {
            return Err(format!("{states} states exceeds Horizon's 2^20 limit"));
        }
        obj.insert("state_properties".into(), Value::Object(sp));
        partial.push(format!(
            "no vanilla template matches properties {:?}: using minecraft:stone with declared state properties (full-cube shape and collision)",
            props.keys().collect::<Vec<_>>()
        ));
    } else if template == "minecraft:stone" {
        partial.push("no state properties: full-cube stone template (shape taken from template, not from the model)".into());
    } else {
        partial.push(format!("template {template} inferred from the blockstate property set"));
    }
    obj.insert("item".into(), json!(has_item_model));
    Ok(BlockPlan { name: name.to_string(), json: Value::Object(obj), template, partial, states })
}

pub fn plan_item(model: &Value) -> (Value, Vec<String>) {
    let mut notes = vec!["stack size, durability, tool/food behaviour live in Java and were not read; carried as a plain item".to_string()];
    let parent = model.get("parent").and_then(|p| p.as_str()).unwrap_or("");
    if parent == "builtin/entity" || parent.ends_with("item/template_spawn_egg") {
        notes.push(format!("model parent {parent} needs a special renderer or entity: appearance will not match"));
    }
    (json!({"template": "minecraft:diamond"}), notes)
}

pub fn item_definition(ns: &str, name: &str) -> Value {
    json!({"model": {"type": "minecraft:model", "model": format!("{ns}:item/{name}")}})
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn shaped_recipe_upgrade() {
        let src = json!({
            "type": "minecraft:crafting_shaped", "category": "misc",
            "key": {"R": {"item": "ruby:ruby"}, "S": {"tag": "c:rods/wooden"}, "X": [{"item":"a:b"},{"item":"c:d"}]},
            "pattern": ["RRR", " S "],
            "result": {"count": 2, "id": "ruby:ruby_block"}
        });
        let out = upgrade_recipe(&src).unwrap();
        assert_eq!(out["key"]["R"], "ruby:ruby");
        assert_eq!(out["key"]["S"], "#c:rods/wooden");
        assert_eq!(out["key"]["X"], json!(["a:b", "c:d"]));
        assert_eq!(out["result"]["id"], "ruby:ruby_block");
    }

    #[test]
    fn legacy_item_key_and_stonecutting() {
        let out = upgrade_recipe(&json!({"type":"minecraft:stonecutting","ingredient":{"item":"a:b"},"result":"a:c","count":2})).unwrap();
        assert_eq!(out["result"], json!({"id":"a:c","count":2}));
        assert!(out.get("count").is_none());
        let out = upgrade_recipe(&json!({"type":"minecraft:smelting","ingredient":{"tag":"c:ores"},"result":{"item":"a:b"},"experience":1.0,"cookingtime":200})).unwrap();
        assert_eq!(out["result"]["id"], "a:b");
        assert_eq!(out["ingredient"], "#c:ores");
    }

    #[test]
    fn refuses_unrepresentable() {
        assert!(upgrade_recipe(&json!({"type":"mymod:machine","x":1})).is_err());
        assert!(upgrade_recipe(&json!({"type":"minecraft:smelting","neoforge:conditions":[],"ingredient":"a:b","result":{"id":"a:c"}})).is_err());
        assert!(upgrade_recipe(&json!({"type":"minecraft:crafting_shapeless","ingredients":[{"type":"neoforge:components","items":"a:b"}],"result":{"id":"a:c"}})).is_err());
    }

    #[test]
    fn block_state_rewrite() {
        let mut v = json!({"state": {"Name":"minecraft:stone"}, "list":[{"Name":"a:b","Properties":{"x":"1"}}], "other":{"Name":"x","y":1}});
        assert_eq!(rewrite_block_states(&mut v), 2);
        assert_eq!(v["state"], json!({"id":"minecraft:stone"}));
        assert_eq!(v["list"][0], json!({"id":"a:b","properties":{"x":"1"}}));
        assert_eq!(v["other"], json!({"Name":"x","y":1}));
    }

    #[test]
    fn template_inference() {
        let door = json!({"variants": {"facing=east,half=lower,hinge=left,open=false,powered=false": {"model":"a:b"}, "facing=north,half=upper,hinge=right,open=true,powered=true": {"model":"a:c"}}});
        assert_eq!(plan_block("my_door", &door, true).unwrap().template, "minecraft:oak_door");
        let plain = json!({"variants": {"": {"model": "a:b"}}});
        let p = plan_block("rock", &plain, true).unwrap();
        assert_eq!(p.template, "minecraft:stone");
        assert!(p.json.get("state_properties").is_none());
        let odd = json!({"variants": {"mode=on,charged=true": {"model":"a:b"}, "mode=off,charged=false": {"model":"a:b"}}});
        let p = plan_block("gizmo", &odd, false).unwrap();
        assert_eq!(p.json["state_properties"]["charged"], json!({"type":"boolean"}));
        assert_eq!(p.json["state_properties"]["mode"]["values"], json!(["off","on"]));
        assert_eq!(p.json["item"], false);
        let bad = json!({"variants": {"Mode=On": {"model":"a:b"}}});
        assert!(plan_block("x", &bad, true).is_err());
    }

    #[test]
    fn multipart_props() {
        let v = json!({"multipart":[{"when":{"north":"true"},"apply":{"model":"a:b"}},{"when":{"OR":[{"east":"true"},{"south":"true"}]},"apply":{"model":"a:c"}}]});
        let p = blockstate_properties(&v);
        assert_eq!(p.keys().cloned().collect::<Vec<_>>(), vec!["east", "north", "south"]);
    }
}
