//! Local project files: everything needed to review or re-export a conversion offline.
use crate::ConvertOptions;
use hmc_core::{HmcError, Report, Result};
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};

#[derive(Debug, Serialize, Deserialize)]
pub struct Project {
    pub format: u32,
    pub source_path: String,
    pub source_sha256: String,
    pub options: ConvertOptions,
    pub created_unix: u64,
    pub hmod_file: String,
    pub report: Report,
}

pub const PROJECT_FILE: &str = "project.json";

impl Project {
    pub fn save(&self, dir: &Path) -> Result<()> {
        let s = serde_json::to_string_pretty(self).map_err(|e| HmcError::Parse(e.to_string()))?;
        let tmp = dir.join("project.json.tmp");
        std::fs::write(&tmp, s)?;
        std::fs::rename(tmp, dir.join(PROJECT_FILE))?;
        Ok(())
    }

    pub fn load(dir: &Path) -> Result<Project> {
        let s = std::fs::read_to_string(dir.join(PROJECT_FILE))?;
        serde_json::from_str(&s).map_err(|e| HmcError::Parse(format!("project.json: {e}")))
    }
}

/// All projects directly under `root` (one folder per mod id).
pub fn list_projects(root: &Path) -> Vec<(PathBuf, Project)> {
    let mut v = Vec::new();
    if let Ok(rd) = std::fs::read_dir(root) {
        for e in rd.flatten() {
            if e.path().is_dir() {
                if let Ok(p) = Project::load(&e.path()) {
                    v.push((e.path(), p));
                }
            }
        }
    }
    v.sort_by(|a, b| b.1.created_unix.cmp(&a.1.created_unix));
    v
}

pub fn delete_project(dir: &Path) -> Result<()> {
    if !dir.join(PROJECT_FILE).exists() {
        return Err(HmcError::UnsafePath(format!("{} is not a project folder", dir.display())));
    }
    std::fs::remove_dir_all(dir)?;
    Ok(())
}
