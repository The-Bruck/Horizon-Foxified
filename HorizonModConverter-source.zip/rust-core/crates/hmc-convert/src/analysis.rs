//! Offline mod analysis: metadata, version detection, file census, bytecode features.
use crate::hooks::{self, HookMatch};
use hmc_bytecode::{analyze, parse_class, CodeFeatures};
use hmc_core::{Jar, Limits, Result};
use hmc_meta::{detect_version, read_meta, ModMeta, VersionDetection};
use serde::Serialize;
use std::collections::{BTreeMap, BTreeSet};
use std::io::{Read, Seek};
use std::time::Instant;

/// Namespaces that are never a mod's own.
pub const FOREIGN_NAMESPACES: &[&str] = &["minecraft", "c", "neoforge", "forge", "horizon", "fabric", "balm"];

#[derive(Clone, Debug, Serialize)]
pub struct HandlerMapping {
    pub class: String,
    pub method: String,
    pub event: HookMatch,
    /// Naming-rule suggestion used only when the catalog has no entry.
    pub fallback_suggestion: String,
}

#[derive(Clone, Debug, Serialize)]
pub struct Analysis {
    pub file_name: String,
    pub size_bytes: u64,
    pub meta: ModMeta,
    pub version: VersionDetection,
    /// Counts by category ("textures", "recipes", "blockstates", ...).
    pub census: BTreeMap<String, u64>,
    /// Namespaces under assets/ and data/.
    pub namespaces: Vec<String>,
    pub code: CodeFeatures,
    pub handler_mappings: Vec<HandlerMapping>,
    /// Nested jars (JarJar) whose contents HMC does not read.
    pub embedded_jars: Vec<String>,
    pub rejected_entries: Vec<String>,
    pub timings_ms: BTreeMap<String, u64>,
}

/// Category of a resource path (`assets/ns/...` or `data/ns/...`), or None for non-resources.
pub fn categorize(path: &str) -> Option<(&'static str, &str)> {
    let mut it = path.splitn(3, '/');
    let root = it.next()?;
    let ns = it.next()?;
    let rest = it.next()?;
    let first = rest.split('/').next().unwrap_or("");
    let cat = match root {
        "assets" => match first {
            "textures" => "textures",
            "models" => "models",
            "blockstates" => "blockstates",
            "items" => "item_definitions",
            "lang" => "lang",
            "sounds" => "sounds",
            "sounds.json" => "sound_definitions",
            "particles" => "particles",
            "font" => "fonts",
            "atlases" => "atlases",
            "shaders" | "post_effect" => "shaders",
            "texts" => "texts",
            _ => "other_assets",
        },
        "data" => match first {
            "recipe" => "recipes",
            "recipes" => "legacy_plural_recipes",
            "loot_table" => "loot_tables",
            "loot_tables" => "legacy_plural_loot_tables",
            "tags" => "tags",
            "advancement" => "advancements",
            "worldgen" => "worldgen",
            "structure" => "structures",
            "neoforge" | "forge" => "neoforge_data",
            "dimension" | "dimension_type" => "dimensions",
            "function" => "functions",
            "enchantment" => "enchantments",
            "damage_type" => "damage_types",
            _ => "other_data",
        },
        _ => return None,
    };
    Some((cat, ns))
}

pub fn analyze_jar<R: Read + Seek>(jar: &mut Jar<R>, file_name: &str, size_bytes: u64) -> Result<Analysis> {
    let mut timings = BTreeMap::new();
    let t = Instant::now();
    let meta = read_meta(jar)?;
    let version = detect_version(jar, &meta);
    timings.insert("metadata_ms".to_string(), t.elapsed().as_millis() as u64);

    let t = Instant::now();
    let mut census: BTreeMap<String, u64> = BTreeMap::new();
    let mut nss = BTreeSet::new();
    let mut embedded = Vec::new();
    let mut class_names = Vec::new();
    for e in &jar.entries {
        if let Some((cat, ns)) = categorize(&e.name) {
            *census.entry(cat.to_string()).or_default() += 1;
            nss.insert(ns.to_string());
        } else if e.name.ends_with(".class") && !e.name.ends_with("module-info.class") && !e.name.starts_with("META-INF/versions/") {
            class_names.push(e.name.clone());
        } else if e.name.starts_with("META-INF/jarjar/") && e.name.ends_with(".jar") {
            embedded.push(e.name.clone());
        }
    }
    census.insert("classes".into(), class_names.len() as u64);
    timings.insert("census_ms".to_string(), t.elapsed().as_millis() as u64);

    let t = Instant::now();
    let mut classes = Vec::with_capacity(class_names.len());
    let mut bad = Vec::new();
    for n in &class_names {
        match jar.read_class(n).and_then(|b| parse_class(&b)) {
            Ok(c) => classes.push(c),
            Err(e) => bad.push(format!("{n}: {e}")),
        }
    }
    let code = analyze(&classes, bad);
    timings.insert("bytecode_ms".to_string(), t.elapsed().as_millis() as u64);

    let handler_mappings = code
        .event_handlers
        .iter()
        .map(|h| HandlerMapping {
            class: h.class.clone(),
            method: h.method.clone(),
            event: hooks::map_event(&h.event_class),
            fallback_suggestion: h.suggested_hook.clone(),
        })
        .collect();

    Ok(Analysis {
        file_name: file_name.to_string(),
        size_bytes,
        meta,
        version,
        census,
        namespaces: nss.into_iter().collect(),
        code,
        handler_mappings,
        embedded_jars: embedded,
        rejected_entries: jar.rejected.clone(),
        timings_ms: timings,
    })
}

pub fn analyze_path(path: &std::path::Path, limits: Limits) -> Result<Analysis> {
    let size = std::fs::metadata(path)?.len();
    let mut jar = Jar::open(path, limits)?;
    let name = path.file_name().map(|s| s.to_string_lossy().into_owned()).unwrap_or_default();
    analyze_jar(&mut jar, &name, size)
}

impl Analysis {
    /// Namespaces that belong to the mod itself.
    pub fn own_namespaces(&self) -> Vec<String> {
        let mut v: Vec<String> = self
            .namespaces
            .iter()
            .filter(|n| !FOREIGN_NAMESPACES.contains(&n.as_str()))
            .cloned()
            .collect();
        if !v.contains(&self.meta.mod_id) && self.namespaces.contains(&self.meta.mod_id) {
            v.push(self.meta.mod_id.clone());
        }
        v.sort();
        v
    }
}
