//! Batch analysis (cross-mod dependency report) and bounded-parallel conversion.
use crate::analysis::{analyze_path, Analysis};
use crate::convert::{convert, Control, ConvertOptions, ConvertOutcome, Progress};
use hmc_core::{HmcError, Result};
use hmc_meta::DepKind;
use serde::Serialize;
use std::collections::{BTreeMap, BTreeSet, VecDeque};
use std::path::{Path, PathBuf};
use std::sync::atomic::AtomicBool;
use std::sync::{Arc, Mutex};

const PLATFORM_IDS: &[&str] = &["minecraft", "neoforge", "forge", "javafml", "lowcodefml", "mixinextras"];

#[derive(Debug, Serialize, Default)]
pub struct DependencyReport {
    /// (mod, missing required dependency)
    pub missing_required: Vec<(String, String)>,
    pub missing_optional: Vec<(String, String)>,
    /// (mod, incompatible mod that is present in the set)
    pub conflicts: Vec<(String, String)>,
    pub cycles: Vec<Vec<String>>,
    /// Libraries first.
    pub order: Vec<String>,
    /// Dependencies several mods share.
    pub shared: BTreeMap<String, Vec<String>>,
}

pub fn dependency_report(set: &[Analysis]) -> DependencyReport {
    let present: BTreeSet<&str> = set.iter().flat_map(|a| a.meta.all_mod_ids.iter().map(|s| s.as_str())).collect();
    let mut rep = DependencyReport::default();
    let mut edges: BTreeMap<String, BTreeSet<String>> = BTreeMap::new();
    for a in set {
        let me = a.meta.mod_id.clone();
        edges.entry(me.clone()).or_default();
        for d in &a.meta.dependencies {
            let id = d.mod_id.as_str();
            if PLATFORM_IDS.contains(&id) {
                continue;
            }
            match d.kind {
                DepKind::Required => {
                    rep.shared.entry(id.to_string()).or_default().push(me.clone());
                    if present.contains(id) {
                        edges.get_mut(&me).unwrap().insert(id.to_string());
                    } else {
                        rep.missing_required.push((me.clone(), id.to_string()));
                    }
                }
                DepKind::Optional => {
                    if !present.contains(id) {
                        rep.missing_optional.push((me.clone(), id.to_string()));
                    }
                }
                DepKind::Incompatible => {
                    if present.contains(id) {
                        rep.conflicts.push((me.clone(), id.to_string()));
                    }
                }
                DepKind::Discouraged => {}
            }
        }
    }
    rep.shared.retain(|_, v| v.len() > 1);

    // Kahn order; leftovers are cyclic.
    let mut indeg: BTreeMap<&str, usize> = edges.iter().map(|(k, v)| (k.as_str(), v.len())).collect();
    let mut q: VecDeque<&str> = indeg.iter().filter(|(_, d)| **d == 0).map(|(k, _)| *k).collect();
    let mut done: BTreeSet<&str> = BTreeSet::new();
    while let Some(n) = q.pop_front() {
        done.insert(n);
        rep.order.push(n.to_string());
        for (m, deps) in &edges {
            if deps.contains(n) && !done.contains(m.as_str()) {
                let e = indeg.get_mut(m.as_str()).unwrap();
                *e = e.saturating_sub(1);
                if *e == 0 && !q.contains(&m.as_str()) {
                    q.push_back(m.as_str());
                }
            }
        }
    }
    let cyc: Vec<String> = edges.keys().filter(|k| !done.contains(k.as_str())).cloned().collect();
    if !cyc.is_empty() {
        rep.cycles.push(cyc);
    }
    rep
}

pub struct BatchJob {
    pub path: PathBuf,
    pub cancel: Arc<AtomicBool>,
}

pub struct BatchResult {
    pub path: PathBuf,
    pub result: Result<ConvertOutcome>,
}

/// Convert many JARs with at most `workers` running at once. Each job has its own cancel flag.
pub fn convert_batch(
    jobs: Vec<BatchJob>,
    out_root: &Path,
    opts: &ConvertOptions,
    workers: usize,
    on_progress: &(dyn Fn(usize, Progress) + Sync),
) -> Vec<BatchResult> {
    let workers = workers.clamp(1, 8);
    let queue: Mutex<VecDeque<(usize, BatchJob)>> = Mutex::new(jobs.into_iter().enumerate().collect());
    let results: Mutex<Vec<(usize, BatchResult)>> = Mutex::new(Vec::new());
    std::thread::scope(|s| {
        for _ in 0..workers {
            s.spawn(|| loop {
                let next = queue.lock().unwrap().pop_front();
                let Some((idx, job)) = next else { break };
                let cb = |p: Progress| on_progress(idx, p);
                let ctl = Control { cancel: Some(job.cancel.as_ref()), progress: Some(&cb) };
                let r = convert(&job.path, out_root, opts, &ctl);
                results.lock().unwrap().push((idx, BatchResult { path: job.path, result: r }));
            });
        }
    });
    let mut v = results.into_inner().unwrap();
    v.sort_by_key(|(i, _)| *i);
    v.into_iter().map(|(_, r)| r).collect()
}

/// Copy every produced `.hmod` into one folder for export together.
pub fn export_together(results: &[BatchResult], dest: &Path) -> Result<Vec<PathBuf>> {
    std::fs::create_dir_all(dest)?;
    let mut out = Vec::new();
    for r in results {
        if let Ok(o) = &r.result {
            let name = o.hmod_path.file_name().ok_or_else(|| HmcError::Io("no file name".into()))?;
            let to = dest.join(name);
            std::fs::copy(&o.hmod_path, &to)?;
            out.push(to);
        }
    }
    Ok(out)
}

pub fn analyze_all(paths: &[PathBuf], limits: &hmc_core::Limits) -> Vec<(PathBuf, Result<Analysis>)> {
    paths.iter().map(|p| (p.clone(), analyze_path(p, limits.clone()))).collect()
}
