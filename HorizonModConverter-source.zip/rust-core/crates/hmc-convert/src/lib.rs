//! HMC conversion engine: NeoForge 1.21.1 JAR -> Horizon 26.3 content mod (`.hmod`).
pub mod adapter;
pub mod analysis;
pub mod batch;
pub mod convert;
pub mod gameplay;
pub mod hooks;
pub mod png;
pub mod project;
pub mod rules;
pub mod rustgen;
pub mod validate;

pub use analysis::{analyze_path, Analysis};
pub use convert::{convert, ConvertOptions, ConvertOutcome, Control, Progress};

/// Self-diagnostics: verify every bundled conversion component is present and consistent.
pub fn selftest() -> Vec<(String, bool, String)> {
    let mut v = Vec::new();
    let cat = hooks::catalog();
    v.push(("hook catalog".into(), cat.hooks.len() > 100, format!("{} hooks, Horizon commit {}", cat.hooks.len(), &cat.commit[..12])));
    for t in adapter::available_targets() {
        let a = adapter::adapter_for(t);
        v.push((format!("target adapter {t}"), a.as_ref().is_some_and(|a| !a.rules().is_empty()), a.map(|a| format!("{} rules", a.rules().len())).unwrap_or_default()));
    }
    let png = png::make_png(2, 2);
    v.push(("png validator".into(), png::validate_png(&png).is_ok(), String::new()));
    v.push(("recipe upgrader".into(), gameplay::upgrade_recipe(&serde_json::json!({"type":"minecraft:smelting","ingredient":{"item":"a:b"},"result":{"item":"a:c"}})).is_ok(), String::new()));
    v
}
