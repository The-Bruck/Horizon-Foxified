//! Offline snapshot of Horizon's native hook catalog (`native-hooks.json`), used to
//! check suggested NeoForge-event -> Horizon-hook mappings against the real catalog.
use serde::Deserialize;
use std::collections::HashMap;
use std::sync::OnceLock;

#[derive(Debug, Deserialize)]
pub struct Hook {
    pub name: String,
    pub version: u32,
    pub neoforge: Option<String>,
    pub side: Option<String>,
    pub cancellable: Option<bool>,
}

#[derive(Debug, Deserialize)]
pub struct Catalog {
    pub commit: String,
    pub snapshot_date: String,
    pub hooks: Vec<Hook>,
}

static RAW: &str = include_str!("../resources/horizon_hooks.json");

pub fn catalog() -> &'static Catalog {
    static C: OnceLock<Catalog> = OnceLock::new();
    C.get_or_init(|| serde_json::from_str(RAW).expect("bundled hook catalog is valid JSON"))
}

fn by_neoforge() -> &'static HashMap<&'static str, &'static Hook> {
    static M: OnceLock<HashMap<&'static str, &'static Hook>> = OnceLock::new();
    M.get_or_init(|| {
        catalog().hooks.iter().filter_map(|h| h.neoforge.as_deref().map(|n| (n, h))).collect()
    })
}

#[derive(Clone, Debug, serde::Serialize)]
pub struct HookMatch {
    /// A hook that exists in the catalog snapshot, when the event maps to one.
    pub hook: Option<String>,
    pub hook_version: Option<u32>,
    pub cancellable: Option<bool>,
    pub side: Option<String>,
    /// The NeoForge event name used for lookup, e.g. `ServerTickEvent.Pre`.
    pub event: String,
}

/// `net/neoforged/neoforge/event/tick/ServerTickEvent$Pre` -> `ServerTickEvent.Pre`.
pub fn event_name(internal: &str) -> String {
    internal.rsplit('/').next().unwrap_or(internal).replace('$', ".")
}

pub fn map_event(internal: &str) -> HookMatch {
    let event = event_name(internal);
    match by_neoforge().get(event.as_str()) {
        Some(h) => HookMatch {
            hook: Some(h.name.clone()),
            hook_version: Some(h.version),
            cancellable: h.cancellable,
            side: h.side.clone(),
            event,
        },
        None => HookMatch { hook: None, hook_version: None, cancellable: None, side: None, event },
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn catalog_loads_and_maps() {
        assert!(catalog().hooks.len() > 100);
        let m = map_event("net/neoforged/neoforge/event/server/ServerStoppingEvent");
        assert_eq!(m.hook.as_deref(), Some("server_stopping"));
        let none = map_event("net/neoforged/neoforge/event/NoSuchThingEvent");
        assert!(none.hook.is_none());
    }
}
