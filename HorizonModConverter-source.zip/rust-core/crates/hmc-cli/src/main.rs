use hmc_convert::batch::{convert_batch, dependency_report, export_together, BatchJob};
use hmc_convert::{analyze_path, ConvertOptions};
use std::path::PathBuf;
use std::sync::atomic::AtomicBool;
use std::sync::Arc;

const USAGE: &str = "hmc - Horizon Mod Converter (offline)
usage:
  hmc analyze <jar>... [--json]
  hmc convert <jar>... --out <dir> [--worldgen] [--override-source] [--workers N] [--export <dir>]
  hmc rules
  hmc selftest";

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let code = match run(&args) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("error: {e}");
            1
        }
    };
    std::process::exit(code);
}

fn flag(args: &[String], name: &str) -> bool {
    args.iter().any(|a| a == name)
}
fn opt(args: &[String], name: &str) -> Option<String> {
    args.iter().position(|a| a == name).and_then(|i| args.get(i + 1)).cloned()
}
fn jars(args: &[String]) -> Vec<PathBuf> {
    let mut out = Vec::new();
    let mut skip = false;
    for a in args.iter().skip(1) {
        if skip {
            skip = false;
            continue;
        }
        if matches!(a.as_str(), "--out" | "--workers" | "--export") {
            skip = true;
        } else if !a.starts_with("--") {
            out.push(PathBuf::from(a));
        }
    }
    out
}

fn run(args: &[String]) -> Result<i32, String> {
    match args.first().map(|s| s.as_str()) {
        Some("analyze") => {
            let limits = hmc_core::Limits::default();
            let mut set = Vec::new();
            let mut rc = 0;
            for p in jars(args) {
                match analyze_path(&p, limits.clone()) {
                    Ok(a) => {
                        if flag(args, "--json") {
                            println!("{}", serde_json::to_string_pretty(&a).unwrap());
                        } else {
                            println!("{}: {} {} ({:?}) mc={:?} nf={:?} supported={}", a.file_name, a.meta.display_name, a.meta.version, a.meta.loader, a.version.minecraft, a.version.neoforge, a.version.supported);
                            println!("  census: {:?}", a.census);
                            println!("  classes: {} handlers: {} mixins: {}", a.code.total_classes, a.handler_mappings.len(), a.code.mixin_classes.len());
                            for c in &a.version.conflicts {
                                println!("  CONFLICT: {c}");
                            }
                        }
                        set.push(a);
                    }
                    Err(e) => {
                        eprintln!("{}: {e}", p.display());
                        rc = 2;
                    }
                }
            }
            if set.len() > 1 {
                println!("{}", serde_json::to_string_pretty(&dependency_report(&set)).unwrap());
            }
            Ok(rc)
        }
        Some("convert") => {
            let out = PathBuf::from(opt(args, "--out").ok_or("--out <dir> required")?);
            let mut o = ConvertOptions::default();
            o.carry_worldgen = flag(args, "--worldgen");
            o.override_source = flag(args, "--override-source");
            let workers = opt(args, "--workers").and_then(|w| w.parse().ok()).unwrap_or(2);
            let list = jars(args);
            if list.is_empty() {
                return Err("no jars given".into());
            }
            let jobs = list.into_iter().map(|p| BatchJob { path: p, cancel: Arc::new(AtomicBool::new(false)) }).collect();
            let results = convert_batch(jobs, &out, &o, workers, &|_, _| {});
            let mut rc = 0;
            for r in &results {
                match &r.result {
                    Ok(o) => {
                        println!("{}: {}", r.path.display(), o.hmod_path.display());
                        println!("{}", o.report.to_markdown());
                    }
                    Err(e) => {
                        eprintln!("{}: FAILED: {e}", r.path.display());
                        rc = 2;
                    }
                }
            }
            if let Some(d) = opt(args, "--export") {
                let v = export_together(&results, &PathBuf::from(d)).map_err(|e| e.to_string())?;
                println!("exported {} package(s)", v.len());
            }
            Ok(rc)
        }
        Some("rules") => {
            for t in hmc_convert::adapter::available_targets() {
                let a = hmc_convert::adapter::adapter_for(t).unwrap();
                println!("{}", serde_json::to_string_pretty(a.rules()).unwrap());
            }
            Ok(0)
        }
        Some("selftest") => {
            let mut rc = 0;
            for (name, ok, note) in hmc_convert::selftest() {
                println!("[{}] {name} {note}", if ok { "ok" } else { "FAIL" });
                if !ok {
                    rc = 1;
                }
            }
            Ok(rc)
        }
        _ => {
            println!("{USAGE}");
            Ok(64)
        }
    }
}
