use serde::{Deserialize, Serialize};

/// Resource limits applied to every imported (untrusted) archive.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Limits {
    pub max_entries: usize,
    /// Largest single entry, uncompressed.
    pub max_entry_bytes: u64,
    /// Sum of all entries, uncompressed.
    pub max_total_bytes: u64,
    /// Largest allowed uncompressed/compressed ratio for an entry (entries
    /// under `ratio_floor_bytes` are exempt: tiny files compress absurdly well).
    pub max_ratio: u64,
    pub ratio_floor_bytes: u64,
    /// Largest class file the bytecode analyzer will parse.
    pub max_class_bytes: u64,
}

impl Default for Limits {
    fn default() -> Self {
        // Content limits mirror Horizon's own (65,536 files, 16 MiB each, 512 MiB total).
        Limits {
            max_entries: 65_536,
            max_entry_bytes: 16 * 1024 * 1024,
            max_total_bytes: 512 * 1024 * 1024,
            max_ratio: 200,
            ratio_floor_bytes: 64 * 1024,
            max_class_bytes: 4 * 1024 * 1024,
        }
    }
}
