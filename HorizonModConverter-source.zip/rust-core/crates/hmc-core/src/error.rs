use std::fmt;

#[derive(Debug)]
pub enum HmcError {
    Io(String),
    Archive(String),
    /// A security limit was exceeded (zip bomb, oversized file, ...).
    Limit(String),
    /// Unsafe path inside an archive or output location.
    UnsafePath(String),
    Parse(String),
    Unsupported(String),
    Validation(Vec<String>),
}

pub type Result<T> = std::result::Result<T, HmcError>;

impl fmt::Display for HmcError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            HmcError::Io(s) => write!(f, "I/O error: {s}"),
            HmcError::Archive(s) => write!(f, "archive error: {s}"),
            HmcError::Limit(s) => write!(f, "limit exceeded: {s}"),
            HmcError::UnsafePath(s) => write!(f, "unsafe path: {s}"),
            HmcError::Parse(s) => write!(f, "parse error: {s}"),
            HmcError::Unsupported(s) => write!(f, "unsupported: {s}"),
            HmcError::Validation(v) => write!(f, "validation failed: {}", v.join("; ")),
        }
    }
}
impl std::error::Error for HmcError {}
impl From<std::io::Error> for HmcError {
    fn from(e: std::io::Error) -> Self {
        HmcError::Io(e.to_string())
    }
}
impl From<zip::result::ZipError> for HmcError {
    fn from(e: zip::result::ZipError) -> Self {
        HmcError::Archive(e.to_string())
    }
}
