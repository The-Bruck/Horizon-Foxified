use serde::{Deserialize, Serialize};

/// Compatibility classification, as required by the spec.
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq, Hash)]
#[serde(rename_all = "snake_case")]
pub enum Class {
    /// Translated into Horizon data and passed HMC's own validation.
    AutomaticallyConverted,
    PartiallyConverted,
    RequiresManualPorting,
    Unsupported,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Finding {
    /// e.g. "assets", "blocks", "items", "recipes", "code", "dependencies".
    pub category: String,
    pub name: String,
    pub class: Class,
    pub detail: String,
}

impl Finding {
    pub fn new(category: &str, name: impl Into<String>, class: Class, detail: impl Into<String>) -> Self {
        Finding { category: category.into(), name: name.into(), class, detail: detail.into() }
    }
}

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct Report {
    pub mod_name: String,
    pub mod_id: String,
    pub source: String,
    pub target: String,
    pub findings: Vec<Finding>,
    pub warnings: Vec<String>,
    /// Plain counters ("textures_carried": 24). No invented percentages.
    pub counters: std::collections::BTreeMap<String, u64>,
    /// What was actually produced and checked.
    pub outputs: Vec<String>,
    /// Honest status of each stage: what was validated and by what.
    pub validation: Vec<String>,
}

impl Report {
    pub fn count(&self, c: Class) -> usize {
        self.findings.iter().filter(|f| f.class == c).count()
    }
    pub fn bump(&mut self, key: &str, by: u64) {
        *self.counters.entry(key.to_string()).or_insert(0) += by;
    }
    pub fn push(&mut self, f: Finding) {
        self.findings.push(f);
    }

    /// One-line verdict. Deliberately no percentage.
    pub fn verdict(&self) -> &'static str {
        let manual = self.count(Class::RequiresManualPorting) + self.count(Class::Unsupported);
        let partial = self.count(Class::PartiallyConverted);
        if manual == 0 && partial == 0 {
            "Conversion completed without recorded limitations (data/assets only; code behaviour not evaluated beyond the findings)."
        } else {
            "Conversion completed with limitations."
        }
    }

    pub fn to_markdown(&self) -> String {
        let mut s = String::new();
        s.push_str(&format!("# Conversion report: {}\n\n", self.mod_name));
        s.push_str(&format!("- Mod id: `{}`\n- Source: {}\n- Target: {}\n\n", self.mod_id, self.source, self.target));
        s.push_str("## Counters\n\n");
        for (k, v) in &self.counters {
            s.push_str(&format!("- {k}: {v}\n"));
        }
        for (title, class) in [
            ("Automatically converted", Class::AutomaticallyConverted),
            ("Partially converted", Class::PartiallyConverted),
            ("Requires manual porting", Class::RequiresManualPorting),
            ("Unsupported", Class::Unsupported),
        ] {
            let items: Vec<_> = self.findings.iter().filter(|f| f.class == class).collect();
            s.push_str(&format!("\n## {title} ({})\n\n", items.len()));
            for f in items {
                s.push_str(&format!("- [{}] {}: {}\n", f.category, f.name, f.detail));
            }
        }
        if !self.warnings.is_empty() {
            s.push_str("\n## Warnings\n\n");
            for w in &self.warnings {
                s.push_str(&format!("- {w}\n"));
            }
        }
        s.push_str("\n## Validation performed\n\n");
        for v in &self.validation {
            s.push_str(&format!("- {v}\n"));
        }
        s.push_str("\n## Outputs\n\n");
        for o in &self.outputs {
            s.push_str(&format!("- {o}\n"));
        }
        s.push_str(&format!("\n**Result:** {}\n", self.verdict()));
        s
    }
}
