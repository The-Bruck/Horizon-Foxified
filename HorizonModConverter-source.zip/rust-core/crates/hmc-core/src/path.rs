use crate::error::{HmcError, Result};

/// Validate an archive entry name the way Horizon's readers do: relative,
/// `/`-separated, no `\`, no `:`, no empty / `.` / `..` parts.
/// Returns the name without a trailing slash for directory entries.
pub fn validate_entry_path(name: &str) -> Result<&str> {
    let bad = |why: &str| Err(HmcError::UnsafePath(format!("{name:?}: {why}")));
    if name.is_empty() {
        return bad("empty");
    }
    if name.starts_with('/') {
        return bad("absolute");
    }
    if name.contains('\\') || name.contains(':') || name.contains('\0') {
        return bad("forbidden character");
    }
    let trimmed = name.strip_suffix('/').unwrap_or(name);
    for part in trimmed.split('/') {
        if part.is_empty() || part == "." || part == ".." {
            return bad("empty, '.' or '..' component");
        }
    }
    Ok(trimmed)
}

/// Resource-location characters Horizon accepts in content paths.
pub fn is_resource_char(b: u8) -> bool {
    b.is_ascii_lowercase() || b.is_ascii_digit() || matches!(b, b'_' | b'.' | b'-')
}

/// `[a-z0-9_]{1,64}`
pub fn valid_mod_id(id: &str) -> bool {
    !id.is_empty()
        && id.len() <= 64
        && id.bytes().all(|b| b.is_ascii_lowercase() || b.is_ascii_digit() || b == b'_')
}

/// Join `rel` under `base` after validating; refuses anything that could escape.
pub fn safe_join(base: &std::path::Path, rel: &str) -> Result<std::path::PathBuf> {
    let rel = validate_entry_path(rel)?;
    Ok(base.join(rel))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn rejects_traversal() {
        for n in ["../x", "a/../b", "/abs", "a\\b", "c:/x", "a//b", "./a", ""] {
            assert!(validate_entry_path(n).is_err(), "{n}");
        }
        assert!(validate_entry_path("assets/mod/x.png").is_ok());
        assert_eq!(validate_entry_path("assets/").unwrap(), "assets");
    }
    #[test]
    fn mod_ids() {
        assert!(valid_mod_id("ruby_2"));
        assert!(!valid_mod_id("Ruby"));
        assert!(!valid_mod_id("a-b"));
        assert!(!valid_mod_id(""));
    }
}
