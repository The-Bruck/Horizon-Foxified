use crate::error::{HmcError, Result};
use crate::limits::Limits;
use crate::path::validate_entry_path;
use std::fs::File;
use std::io::{Read, Seek};
use zip::ZipArchive;

#[derive(Clone, Debug)]
pub struct JarEntry {
    pub name: String,
    pub size: u64,
    pub compressed: u64,
}

/// A read-only, limit-checked view of a JAR. The file is never modified and
/// never loaded fully into memory: entries are decompressed one at a time,
/// with a hard cap enforced while reading (not trusted from the header).
pub struct Jar<R: Read + Seek> {
    zip: ZipArchive<R>,
    limits: Limits,
    pub entries: Vec<JarEntry>,
    /// Entries skipped because their names were unsafe (path traversal etc).
    pub rejected: Vec<String>,
}

impl Jar<File> {
    pub fn open(path: &std::path::Path, limits: Limits) -> Result<Self> {
        Jar::new(File::open(path)?, limits)
    }
}

impl<R: Read + Seek> Jar<R> {
    pub fn new(reader: R, limits: Limits) -> Result<Self> {
        let mut zip = ZipArchive::new(reader)?;
        if zip.len() > limits.max_entries {
            return Err(HmcError::Limit(format!("{} entries (max {})", zip.len(), limits.max_entries)));
        }
        let mut entries = Vec::with_capacity(zip.len());
        let mut rejected = Vec::new();
        let mut total: u64 = 0;
        for i in 0..zip.len() {
            let f = zip.by_index_raw(i)?;
            let raw = f.name().to_string();
            if f.is_dir() {
                continue;
            }
            let name = match validate_entry_path(&raw) {
                Ok(n) => n.to_string(),
                Err(_) => {
                    rejected.push(raw);
                    continue;
                }
            };
            let (size, comp) = (f.size(), f.compressed_size());
            if size > limits.max_entry_bytes && !name.ends_with(".class") {
                // Oversized non-class entries are skipped (reported), not fatal.
                rejected.push(format!("{name} (oversized: {size} bytes)"));
                continue;
            }
            if size > limits.ratio_floor_bytes && comp > 0 && size / comp > limits.max_ratio {
                return Err(HmcError::Limit(format!(
                    "{name}: compression ratio {} exceeds {}", size / comp, limits.max_ratio
                )));
            }
            total = total.saturating_add(size);
            if total > limits.max_total_bytes {
                return Err(HmcError::Limit(format!("declared total exceeds {} bytes", limits.max_total_bytes)));
            }
            entries.push(JarEntry { name, size, compressed: comp });
        }
        Ok(Jar { zip, limits, entries, rejected })
    }

    pub fn limits(&self) -> &Limits {
        &self.limits
    }

    pub fn contains(&self, name: &str) -> bool {
        self.entries.iter().any(|e| e.name == name)
    }

    /// Read one entry, enforcing `max` bytes while decompressing.
    pub fn read_limited(&mut self, name: &str, max: u64) -> Result<Vec<u8>> {
        if !self.contains(name) {
            return Err(HmcError::Archive(format!("no entry {name}")));
        }
        let f = self.zip.by_name(name)?;
        let mut buf = Vec::new();
        f.take(max + 1).read_to_end(&mut buf)?;
        if buf.len() as u64 > max {
            return Err(HmcError::Limit(format!("{name} exceeds {max} bytes when decompressed")));
        }
        Ok(buf)
    }

    pub fn read(&mut self, name: &str) -> Result<Vec<u8>> {
        let max = self.limits.max_entry_bytes;
        self.read_limited(name, max)
    }

    pub fn read_class(&mut self, name: &str) -> Result<Vec<u8>> {
        let max = self.limits.max_class_bytes;
        self.read_limited(name, max)
    }

    pub fn read_string(&mut self, name: &str) -> Result<String> {
        let b = self.read(name)?;
        String::from_utf8(b).map_err(|e| HmcError::Parse(format!("{name}: {e}")))
    }

    pub fn names_with_prefix<'a>(&'a self, prefix: &'a str) -> impl Iterator<Item = &'a JarEntry> + 'a {
        self.entries.iter().filter(move |e| e.name.starts_with(prefix))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::{Cursor, Write};

    fn make(files: &[(&str, &[u8])]) -> Vec<u8> {
        let mut w = zip::ZipWriter::new(Cursor::new(Vec::new()));
        let o = zip::write::FileOptions::default().compression_method(zip::CompressionMethod::Deflated);
        for (n, d) in files {
            w.start_file(*n, o).unwrap();
            w.write_all(d).unwrap();
        }
        w.finish().unwrap().into_inner()
    }

    #[test]
    fn reads_and_rejects_traversal() {
        let z = make(&[("a/b.txt", b"hi"), ("../evil.txt", b"x")]);
        let mut j = Jar::new(Cursor::new(z), Limits::default()).unwrap();
        assert_eq!(j.entries.len(), 1);
        assert_eq!(j.rejected.len(), 1);
        assert_eq!(j.read_string("a/b.txt").unwrap(), "hi");
    }

    #[test]
    fn zip_bomb_ratio_rejected() {
        let big = vec![0u8; 8 * 1024 * 1024];
        let z = make(&[("bomb.bin", &big)]);
        let r = Jar::new(Cursor::new(z), Limits::default());
        assert!(matches!(r, Err(HmcError::Limit(_))));
    }

    #[test]
    fn entry_count_limit() {
        let z = make(&[("a", b"1"), ("b", b"2"), ("c", b"3")]);
        let l = Limits { max_entries: 2, ..Limits::default() };
        assert!(matches!(Jar::new(Cursor::new(z), l), Err(HmcError::Limit(_))));
    }
}
