//! JNI bridge. All calls exchange JSON strings; panics never cross the FFI boundary.
use hmc_convert::project::{delete_project, list_projects};
use hmc_convert::{analyze_path, convert, ConvertOptions, Control};
use jni::objects::{JClass, JString};
use jni::sys::{jint, jstring};
use jni::JNIEnv;
use serde_json::{json, Value};
use std::collections::HashMap;
use std::path::Path;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex, OnceLock};

struct Job {
    cancel: AtomicBool,
    progress: Mutex<(String, u64, u64)>,
}

fn jobs() -> &'static Mutex<HashMap<i32, Arc<Job>>> {
    static J: OnceLock<Mutex<HashMap<i32, Arc<Job>>>> = OnceLock::new();
    J.get_or_init(|| Mutex::new(HashMap::new()))
}

pub mod api {
    use super::*;

    pub fn analyze(path: &str) -> Value {
        match analyze_path(Path::new(path), hmc_core::Limits::default()) {
            Ok(a) => json!({"ok": true, "analysis": a}),
            Err(e) => json!({"ok": false, "error": e.to_string()}),
        }
    }

    pub fn convert_job(job_id: i32, path: &str, out_dir: &str, options_json: &str) -> Value {
        let opts: ConvertOptions = if options_json.trim().is_empty() {
            ConvertOptions::default()
        } else {
            match serde_json::from_str(options_json) {
                Ok(o) => o,
                Err(e) => return json!({"ok": false, "error": format!("bad options: {e}")}),
            }
        };
        let job = Arc::new(Job { cancel: AtomicBool::new(false), progress: Mutex::new((String::new(), 0, 0)) });
        jobs().lock().unwrap().insert(job_id, job.clone());
        let cb = |p: hmc_convert::Progress| {
            *job.progress.lock().unwrap() = (p.stage, p.done, p.total);
        };
        let ctl = Control { cancel: Some(&job.cancel), progress: Some(&cb) };
        let r = convert(Path::new(path), Path::new(out_dir), &opts, &ctl);
        jobs().lock().unwrap().remove(&job_id);
        match r {
            Ok(o) => json!({
                "ok": true,
                "hmod_path": o.hmod_path.to_string_lossy(),
                "project_dir": o.project_dir.to_string_lossy(),
                "verdict": o.report.verdict(),
                "report": o.report,
                "report_markdown": o.report.to_markdown(),
            }),
            Err(e) => json!({"ok": false, "error": e.to_string()}),
        }
    }

    pub fn progress(job_id: i32) -> Value {
        match jobs().lock().unwrap().get(&job_id) {
            Some(j) => {
                let p = j.progress.lock().unwrap();
                json!({"running": true, "stage": p.0, "done": p.1, "total": p.2})
            }
            None => json!({"running": false}),
        }
    }

    pub fn cancel(job_id: i32) {
        if let Some(j) = jobs().lock().unwrap().get(&job_id) {
            j.cancel.store(true, Ordering::Relaxed);
        }
    }

    /// Analyze several jars and report cross-mod dependencies.
    pub fn deps(paths_json: &str) -> Value {
        let paths: Vec<String> = serde_json::from_str(paths_json).unwrap_or_default();
        let mut set = Vec::new();
        let mut errors = Vec::new();
        for p in &paths {
            match analyze_path(Path::new(p), hmc_core::Limits::default()) {
                Ok(a) => set.push(a),
                Err(e) => errors.push(json!({"path": p, "error": e.to_string()})),
            }
        }
        json!({"ok": true, "report": hmc_convert::batch::dependency_report(&set), "errors": errors})
    }

    pub fn selftest() -> Value {
        let items: Vec<Value> = hmc_convert::selftest().into_iter().map(|(n, ok, note)| json!({"name": n, "ok": ok, "note": note})).collect();
        json!({"ok": items.iter().all(|i| i["ok"] == true), "checks": items})
    }

    pub fn projects(root: &str) -> Value {
        let v: Vec<Value> = list_projects(Path::new(root))
            .into_iter()
            .map(|(dir, p)| json!({"dir": dir.to_string_lossy(), "mod_id": p.report.mod_id, "mod_name": p.report.mod_name, "created_unix": p.created_unix, "hmod_file": p.hmod_file, "verdict": p.report.verdict()}))
            .collect();
        json!({"projects": v})
    }

    pub fn delete(dir: &str) -> Value {
        match delete_project(Path::new(dir)) {
            Ok(()) => json!({"ok": true}),
            Err(e) => json!({"ok": false, "error": e.to_string()}),
        }
    }
}

fn guard(f: impl FnOnce() -> Value + std::panic::UnwindSafe) -> String {
    match std::panic::catch_unwind(f) {
        Ok(v) => v.to_string(),
        Err(_) => json!({"ok": false, "error": "internal error (panic) in conversion engine"}).to_string(),
    }
}

fn get(env: &mut JNIEnv, s: &JString) -> String {
    env.get_string(s).map(|s| s.into()).unwrap_or_default()
}

fn ret(env: &mut JNIEnv, s: String) -> jstring {
    env.new_string(s).map(|s| s.into_raw()).unwrap_or(std::ptr::null_mut())
}

#[no_mangle]
pub extern "system" fn Java_com_horizon_modconverter_NativeBridge_analyze(mut env: JNIEnv, _c: JClass, path: JString) -> jstring {
    let p = get(&mut env, &path);
    let s = guard(move || api::analyze(&p));
    ret(&mut env, s)
}

#[no_mangle]
pub extern "system" fn Java_com_horizon_modconverter_NativeBridge_convert(
    mut env: JNIEnv, _c: JClass, job: jint, path: JString, out: JString, opts: JString,
) -> jstring {
    let (p, o, op) = (get(&mut env, &path), get(&mut env, &out), get(&mut env, &opts));
    let s = guard(move || api::convert_job(job, &p, &o, &op));
    ret(&mut env, s)
}

#[no_mangle]
pub extern "system" fn Java_com_horizon_modconverter_NativeBridge_progress(mut env: JNIEnv, _c: JClass, job: jint) -> jstring {
    let s = guard(move || api::progress(job));
    ret(&mut env, s)
}

#[no_mangle]
pub extern "system" fn Java_com_horizon_modconverter_NativeBridge_cancel(_env: JNIEnv, _c: JClass, job: jint) {
    api::cancel(job);
}

#[no_mangle]
pub extern "system" fn Java_com_horizon_modconverter_NativeBridge_deps(mut env: JNIEnv, _c: JClass, paths: JString) -> jstring {
    let p = get(&mut env, &paths);
    let s = guard(move || api::deps(&p));
    ret(&mut env, s)
}

#[no_mangle]
pub extern "system" fn Java_com_horizon_modconverter_NativeBridge_selftest(mut env: JNIEnv, _c: JClass) -> jstring {
    let s = guard(api::selftest);
    ret(&mut env, s)
}

#[no_mangle]
pub extern "system" fn Java_com_horizon_modconverter_NativeBridge_projects(mut env: JNIEnv, _c: JClass, root: JString) -> jstring {
    let r = get(&mut env, &root);
    let s = guard(move || api::projects(&r));
    ret(&mut env, s)
}

#[no_mangle]
pub extern "system" fn Java_com_horizon_modconverter_NativeBridge_deleteProject(mut env: JNIEnv, _c: JClass, dir: JString) -> jstring {
    let d = get(&mut env, &dir);
    let s = guard(move || api::delete(&d));
    ret(&mut env, s)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn api_roundtrip() {
        let fx = format!("{}/../../../tests/fixtures/ruby-1.0.0.jar", env!("CARGO_MANIFEST_DIR"));
        let a = api::analyze(&fx);
        assert_eq!(a["ok"], true);
        let out = std::env::temp_dir().join(format!("hmc-ffi-{}", std::process::id()));
        let r = api::convert_job(7, &fx, out.to_str().unwrap(), "");
        assert_eq!(r["ok"], true, "{r}");
        assert_eq!(api::progress(7)["running"], false);
        let p = api::projects(out.to_str().unwrap());
        assert_eq!(p["projects"].as_array().unwrap().len(), 1);
        let d = p["projects"][0]["dir"].as_str().unwrap().to_string();
        assert_eq!(api::delete(&d)["ok"], true);
        assert_eq!(api::delete("/tmp")["ok"], false);
        assert_eq!(api::selftest()["ok"], true);
        assert_eq!(api::analyze("/nonexistent.jar")["ok"], false);
    }
}
