//! Mod metadata parsing and source version detection.
use hmc_core::{HmcError, Jar, Result};
use serde::{Deserialize, Serialize};
use std::io::{Read, Seek};

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum Loader {
    NeoForge,
    Forge,
    Fabric,
    Quilt,
    Unknown,
}

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum DepKind {
    Required,
    Optional,
    Incompatible,
    Discouraged,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Dependency {
    pub mod_id: String,
    pub kind: DepKind,
    pub version_range: Option<String>,
    pub side: String,
}

#[derive(Clone, Debug, Serialize, Deserialize, Default)]
pub struct Indicator {
    pub source: String,
    pub value: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ModMeta {
    pub loader: Loader,
    pub mod_id: String,
    pub version: String,
    pub display_name: String,
    pub description: String,
    pub authors: Vec<String>,
    pub license: String,
    pub dependencies: Vec<Dependency>,
    pub mixin_configs: Vec<String>,
    pub access_transformers: Vec<String>,
    /// All `[[mods]]` ids when a jar holds several (first is `mod_id`).
    pub all_mod_ids: Vec<String>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct VersionDetection {
    pub loader: Loader,
    pub minecraft: Option<String>,
    pub neoforge: Option<String>,
    pub indicators: Vec<Indicator>,
    /// Disagreeing indicators, reported rather than resolved silently.
    pub conflicts: Vec<String>,
    /// True only for NeoForge sources with a Minecraft version HMC has rules for.
    pub supported: bool,
    pub notes: Vec<String>,
}

/// Source versions HMC has migration rules for.
pub const SUPPORTED_SOURCE_MC: &[&str] = &["1.21.1"];

pub fn read_meta<R: Read + Seek>(jar: &mut Jar<R>) -> Result<ModMeta> {
    if jar.contains("META-INF/neoforge.mods.toml") {
        let s = jar.read_string("META-INF/neoforge.mods.toml")?;
        let mut m = parse_mods_toml(&s, Loader::NeoForge)?;
        fill_version_from_manifest(jar, &mut m);
        Ok(m)
    } else if jar.contains("META-INF/mods.toml") {
        let s = jar.read_string("META-INF/mods.toml")?;
        let mut m = parse_mods_toml(&s, Loader::Forge)?;
        fill_version_from_manifest(jar, &mut m);
        Ok(m)
    } else if jar.contains("fabric.mod.json") {
        let s = jar.read_string("fabric.mod.json")?;
        parse_fabric(&s)
    } else if jar.contains("quilt.mod.json") {
        Ok(ModMeta {
            loader: Loader::Quilt,
            mod_id: String::new(),
            version: String::new(),
            display_name: String::new(),
            description: String::new(),
            authors: vec![],
            license: String::new(),
            dependencies: vec![],
            mixin_configs: vec![],
            access_transformers: vec![],
            all_mod_ids: vec![],
        })
    } else {
        Err(HmcError::Unsupported("no mod metadata found (not a NeoForge/Forge/Fabric/Quilt mod)".into()))
    }
}

fn fill_version_from_manifest<R: Read + Seek>(jar: &mut Jar<R>, m: &mut ModMeta) {
    if m.version.contains("${") || m.version.is_empty() {
        if let Ok(mf) = jar.read_string("META-INF/MANIFEST.MF") {
            for line in mf.lines() {
                if let Some(v) = line.strip_prefix("Implementation-Version:") {
                    m.version = v.trim().to_string();
                    return;
                }
            }
        }
        if m.version.is_empty() {
            m.version = "0.0.0".into();
        }
    }
}

fn str_of(v: &toml::Value, k: &str) -> String {
    v.get(k).and_then(|x| x.as_str()).unwrap_or("").to_string()
}

pub fn parse_mods_toml(src: &str, loader: Loader) -> Result<ModMeta> {
    let root: toml::Value = src.parse().map_err(|e| HmcError::Parse(format!("mods.toml: {e}")))?;
    let mods = root
        .get("mods")
        .and_then(|m| m.as_array())
        .filter(|a| !a.is_empty())
        .ok_or_else(|| HmcError::Parse("mods.toml has no [[mods]] entry".into()))?;
    let all_mod_ids: Vec<String> = mods.iter().map(|m| str_of(m, "modId")).filter(|s| !s.is_empty()).collect();
    let first = &mods[0];
    let mod_id = all_mod_ids.first().cloned().ok_or_else(|| HmcError::Parse("[[mods]] without modId".into()))?;
    let authors = match first.get("authors") {
        Some(toml::Value::String(s)) => s.split(',').map(|a| a.trim().to_string()).filter(|a| !a.is_empty()).collect(),
        Some(toml::Value::Array(a)) => a.iter().filter_map(|x| x.as_str().map(String::from)).collect(),
        _ => match root.get("authors").and_then(|a| a.as_str()) {
            Some(s) => vec![s.to_string()],
            None => vec![],
        },
    };
    let mut dependencies = Vec::new();
    if let Some(deps) = root.get("dependencies").and_then(|d| d.as_table()) {
        if let Some(list) = deps.get(&mod_id).and_then(|l| l.as_array()) {
            for d in list {
                let id = str_of(d, "modId");
                if id.is_empty() {
                    continue;
                }
                let kind = match d.get("type").and_then(|t| t.as_str()) {
                    Some("optional") => DepKind::Optional,
                    Some("incompatible") => DepKind::Incompatible,
                    Some("discouraged") => DepKind::Discouraged,
                    Some(_) => DepKind::Required,
                    // Older format: `mandatory = true/false`.
                    None => match d.get("mandatory").and_then(|b| b.as_bool()) {
                        Some(false) => DepKind::Optional,
                        _ => DepKind::Required,
                    },
                };
                let range = d.get("versionRange").and_then(|r| r.as_str()).map(String::from);
                let side = d.get("side").and_then(|s| s.as_str()).unwrap_or("BOTH").to_string();
                dependencies.push(Dependency { mod_id: id, kind, version_range: range, side });
            }
        }
    }
    let mut mixin_configs = vec![];
    if let Some(a) = root.get("mixins").and_then(|m| m.as_array()) {
        for m in a {
            let c = str_of(m, "config");
            if !c.is_empty() {
                mixin_configs.push(c);
            }
        }
    }
    let mut access_transformers = vec![];
    if let Some(a) = root.get("accessTransformers").and_then(|m| m.as_array()) {
        for m in a {
            let c = str_of(m, "file");
            if !c.is_empty() {
                access_transformers.push(c);
            }
        }
    }
    Ok(ModMeta {
        loader,
        mod_id,
        version: str_of(first, "version"),
        display_name: {
            let n = str_of(first, "displayName");
            if n.is_empty() { all_mod_ids[0].clone() } else { n }
        },
        description: str_of(first, "description").trim().to_string(),
        authors,
        license: str_of(&root, "license"),
        dependencies,
        mixin_configs,
        access_transformers,
        all_mod_ids,
    })
}

pub fn parse_fabric(src: &str) -> Result<ModMeta> {
    let v: serde_json::Value = serde_json::from_str(src).map_err(|e| HmcError::Parse(format!("fabric.mod.json: {e}")))?;
    let s = |k: &str| v.get(k).and_then(|x| x.as_str()).unwrap_or("").to_string();
    let id = s("id");
    Ok(ModMeta {
        loader: Loader::Fabric,
        mod_id: id.clone(),
        version: s("version"),
        display_name: { let n = s("name"); if n.is_empty() { id.clone() } else { n } },
        description: s("description"),
        authors: vec![],
        license: String::new(),
        dependencies: vec![],
        mixin_configs: vec![],
        access_transformers: vec![],
        all_mod_ids: vec![id],
    })
}

/// Lower bound of a Maven version range ("[1.21,1.22)" -> "1.21"; "[21.1.0,)" -> "21.1.0").
/// Returns `(version, exact)` where exact means the range pins one version ("[1.21.1]").
pub fn range_lower(range: &str) -> Option<(String, bool)> {
    let r = range.trim();
    if r.is_empty() {
        return None;
    }
    let inner = r.trim_start_matches(['[', '(']).trim_end_matches([']', ')']);
    if !r.starts_with('[') && !r.starts_with('(') {
        return Some((r.to_string(), false)); // bare version = minimum
    }
    match inner.split_once(',') {
        None => Some((inner.trim().to_string(), r.starts_with('['))),
        Some((lo, _hi)) => {
            let lo = lo.trim();
            if lo.is_empty() { None } else { Some((lo.to_string(), false)) }
        }
    }
}

/// NeoForge 21.1.x targets Minecraft 1.21.1; 21.0.x targets 1.21; 20.4.x -> 1.20.4.
pub fn neoforge_to_minecraft(nf: &str) -> Option<String> {
    let mut it = nf.split('.');
    let major: u32 = it.next()?.parse().ok()?;
    let minor: u32 = it.next()?.parse().ok()?;
    if major < 20 {
        return None;
    }
    Some(if minor == 0 { format!("1.{major}") } else { format!("1.{major}.{minor}") })
}

pub fn detect_version<R: Read + Seek>(jar: &mut Jar<R>, meta: &ModMeta) -> VersionDetection {
    let mut ind = Vec::new();
    let mut notes = Vec::new();
    let mut mc: Option<String> = None;
    let mut nf: Option<String> = None;
    let mut candidates: Vec<(String, String)> = Vec::new(); // (source, mc version)

    for d in &meta.dependencies {
        let id = d.mod_id.as_str();
        let Some(range) = d.version_range.as_deref() else { continue };
        if id == "minecraft" {
            ind.push(Indicator { source: "dependency minecraft".into(), value: range.into() });
            if let Some((v, exact)) = range_lower(range) {
                if !exact {
                    notes.push(format!("minecraft range {range} is not exact; using lower bound {v}"));
                }
                candidates.push(("minecraft dependency range".into(), v.clone()));
                mc.get_or_insert(v);
            }
        } else if id == "neoforge" {
            ind.push(Indicator { source: "dependency neoforge".into(), value: range.into() });
            if let Some((v, _)) = range_lower(range) {
                if let Some(derived) = neoforge_to_minecraft(&v) {
                    candidates.push((format!("neoforge {v}"), derived));
                }
                nf = Some(v);
            }
        }
    }

    // pack.mcmeta: 1.21 / 1.21.1 use resource pack_format 34 and data pack_format 48.
    if let Ok(s) = jar.read_string("pack.mcmeta") {
        if let Ok(v) = serde_json::from_str::<serde_json::Value>(&s) {
            if let Some(pf) = v.pointer("/pack/pack_format").and_then(|x| x.as_i64()) {
                ind.push(Indicator { source: "pack.mcmeta pack_format".into(), value: pf.to_string() });
                if pf == 34 || pf == 48 {
                    candidates.push((format!("pack_format {pf}"), "1.21.x".into()));
                } else {
                    notes.push(format!("pack_format {pf} is not the 1.21/1.21.1 value (34 resources / 48 data)"));
                }
            }
        }
    }

    // Structure: 1.21 data packs use singular folders (recipe/, loot_table/, tags/block/).
    let plural = jar.entries.iter().any(|e| {
        e.name.contains("/recipes/") || e.name.contains("/loot_tables/") || e.name.contains("/tags/blocks/") || e.name.contains("/tags/items/")
    });
    let singular = jar.entries.iter().any(|e| {
        e.name.contains("/recipe/") || e.name.contains("/loot_table/") || e.name.contains("/tags/block/") || e.name.contains("/tags/item/")
    });
    if plural {
        ind.push(Indicator { source: "data layout".into(), value: "plural folders (pre-1.21)".into() });
        candidates.push(("data layout".into(), "pre-1.21".into()));
    } else if singular {
        ind.push(Indicator { source: "data layout".into(), value: "singular folders (1.21+)".into() });
    }

    let mut conflicts = Vec::new();
    let strong: Vec<&(String, String)> = candidates.iter().filter(|(_, v)| v != "1.21.x").collect();
    for w in strong.windows(2) {
        if w[0].1 != w[1].1 {
            conflicts.push(format!("{} says {} but {} says {}", w[0].0, w[0].1, w[1].0, w[1].1));
        }
    }
    // pack_format family check against concrete versions.
    if let (Some(v), true) = (&mc, candidates.iter().any(|(_, c)| c == "1.21.x")) {
        if !(v == "1.21" || v == "1.21.1") {
            conflicts.push(format!("pack_format indicates the 1.21/1.21.1 family but metadata says {v}"));
        }
    }

    let supported = matches!(meta.loader, Loader::NeoForge)
        && mc.as_deref().map(|v| SUPPORTED_SOURCE_MC.contains(&v)).unwrap_or(false)
        && conflicts.is_empty();
    if !matches!(meta.loader, Loader::NeoForge) {
        notes.push(format!("loader {:?} is not supported as a source", meta.loader));
    }
    VersionDetection { loader: meta.loader, minecraft: mc, neoforge: nf, indicators: ind, conflicts, supported, notes }
}

#[cfg(test)]
mod tests {
    use super::*;

    const TOML: &str = r#"
modLoader="javafml"
loaderVersion="[4,)"
license="MIT"
[[mods]]
modId="ruby"
version="${file.jarVersion}"
displayName="Ruby"
description='''A gem mod'''
authors="Ann, Bob"
[[mixins]]
config="ruby.mixins.json"
[[dependencies.ruby]]
modId="neoforge"
type="required"
versionRange="[21.1.0,)"
side="BOTH"
[[dependencies.ruby]]
modId="minecraft"
type="required"
versionRange="[1.21.1]"
side="BOTH"
[[dependencies.ruby]]
modId="jei"
type="optional"
versionRange="[19,)"
"#;

    #[test]
    fn parses_neoforge_toml() {
        let m = parse_mods_toml(TOML, Loader::NeoForge).unwrap();
        assert_eq!(m.mod_id, "ruby");
        assert_eq!(m.authors, vec!["Ann", "Bob"]);
        assert_eq!(m.dependencies.len(), 3);
        assert_eq!(m.dependencies[2].kind, DepKind::Optional);
        assert_eq!(m.mixin_configs, vec!["ruby.mixins.json"]);
    }

    #[test]
    fn ranges() {
        assert_eq!(range_lower("[1.21.1]"), Some(("1.21.1".into(), true)));
        assert_eq!(range_lower("[21.1.0,)"), Some(("21.1.0".into(), false)));
        assert_eq!(range_lower("[1.21,1.22)"), Some(("1.21".into(), false)));
    }

    #[test]
    fn nf_mapping() {
        assert_eq!(neoforge_to_minecraft("21.1.77").as_deref(), Some("1.21.1"));
        assert_eq!(neoforge_to_minecraft("21.0.5").as_deref(), Some("1.21"));
        assert_eq!(neoforge_to_minecraft("20.4.1").as_deref(), Some("1.20.4"));
    }

    #[test]
    fn conflict_detected() {
        use std::io::{Cursor, Write};
        let mut w = zip::ZipWriter::new(Cursor::new(Vec::new()));
        w.start_file("pack.mcmeta", zip::write::FileOptions::default()).unwrap();
        w.write_all(br#"{"pack":{"pack_format":34}}"#).unwrap();
        let bytes = w.finish().unwrap().into_inner();
        let mut jar = Jar::new(Cursor::new(bytes), hmc_core::Limits::default()).unwrap();
        let toml = TOML.replace("[1.21.1]", "[1.20.4]");
        let m = parse_mods_toml(&toml, Loader::NeoForge).unwrap();
        let d = detect_version(&mut jar, &m);
        assert!(!d.conflicts.is_empty(), "{:?}", d);
        assert!(!d.supported);
    }
}
