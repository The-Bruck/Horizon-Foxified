use crate::classfile::{Annotation, ClassInfo};
use serde::Serialize;
use std::collections::{BTreeMap, BTreeSet};

const MC_BLOCK: &str = "net/minecraft/world/level/block/Block";
const MC_ITEM: &str = "net/minecraft/world/item/Item";
const MC_BLOCK_ENTITY: &str = "net/minecraft/world/level/block/entity/BlockEntity";
const MC_ENTITY: &str = "net/minecraft/world/entity/Entity";
const MC_MENU: &str = "net/minecraft/world/inventory/AbstractContainerMenu";
const MC_SCREEN: &str = "net/minecraft/client/gui/screens/Screen";
const MC_BER: &str = "net/minecraft/client/renderer/blockentity/BlockEntityRenderer";
const MC_ER: &str = "net/minecraft/client/renderer/entity/EntityRenderer";
const MC_MODEL: &str = "net/minecraft/client/model/Model";
const MC_RECIPE: &str = "net/minecraft/world/item/crafting/Recipe";
const MC_RECIPE_SER: &str = "net/minecraft/world/item/crafting/RecipeSerializer";
const MC_FEATURE: &str = "net/minecraft/world/level/levelgen/feature/Feature";
const MC_STRUCTURE: &str = "net/minecraft/world/level/levelgen/structure/Structure";
const MC_EFFECT: &str = "net/minecraft/world/effect/MobEffect";
const MC_ENCHANT_EFFECT: &str = "net/minecraft/world/item/enchantment/effects/EnchantmentEntityEffect";

const SUBSCRIBE: &str = "Lnet/neoforged/bus/api/SubscribeEvent;";
const ANNO_MOD: &str = "Lnet/neoforged/fml/common/Mod;";
const ANNO_MIXIN: &str = "Lorg/spongepowered/asm/mixin/Mixin;";

#[derive(Clone, Debug, Serialize, PartialEq, Eq, PartialOrd, Ord)]
pub enum FeatureClass {
    Block,
    Item,
    BlockEntity,
    Entity,
    Menu,
    Screen,
    Renderer,
    CustomRecipe,
    Worldgen,
    MobEffect,
    EnchantmentEffect,
}

#[derive(Clone, Debug, Serialize)]
pub struct EventHandler {
    pub class: String,
    pub method: String,
    pub event_class: String,
    /// Suggested Horizon hook name following docs/native-hooks-neoforge.md rule 1.
    /// A suggestion for a human to review: not verified against native-hooks.json.
    pub suggested_hook: String,
}

#[derive(Clone, Debug, Default, Serialize)]
pub struct CodeFeatures {
    pub total_classes: usize,
    pub unparsable_classes: Vec<String>,
    pub mod_entry_points: Vec<(String, String)>,
    pub event_handlers: Vec<EventHandler>,
    /// Classes extending a Minecraft base class (transitively through the jar).
    pub classes: BTreeMap<String, Vec<(FeatureClass, bool)>>,
    pub mixin_classes: Vec<(String, Vec<String>)>,
    pub native_methods: Vec<String>,
    pub reflection_users: Vec<String>,
    pub networking_classes: Vec<String>,
    pub config_classes: Vec<String>,
    pub registry_classes: Vec<String>,
    pub capability_classes: Vec<String>,
    pub minecraft_refs: usize,
    pub neoforge_refs: usize,
    pub other_library_refs: BTreeSet<String>,
    /// Class dependency graph edges inside the jar: class -> in-jar classes it uses.
    pub graph: BTreeMap<String, Vec<String>>,
    /// All short string constants seen (candidates for registry names).
    pub strings: BTreeSet<String>,
}

/// Does the class declare behaviour beyond construction and codec plumbing?
fn has_behaviour(c: &ClassInfo) -> bool {
    c.methods.iter().any(|m| {
        !matches!(m.name.as_str(), "<init>" | "<clinit>" | "codec" | "$values" | "values" | "valueOf")
            && !m.name.starts_with("lambda$")
            && !m.name.starts_with("access$")
    })
}

fn bases() -> [(&'static str, FeatureClass); 14] {
    [
        (MC_BLOCK, FeatureClass::Block),
        (MC_ITEM, FeatureClass::Item),
        (MC_BLOCK_ENTITY, FeatureClass::BlockEntity),
        (MC_ENTITY, FeatureClass::Entity),
        (MC_MENU, FeatureClass::Menu),
        (MC_SCREEN, FeatureClass::Screen),
        (MC_BER, FeatureClass::Renderer),
        (MC_ER, FeatureClass::Renderer),
        (MC_MODEL, FeatureClass::Renderer),
        (MC_RECIPE, FeatureClass::CustomRecipe),
        (MC_RECIPE_SER, FeatureClass::CustomRecipe),
        (MC_FEATURE, FeatureClass::Worldgen),
        (MC_STRUCTURE, FeatureClass::Worldgen),
        (MC_EFFECT, FeatureClass::MobEffect),
    ]
}

/// Resolve what a class ultimately extends / implements. Vanilla classes that
/// merely *sit between* (BaseEntityBlock, LivingEntity, ...) are recognised by
/// well-known prefixes since the jar does not contain them.
fn mark(n: &str, out: &mut BTreeSet<FeatureClass>) {
    for (b, f) in bases() {
        if n == b {
            out.insert(f);
        }
    }
    match n {
        "net/minecraft/world/level/block/BaseEntityBlock" => {
            out.insert(FeatureClass::Block);
            out.insert(FeatureClass::BlockEntity);
        }
        "net/minecraft/world/entity/LivingEntity"
        | "net/minecraft/world/entity/Mob"
        | "net/minecraft/world/entity/PathfinderMob"
        | "net/minecraft/world/entity/animal/Animal"
        | "net/minecraft/world/entity/monster/Monster"
        | "net/minecraft/world/entity/projectile/Projectile"
        | "net/minecraft/world/entity/projectile/ThrowableItemProjectile" => {
            out.insert(FeatureClass::Entity);
        }
        "net/minecraft/client/gui/screens/inventory/AbstractContainerScreen" => {
            out.insert(FeatureClass::Screen);
        }
        "net/minecraft/client/model/EntityModel"
        | "net/minecraft/client/renderer/entity/LivingEntityRenderer"
        | "net/minecraft/client/renderer/entity/MobRenderer" => {
            out.insert(FeatureClass::Renderer);
        }
        MC_ENCHANT_EFFECT => {
            out.insert(FeatureClass::EnchantmentEffect);
        }
        _ => {}
    }
}

/// Resolve what a class ultimately extends / implements. Vanilla classes that
/// merely sit between (BaseEntityBlock, LivingEntity, ...) are recognised by
/// name since the jar does not contain them.
fn resolve(name: &str, by_name: &BTreeMap<&str, &ClassInfo>, depth: usize, out: &mut BTreeSet<FeatureClass>) {
    if depth > 32 {
        return;
    }
    if let Some(c) = by_name.get(name) {
        if let Some(s) = &c.super_name {
            mark(s, out);
            resolve(s, by_name, depth + 1, out);
        }
        for i in &c.interfaces {
            mark(i, out);
            resolve(i, by_name, depth + 1, out);
        }
    }
}

fn snake(s: &str) -> String {
    let mut out = String::new();
    for (i, ch) in s.chars().enumerate() {
        if ch.is_ascii_uppercase() {
            if i > 0 {
                out.push('_');
            }
            out.push(ch.to_ascii_lowercase());
        } else {
            out.push(ch);
        }
    }
    out
}

/// `net/neoforged/neoforge/event/tick/ServerTickEvent$Pre` -> `server_tick_pre`.
/// Rule 1 of docs/native-hooks-neoforge.md. Where the nested name alone is
/// meaningful (`RightClickBlock`) it is used alone, as the doc's example does.
pub fn suggest_hook(event_internal_name: &str) -> String {
    let simple = event_internal_name.rsplit('/').next().unwrap_or(event_internal_name);
    let mut parts = simple.split('$');
    let outer = parts.next().unwrap_or("");
    let outer = outer.strip_suffix("Event").unwrap_or(outer);
    let nested: Vec<&str> = parts.collect();
    match nested.as_slice() {
        [] => snake(outer),
        [n] if matches!(*n, "Pre" | "Post" | "Open" | "Close" | "Start" | "Stop") => format!("{}_{}", snake(outer), snake(n)),
        [n, ..] => snake(n),
    }
}

fn first_event_param(desc: &str) -> Option<String> {
    let inner = desc.strip_prefix('(')?;
    let first = inner.strip_prefix('L')?;
    let end = first.find(';')?;
    Some(first[..end].to_string())
}

fn is_annotated(list: &[Annotation], t: &str) -> bool {
    list.iter().any(|a| a.type_desc == t)
}

pub fn analyze(classes: &[ClassInfo], unparsable: Vec<String>) -> CodeFeatures {
    let by_name: BTreeMap<&str, &ClassInfo> = classes.iter().map(|c| (c.name.as_str(), c)).collect();
    let mut f = CodeFeatures { total_classes: classes.len() + unparsable.len(), unparsable_classes: unparsable, ..Default::default() };
    let mut mc = BTreeSet::new();
    let mut nf = BTreeSet::new();

    for c in classes {
        for a in &c.annotations {
            if a.type_desc == ANNO_MOD {
                f.mod_entry_points.push((c.name.clone(), a.values.first().cloned().unwrap_or_default()));
            }
            if a.type_desc == ANNO_MIXIN {
                f.mixin_classes.push((c.name.clone(), a.values.clone()));
            }
        }
        for m in &c.methods {
            if m.is_native() {
                f.native_methods.push(format!("{}.{}", c.name, m.name));
            }
            if is_annotated(&m.annotations, SUBSCRIBE) {
                if let Some(ev) = first_event_param(&m.desc) {
                    f.event_handlers.push(EventHandler {
                        class: c.name.clone(),
                        method: m.name.clone(),
                        suggested_hook: suggest_hook(&ev),
                        event_class: ev,
                    });
                }
            }
        }
        let mut kinds = BTreeSet::new();
        resolve(&c.name, &by_name, 0, &mut kinds);
        if !kinds.is_empty() {
            let b = has_behaviour(c);
            f.classes.entry(c.name.clone()).or_default().extend(kinds.into_iter().map(|k| (k, b)));
        }
        let mut deps = Vec::new();
        for r in &c.class_refs {
            if r.starts_with("net/minecraft/") {
                mc.insert(r.clone());
            } else if r.starts_with("net/neoforged/") {
                nf.insert(r.clone());
                if r.starts_with("net/neoforged/neoforge/network/") {
                    f.networking_classes.push(c.name.clone());
                }
                if r.contains("ModConfigSpec") || r.contains("/config/") && r.starts_with("net/neoforged/") {
                    f.config_classes.push(c.name.clone());
                }
                if r.starts_with("net/neoforged/neoforge/registries/") {
                    f.registry_classes.push(c.name.clone());
                }
                if r.starts_with("net/neoforged/neoforge/capabilities/") {
                    f.capability_classes.push(c.name.clone());
                }
            } else if by_name.contains_key(r.as_str()) {
                deps.push(r.clone());
            } else if !r.starts_with("java/") && !r.starts_with("javax/") && !r.starts_with("org/spongepowered/")
                && !r.starts_with("org/slf4j/") && !r.starts_with("com/mojang/") && !r.starts_with("it/unimi/")
                && !r.starts_with("com/google/") && !r.starts_with("org/apache/") && !r.starts_with("org/jetbrains/")
            {
                f.other_library_refs.insert(r.split('/').take(3).collect::<Vec<_>>().join("/"));
            }
        }
        if c.member_refs.iter().any(|m| m.starts_with("java/lang/reflect/") || m == "java/lang/Class.forName") {
            f.reflection_users.push(c.name.clone());
        }
        f.networking_classes.sort();
        f.networking_classes.dedup();
        f.config_classes.sort();
        f.config_classes.dedup();
        f.registry_classes.sort();
        f.registry_classes.dedup();
        f.capability_classes.sort();
        f.capability_classes.dedup();
        f.graph.insert(c.name.clone(), deps);
        f.strings.extend(c.strings.iter().cloned());
    }
    f.minecraft_refs = mc.len();
    f.neoforge_refs = nf.len();
    f
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn hook_names() {
        assert_eq!(suggest_hook("net/neoforged/neoforge/event/tick/ServerTickEvent$Pre"), "server_tick_pre");
        assert_eq!(suggest_hook("net/neoforged/neoforge/event/entity/player/PlayerInteractEvent$RightClickBlock"), "right_click_block");
        assert_eq!(suggest_hook("net/neoforged/neoforge/event/entity/living/LivingDeathEvent"), "living_death");
    }
    #[test]
    fn event_param() {
        assert_eq!(first_event_param("(Lfoo/BarEvent;)V").as_deref(), Some("foo/BarEvent"));
        assert_eq!(first_event_param("()V"), None);
    }
    fn cls(name: &str, sup: &str, methods: &[&str]) -> ClassInfo {
        ClassInfo {
            name: name.into(), super_name: Some(sup.into()), interfaces: vec![], access: 1, fields: vec![],
            methods: methods.iter().map(|m| crate::MethodInfo { name: (*m).into(), desc: "()V".into(), access: 1, annotations: vec![] }).collect(),
            annotations: vec![], class_refs: Default::default(), member_refs: Default::default(), strings: Default::default(),
        }
    }
    #[test]
    fn transitive_block_entity() {
        let a = cls("m/Base", "net/minecraft/world/level/block/BaseEntityBlock", &["<init>"]);
        let b = cls("m/Machine", "m/Base", &["<init>", "use"]);
        let f = analyze(&[a, b], vec![]);
        let kinds = &f.classes["m/Machine"];
        assert!(kinds.iter().any(|(k, beh)| *k == FeatureClass::Block && *beh));
        assert!(kinds.iter().any(|(k, _)| *k == FeatureClass::BlockEntity));
        assert!(!f.classes["m/Base"].iter().any(|(_, beh)| *beh));
    }
}
