//! Static Java class-file analysis. Never executes imported code.
mod classfile;
mod features;

pub use classfile::{parse_class, Annotation, ClassInfo, MethodInfo};
pub use features::{analyze, CodeFeatures, EventHandler, FeatureClass};
