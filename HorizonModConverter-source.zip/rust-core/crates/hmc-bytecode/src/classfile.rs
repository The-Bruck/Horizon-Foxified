use hmc_core::{HmcError, Result};
use serde::Serialize;
use std::collections::BTreeSet;

#[derive(Clone, Debug, Serialize)]
pub struct Annotation {
    /// Descriptor form, e.g. `Lnet/neoforged/bus/api/SubscribeEvent;`.
    pub type_desc: String,
    /// String and class-literal element values (bounded).
    pub values: Vec<String>,
}

#[derive(Clone, Debug, Serialize)]
pub struct MethodInfo {
    pub name: String,
    pub desc: String,
    pub access: u16,
    pub annotations: Vec<Annotation>,
}

impl MethodInfo {
    pub fn is_native(&self) -> bool {
        self.access & 0x0100 != 0
    }
    pub fn is_static(&self) -> bool {
        self.access & 0x0008 != 0
    }
}

#[derive(Clone, Debug, Serialize)]
pub struct ClassInfo {
    pub name: String,
    pub super_name: Option<String>,
    pub interfaces: Vec<String>,
    pub access: u16,
    pub fields: Vec<(String, String)>,
    pub methods: Vec<MethodInfo>,
    pub annotations: Vec<Annotation>,
    /// Every class named in the constant pool (dependency graph edges).
    pub class_refs: BTreeSet<String>,
    /// `owner.name` of every method/field reference.
    pub member_refs: BTreeSet<String>,
    /// String constants (<= 64 chars, bounded count): registry names, ids.
    pub strings: BTreeSet<String>,
}

struct Cur<'a> {
    b: &'a [u8],
    p: usize,
}

impl<'a> Cur<'a> {
    fn need(&self, n: usize) -> Result<()> {
        if self.p.checked_add(n).map(|e| e <= self.b.len()).unwrap_or(false) {
            Ok(())
        } else {
            Err(HmcError::Parse("truncated class file".into()))
        }
    }
    fn u8(&mut self) -> Result<u8> {
        self.need(1)?;
        let v = self.b[self.p];
        self.p += 1;
        Ok(v)
    }
    fn u16(&mut self) -> Result<u16> {
        self.need(2)?;
        let v = u16::from_be_bytes([self.b[self.p], self.b[self.p + 1]]);
        self.p += 2;
        Ok(v)
    }
    fn u32(&mut self) -> Result<u32> {
        self.need(4)?;
        let v = u32::from_be_bytes([self.b[self.p], self.b[self.p + 1], self.b[self.p + 2], self.b[self.p + 3]]);
        self.p += 4;
        Ok(v)
    }
    fn skip(&mut self, n: usize) -> Result<()> {
        self.need(n)?;
        self.p += n;
        Ok(())
    }
    fn bytes(&mut self, n: usize) -> Result<&'a [u8]> {
        self.need(n)?;
        let s = &self.b[self.p..self.p + n];
        self.p += n;
        Ok(s)
    }
}

#[derive(Clone)]
enum Cp {
    Empty,
    Utf8(String),
    Class(u16),
    Str(u16),
    Ref(u16, u16), // field/method/imethod: class idx, nat idx
    Nat(u16),
    Other,
}

struct Pool(Vec<Cp>);
impl Pool {
    fn utf8(&self, i: u16) -> Option<&str> {
        match self.0.get(i as usize) {
            Some(Cp::Utf8(s)) => Some(s),
            _ => None,
        }
    }
    fn class_name(&self, i: u16) -> Option<&str> {
        match self.0.get(i as usize) {
            Some(Cp::Class(n)) => self.utf8(*n),
            _ => None,
        }
    }
}

const MAX_STRINGS: usize = 4000;

pub fn parse_class(data: &[u8]) -> Result<ClassInfo> {
    let mut c = Cur { b: data, p: 0 };
    if c.u32()? != 0xCAFE_BABE {
        return Err(HmcError::Parse("bad class magic".into()));
    }
    c.skip(4)?; // minor, major
    let count = c.u16()? as usize;
    let mut pool = Pool(vec![Cp::Empty; count.max(1)]);
    let mut i = 1;
    while i < count {
        let tag = c.u8()?;
        let e = match tag {
            1 => {
                let len = c.u16()? as usize;
                Cp::Utf8(String::from_utf8_lossy(c.bytes(len)?).into_owned())
            }
            3 | 4 => {
                c.skip(4)?;
                Cp::Other
            }
            5 | 6 => {
                c.skip(8)?;
                pool.0[i] = Cp::Other;
                i += 1; // takes two slots
                Cp::Empty
            }
            7 => Cp::Class(c.u16()?),
            8 => Cp::Str(c.u16()?),
            9 | 10 | 11 => {
                let a = c.u16()?;
                let b = c.u16()?;
                Cp::Ref(a, b)
            }
            12 => {
                let a = c.u16()?;
                c.skip(2)?;
                Cp::Nat(a)
            }
            15 => {
                c.skip(3)?;
                Cp::Other
            }
            16 | 19 | 20 => {
                c.skip(2)?;
                Cp::Other
            }
            17 | 18 => {
                c.skip(4)?;
                Cp::Other
            }
            t => return Err(HmcError::Parse(format!("unknown constant pool tag {t}"))),
        };
        if i < pool.0.len() {
            pool.0[i] = e;
        }
        i += 1;
    }

    let access = c.u16()?;
    let this_idx = c.u16()?;
    let super_idx = c.u16()?;
    let name = pool.class_name(this_idx).ok_or_else(|| HmcError::Parse("bad this_class".into()))?.to_string();
    let super_name = if super_idx == 0 { None } else { pool.class_name(super_idx).map(String::from) };
    let ic = c.u16()? as usize;
    let mut interfaces = Vec::with_capacity(ic);
    for _ in 0..ic {
        let idx = c.u16()?;
        if let Some(n) = pool.class_name(idx) {
            interfaces.push(n.to_string());
        }
    }

    let mut fields = Vec::new();
    let fc = c.u16()? as usize;
    for _ in 0..fc {
        c.skip(2)?;
        let n = c.u16()?;
        let d = c.u16()?;
        skip_attrs(&mut c)?;
        fields.push((pool.utf8(n).unwrap_or("").to_string(), pool.utf8(d).unwrap_or("").to_string()));
    }

    let mc = c.u16()? as usize;
    let mut methods = Vec::with_capacity(mc);
    for _ in 0..mc {
        let acc = c.u16()?;
        let n = c.u16()?;
        let d = c.u16()?;
        let annotations = read_attrs_annotations(&mut c, &pool)?;
        methods.push(MethodInfo {
            name: pool.utf8(n).unwrap_or("").to_string(),
            desc: pool.utf8(d).unwrap_or("").to_string(),
            access: acc,
            annotations,
        });
    }
    let annotations = read_attrs_annotations(&mut c, &pool)?;

    let mut class_refs = BTreeSet::new();
    let mut member_refs = BTreeSet::new();
    let mut strings = BTreeSet::new();
    for e in &pool.0 {
        match e {
            Cp::Class(n) => {
                if let Some(s) = pool.utf8(*n) {
                    if !s.starts_with('[') {
                        class_refs.insert(s.to_string());
                    }
                }
            }
            Cp::Ref(ci, nat) => {
                if let (Some(owner), Some(Cp::Nat(n))) = (pool.class_name(*ci), pool.0.get(*nat as usize)) {
                    if let Some(m) = pool.utf8(*n) {
                        if member_refs.len() < 20_000 {
                            member_refs.insert(format!("{owner}.{m}"));
                        }
                    }
                }
            }
            Cp::Str(u) => {
                if let Some(s) = pool.utf8(*u) {
                    if s.len() <= 64 && strings.len() < MAX_STRINGS {
                        strings.insert(s.to_string());
                    }
                }
            }
            _ => {}
        }
    }
    // Types that appear only in field/method descriptors are not Class constants.
    for d in fields.iter().map(|f| f.1.as_str()).chain(methods.iter().map(|m| m.desc.as_str())) {
        let mut rest = d;
        while let Some(i) = rest.find('L') {
            let after = &rest[i + 1..];
            match after.find(';') {
                Some(j) if !after[..j].contains(['(', ')', '[']) => {
                    class_refs.insert(after[..j].to_string());
                    rest = &after[j + 1..];
                }
                _ => rest = after,
            }
        }
    }
    class_refs.remove(&name);
    Ok(ClassInfo { name, super_name, interfaces, access, fields, methods, annotations, class_refs, member_refs, strings })
}

fn skip_attrs(c: &mut Cur) -> Result<()> {
    let n = c.u16()?;
    for _ in 0..n {
        c.skip(2)?;
        let len = c.u32()? as usize;
        c.skip(len)?;
    }
    Ok(())
}

fn read_attrs_annotations(c: &mut Cur, pool: &Pool) -> Result<Vec<Annotation>> {
    let n = c.u16()?;
    let mut out = Vec::new();
    for _ in 0..n {
        let name_idx = c.u16()?;
        let len = c.u32()? as usize;
        let body = c.bytes(len)?;
        if pool.utf8(name_idx) == Some("RuntimeVisibleAnnotations") {
            let mut sub = Cur { b: body, p: 0 };
            // Malformed annotation bodies are ignored, not fatal.
            if let Ok(a) = read_annotations(&mut sub, pool) {
                out.extend(a);
            }
        }
    }
    Ok(out)
}

fn read_annotations(c: &mut Cur, pool: &Pool) -> Result<Vec<Annotation>> {
    let n = c.u16()?;
    let mut out = Vec::new();
    for _ in 0..n {
        out.push(read_annotation(c, pool, 0)?);
    }
    Ok(out)
}

fn read_annotation(c: &mut Cur, pool: &Pool, depth: u8) -> Result<Annotation> {
    if depth > 6 {
        return Err(HmcError::Parse("annotation nesting too deep".into()));
    }
    let t = c.u16()?;
    let pairs = c.u16()?;
    let mut values = Vec::new();
    for _ in 0..pairs {
        c.skip(2)?;
        read_element(c, pool, depth, &mut values)?;
    }
    Ok(Annotation { type_desc: pool.utf8(t).unwrap_or("").to_string(), values })
}

fn read_element(c: &mut Cur, pool: &Pool, depth: u8, out: &mut Vec<String>) -> Result<()> {
    if depth > 6 {
        return Err(HmcError::Parse("annotation nesting too deep".into()));
    }
    let tag = c.u8()?;
    match tag {
        b's' => {
            let i = c.u16()?;
            if out.len() < 32 {
                if let Some(s) = pool.utf8(i) {
                    out.push(s.to_string());
                }
            }
        }
        b'c' => {
            let i = c.u16()?;
            if out.len() < 32 {
                if let Some(s) = pool.utf8(i) {
                    out.push(s.to_string());
                }
            }
        }
        b'B' | b'C' | b'D' | b'F' | b'I' | b'J' | b'S' | b'Z' => c.skip(2)?,
        b'e' => c.skip(4)?,
        b'@' => {
            let a = read_annotation(c, pool, depth + 1)?;
            out.extend(a.values);
        }
        b'[' => {
            let n = c.u16()?;
            for _ in 0..n {
                read_element(c, pool, depth + 1, out)?;
            }
        }
        t => return Err(HmcError::Parse(format!("bad element tag {t}"))),
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Hand-assembled minimal class: `public class a/B extends java/lang/Object`.
    pub fn minimal() -> Vec<u8> {
        let mut v = vec![0xCA, 0xFE, 0xBA, 0xBE, 0, 0, 0, 65];
        let utf = |s: &str| {
            let mut o = vec![1u8];
            o.extend((s.len() as u16).to_be_bytes());
            o.extend(s.as_bytes());
            o
        };
        // 1 utf8 a/B, 2 class->1, 3 utf8 java/lang/Object, 4 class->3
        v.extend(5u16.to_be_bytes());
        v.extend(utf("a/B"));
        v.extend([7, 0, 1]);
        v.extend(utf("java/lang/Object"));
        v.extend([7, 0, 3]);
        v.extend(0x0021u16.to_be_bytes());
        v.extend(2u16.to_be_bytes());
        v.extend(4u16.to_be_bytes());
        v.extend([0, 0, 0, 0, 0, 0, 0, 0]); // interfaces, fields, methods, attributes
        v
    }

    #[test]
    fn parses_minimal() {
        let c = parse_class(&minimal()).unwrap();
        assert_eq!(c.name, "a/B");
        assert_eq!(c.super_name.as_deref(), Some("java/lang/Object"));
        assert!(c.class_refs.contains("java/lang/Object"));
    }

    #[test]
    fn rejects_garbage_without_panic() {
        assert!(parse_class(&[]).is_err());
        assert!(parse_class(&[0xCA, 0xFE, 0xBA, 0xBE]).is_err());
        let mut m = minimal();
        m.truncate(m.len() - 5);
        assert!(parse_class(&m).is_err());
        // every prefix must fail cleanly
        let full = minimal();
        for n in 0..full.len() {
            let _ = parse_class(&full[..n]);
        }
    }
}
