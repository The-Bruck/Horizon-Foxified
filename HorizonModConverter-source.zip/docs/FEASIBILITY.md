# Technical feasibility report (Milestone 1)

Sources read: `horizon-rust/horizon` at commit `83ad384f48d0742746d518737511882680aab5b7`
(docs/mods.md, docs/modpacks.md, docs/native-mods.md, docs/native-hooks-neoforge.md, docs/api/mod-files.md,
crates/horizon-mods, crates/cargo-horizon-mod, native-hooks.json), read on 2026-11-04.

## What Horizon actually accepts
| Format | What it is | Can HMC produce it? |
|---|---|---|
| `.hmod` content mod | zip: `horizon-mod.toml` + `assets/` + `data/`; no code | **Yes.** This is HMC's main output. |
| `.hnmod` native mod | zip: `horizon-native.json` + `mixins/<id>/` (horizon-mixins bundle). The launcher compiles it into the game on the player's PC | **No.** It needs injections hand-written against the hook catalog, a pinned Horizon commit, and the PC launcher's build. HMC emits a clearly-labelled porting scaffold instead. |

Java mod jars do not run in Horizon (docs/mods.md). Only the data and assets inside a jar carry over.

## Consequences for the requested spec
- NeoForge Java logic -> Rust cannot be translated automatically. HMC detects it, classifies it, maps event
  handlers to real catalog hooks where one exists, and generates stubs. It never claims otherwise.
- Block and item registrations live in Java. HMC observes them through blockstates and item models and declares
  them from vanilla templates. Hardness, light, sounds, stack size, tool/food behaviour are NOT read (reported as partial).
- Android cannot build `.hnmod` (launcher-side, PC).
- Entities, networking, capabilities, custom recipe types, Mixins, custom renderers: no content-mod representation
  today (docs/modpacks.md roadmap). Reported as unsupported.

## Conversion compatibility matrix
See `COMPATIBILITY.md` and `hmc rules` (machine-readable migration rule table with source, target, logic, validation, limitations).
