# Building

## Rust engine + CLI (any desktop)
    cd rust-core && cargo test --workspace && cargo build --release -p hmc-cli
    ./target/release/hmc convert mod.jar --out out/        # writes out/<id>/<id>.hmod, report.md, project.json
    ./target/release/hmc analyze mod.jar --json
    ./target/release/hmc selftest

Rust >= 1.75 works (the workspace was developed on 1.99). Optional authoritative check:
build `cargo-horizon-mod` from github.com/horizon-rust/horizon and run tests with `HORIZON_MOD_CHECK=/path/to/it`.

## Android APK
Requirements: JDK 17, Android SDK + NDK, `rustup target add aarch64-linux-android`, `cargo install cargo-ndk`.

    cd android && ANDROID_NDK_HOME=/path/to/ndk ./gradlew assembleDebug assembleRelease

Output: `android/app/build/outputs/apk/{debug,release}/`. The release build is signed with the debug key unless you
configure your own keystore. GitHub Actions (`.github/workflows/android.yml`) builds both and uploads them.

## Rebuilding the test fixture
    python3 tests/fixtures/make_fixture.py tests/fixtures/ruby-1.0.0.jar     # needs javac
