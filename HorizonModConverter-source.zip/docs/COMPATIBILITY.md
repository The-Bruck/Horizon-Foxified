# Compatibility

Target: Horizon 26.3 content mods (API 0.2). Source: NeoForge 1.21.1 (others are refused unless overridden).

| Feature | Result | Notes |
|---|---|---|
| Textures (PNG) | Converted | structure + CRCs verified; invalid files skipped and listed |
| Models, blockstates, lang, sounds, particles, atlases | Converted | carried unchanged, JSON parsed; models' geometry not re-validated |
| Item definitions (1.21.4+) | Converted | generated from `models/item` |
| Recipes (vanilla types) | Converted | ingredient/result shapes rewritten; custom types, `neoforge:` ingredients and conditions skipped + listed |
| Loot tables, tags | Converted | skipped if they use `neoforge:`/`forge:` types or conditions |
| Blocks | Partial | declared from blockstates with a vanilla template; Java-defined numbers/behaviour not read |
| Items | Partial | plain items; Java-defined behaviour not read |
| Worldgen/structures | Partial, opt-in | only the documented block-state rewrite; unvalidated |
| Event handlers | Manual | mapped to a catalog hook when one exists (offline snapshot of native-hooks.json) |
| Block entities, menus, screens, config, mob effects | Manual | native mod needed (PC build) |
| Mixins, entities, renderers, networking, capabilities, custom recipe types, JarJar | Unsupported | |

## What "validated" means
HMC re-reads each produced `.hmod` and checks the rules in Horizon's docs/api/mod-files.md and docs/mods.md
(paths, namespace fence, manifest keys, declaration keys, JSON, limits). In this repository's tests the output is
also accepted by Horizon's own `cargo horizon-mod check` (built from horizon-rust/horizon). HMC has not been run
against a live Horizon client: that is not possible in CI.
