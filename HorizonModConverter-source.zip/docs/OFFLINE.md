# Offline operation
- The APK declares no `INTERNET` permission (see AndroidManifest.xml), so it cannot reach the network.
- Files are chosen through the Storage Access Framework; no storage permissions are requested.
- Everything needed is bundled: migration rules, adapters, and an offline snapshot of Horizon's hook catalog
  (`crates/hmc-convert/resources/horizon_hooks.json`, from commit 83ad384f). Hook names can go stale as Horizon
  evolves; rebuild the snapshot with a newer HMC release.
- Imported jars are never modified, executed or uploaded; temporary copies are deleted after conversion.
