# Horizon Mod Converter (HMC)

Offline converter from **NeoForge 1.21.1** mod jars to **Horizon 26.3** content mods (`.hmod`), with an Android app
(Kotlin/Compose + JNI) over a Rust engine.

**Status, honestly**
- Rust engine, CLI, JNI API layer: implemented and tested (`cargo test --workspace`), including a real compiled test mod
  and Horizon's own `cargo horizon-mod check` accepting the output.
- The JNI crate type-checks for `aarch64-linux-android`.
- The Android UI (Kotlin) and Gradle build were written but **not compiled or run** where this was authored (no Android SDK).
  CI (`.github/workflows/build.yml`) is set up to build the APKs; expect to fix compile errors on first run.
- No APK is shipped in this repository.
- Not possible by design: automatic Java->Rust translation, building `.hnmod` on a phone. See `docs/FEASIBILITY.md`.

Docs: `docs/FEASIBILITY.md`, `docs/COMPATIBILITY.md`, `docs/BUILDING.md`, `docs/OFFLINE.md`.
