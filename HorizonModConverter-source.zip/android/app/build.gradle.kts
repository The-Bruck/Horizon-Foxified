plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.horizon.modconverter"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.horizon.modconverter"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // CI signs with a keystore from secrets; locally this falls back to the debug key so the
            // release APK is installable. Replace for real distribution.
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    sourceSets["main"].jniLibs.srcDir(layout.buildDirectory.dir("rustJniLibs"))
}

// Builds the Rust engine for arm64 with cargo-ndk (requires: rustup target add aarch64-linux-android,
// cargo install cargo-ndk, and ANDROID_NDK_HOME). See docs/BUILDING.md.
val buildRust = tasks.register<Exec>("buildRust") {
    val profile = if (gradle.startParameter.taskNames.any { it.contains("Release", ignoreCase = true) }) "--release" else ""
    workingDir = file("../../rust-core")
    val out = layout.buildDirectory.dir("rustJniLibs").get().asFile
    commandLine(
        listOf("cargo", "ndk", "-t", "arm64-v8a", "-o", out.absolutePath, "build", "-p", "hmc-ffi") +
            (if (profile.isNotEmpty()) listOf(profile) else emptyList())
    )
}
tasks.matching { it.name.startsWith("merge") && it.name.endsWith("JniLibFolders") }.configureEach { dependsOn(buildRust) }

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.03")
    implementation(composeBom)
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.navigation:navigation-compose:2.8.2")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("androidx.core:core-ktx:1.13.1")
}
