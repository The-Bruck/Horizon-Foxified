package com.horizon.modconverter

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.workDataOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class Imported(val id: Int, val name: String, val path: String, val analysis: JSONObject?, val error: String?)
data class JobUi(val importId: Int, val name: String, val workId: UUID, val state: String, val stage: String, val done: Long, val total: Long, val message: String)
data class ProjectUi(val dir: String, val modId: String, val name: String, val created: Long, val hmod: String, val verdict: String)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("hmc", 0)
    val projectsRoot = File(app.filesDir, "projects").apply { mkdirs() }
    private val importDir = File(app.cacheDir, "imports").apply { mkdirs() }
    private var nextId = 1

    val imports = mutableStateListOf<Imported>()
    val jobs = mutableStateMapOf<Int, JobUi>()
    val projects = mutableStateListOf<ProjectUi>()
    val selfTest = mutableStateOf<JSONObject?>(null)
    val dependencyReport = mutableStateOf<JSONObject?>(null)

    var workers: Int
        get() = prefs.getInt("workers", 2)
        set(v) { prefs.edit().putInt("workers", v.coerceIn(1, 4)).apply() }
    var carryWorldgen: Boolean
        get() = prefs.getBoolean("worldgen", false)
        set(v) { prefs.edit().putBoolean("worldgen", v).apply() }
    var creativeTab: Boolean
        get() = prefs.getBoolean("tab", true)
        set(v) { prefs.edit().putBoolean("tab", v).apply() }
    var overrideSource: Boolean
        get() = prefs.getBoolean("override", false)
        set(v) { prefs.edit().putBoolean("override", v).apply() }

    init {
        refreshProjects()
        viewModelScope.launch(Dispatchers.Default) { selfTest.value = NativeBridge.runSelfTest() }
        // Temp copies from an earlier interrupted run are never needed again.
        importDir.listFiles()?.forEach { it.delete() }
    }

    fun refreshProjects() {
        viewModelScope.launch(Dispatchers.IO) {
            val arr = NativeBridge.listProjects(projectsRoot.absolutePath).getJSONArray("projects")
            val list = (0 until arr.length()).map { arr.getJSONObject(it) }.map {
                ProjectUi(it.getString("dir"), it.getString("mod_id"), it.getString("mod_name"), it.getLong("created_unix"), it.getString("hmod_file"), it.getString("verdict"))
            }
            withContext(Dispatchers.Main) { projects.clear(); projects.addAll(list) }
        }
    }

    /** Copies picked files (Storage Access Framework) into app cache, streaming, then analyzes them. */
    fun importUris(uris: List<Uri>) {
        val cr = getApplication<Application>().contentResolver
        viewModelScope.launch(Dispatchers.IO) {
            for (u in uris) {
                val id = nextId++
                val name = cr.query(u, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (c.moveToFirst() && i >= 0) c.getString(i) else null
                } ?: "mod-$id.jar"
                val dest = File(importDir, "$id-${name.replace(Regex("[^A-Za-z0-9._-]"), "_")}")
                try {
                    cr.openInputStream(u)!!.use { inp -> dest.outputStream().use { inp.copyTo(it) } }
                    val r = NativeBridge.analyzeJar(dest.absolutePath)
                    val item = if (r.optBoolean("ok")) Imported(id, name, dest.absolutePath, r.getJSONObject("analysis"), null)
                    else Imported(id, name, dest.absolutePath, null, r.optString("error"))
                    withContext(Dispatchers.Main) { imports.add(item) }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) { imports.add(Imported(id, name, dest.absolutePath, null, e.message ?: "import failed")) }
                }
            }
            val ok = imports.filter { it.analysis != null }.map { it.path }
            if (ok.size > 1) dependencyReport.value = NativeBridge.dependencyReport(ok)
        }
    }

    fun remove(i: Imported) { File(i.path).delete(); imports.remove(i) }

    private fun options() = JSONObject()
        .put("carry_worldgen", carryWorldgen).put("generate_creative_tab", creativeTab).put("override_source", overrideSource)

    /** One WorkManager job per mod; `lane` (index % workers) chains jobs so at most `workers` run at once. */
    fun convert(items: List<Imported>) {
        val wm = WorkManager.getInstance(getApplication())
        items.filter { it.analysis != null }.forEachIndexed { idx, item ->
            // The worker deletes its temp copy, so hand it a private one.
            val copy = File(importDir, "job-${item.id}-${System.nanoTime()}.jar")
            File(item.path).copyTo(copy, overwrite = true)
            val req = OneTimeWorkRequestBuilder<ConversionWorker>().setInputData(
                workDataOf("job" to item.id, "path" to copy.absolutePath, "out" to projectsRoot.absolutePath, "name" to item.name, "options" to options().toString())
            ).build()
            wm.enqueueUniqueWork("lane-${idx % workers}", ExistingWorkPolicy.APPEND_OR_REPLACE, req)
            jobs[item.id] = JobUi(item.id, item.name, req.id, "QUEUED", "", 0, 0, "")
            viewModelScope.launch {
                wm.getWorkInfoByIdFlow(req.id).collect { info ->
                    if (info == null) return@collect
                    val p = info.progress
                    jobs[item.id] = JobUi(item.id, item.name, req.id, info.state.name, p.getString("stage") ?: "", p.getLong("done", 0), p.getLong("total", 0),
                        info.outputData.getString("error") ?: info.outputData.getString("verdict") ?: "")
                    if (info.state.isFinished) { refreshProjects() }
                }
            }
        }
    }

    fun cancel(importId: Int) {
        val j = jobs[importId] ?: return
        WorkManager.getInstance(getApplication()).cancelWorkById(j.workId)
    }

    fun deleteProject(p: ProjectUi) {
        viewModelScope.launch(Dispatchers.IO) { NativeBridge.removeProject(p.dir); refreshProjects() }
    }

    fun readReport(p: ProjectUi): String = runCatching { File(p.dir, "report.md").readText() }.getOrDefault("report missing")

    /** Copy a produced .hmod to a user-chosen location (SAF document). */
    fun exportTo(p: ProjectUi, dest: Uri) {
        val cr = getApplication<Application>().contentResolver
        viewModelScope.launch(Dispatchers.IO) {
            File(p.dir, p.hmod).inputStream().use { i -> cr.openOutputStream(dest)!!.use { i.copyTo(it) } }
        }
    }
}
