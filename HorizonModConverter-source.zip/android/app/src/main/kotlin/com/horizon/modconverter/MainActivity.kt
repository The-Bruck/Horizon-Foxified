package com.horizon.modconverter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import kotlinx.coroutines.launch

enum class Screen(val title: String) {
    Dashboard("Dashboard"), Convert("Convert Mods"), Batch("Batch Conversion"), Analyzer("Mod Analyzer"),
    History("Conversion History"), Projects("Projects"), Editor("Rust Code Editor"),
    Compatibility("Compatibility"), Settings("Settings"), About("About")
}

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface { App(vm) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: MainViewModel) {
    var screen by remember { mutableStateOf(Screen.Dashboard) }
    var editorProject by remember { mutableStateOf<ProjectUi?>(null) }
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                Text("Horizon Mod Converter", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(16.dp))
                Screen.values().forEach { s ->
                    NavigationDrawerItem(label = { Text(s.title) }, selected = s == screen, onClick = { screen = s; scope.launch { drawer.close() } })
                }
            }
        }
    ) {
        Scaffold(topBar = {
            TopAppBar(title = { Text(screen.title) }, navigationIcon = {
                IconButton(onClick = { scope.launch { drawer.open() } }) { Icon(Icons.Default.Menu, "Menu") }
            })
        }) { pad ->
            val m = Modifier.padding(pad)
            when (screen) {
                Screen.Dashboard -> DashboardScreen(vm, m) { screen = it }
                Screen.Convert -> ConvertScreen(vm, m, batch = false)
                Screen.Batch -> ConvertScreen(vm, m, batch = true)
                Screen.Analyzer -> AnalyzerScreen(vm, m)
                Screen.History, Screen.Projects -> ProjectsScreen(vm, m, history = screen == Screen.History) { p -> editorProject = p; screen = Screen.Editor }
                Screen.Editor -> EditorScreen(vm, editorProject, m)
                Screen.Compatibility -> CompatibilityScreen(vm, m)
                Screen.Settings -> SettingsScreen(vm, m)
                Screen.About -> AboutScreen(m)
            }
        }
    }
}
