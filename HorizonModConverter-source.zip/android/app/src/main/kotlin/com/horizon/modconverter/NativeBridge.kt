package com.horizon.modconverter

import org.json.JSONObject

/** JNI bridge to the Rust engine (rust-core/crates/hmc-ffi). Every call exchanges JSON. */
object NativeBridge {
    init { System.loadLibrary("hmc_ffi") }

    private external fun analyze(path: String): String
    private external fun convert(job: Int, path: String, outDir: String, optionsJson: String): String
    private external fun progress(job: Int): String
    private external fun cancel(job: Int)
    private external fun deps(pathsJson: String): String
    private external fun selftest(): String
    private external fun projects(root: String): String
    private external fun deleteProject(dir: String): String

    fun analyzeJar(path: String) = JSONObject(analyze(path))
    fun convertJar(job: Int, path: String, outDir: String, options: JSONObject = JSONObject()) =
        JSONObject(convert(job, path, outDir, if (options.length() == 0) "" else options.toString()))
    fun jobProgress(job: Int) = JSONObject(progress(job))
    fun cancelJob(job: Int) = cancel(job)
    fun dependencyReport(paths: List<String>) = JSONObject(deps(org.json.JSONArray(paths).toString()))
    fun runSelfTest() = JSONObject(selftest())
    fun listProjects(root: String) = JSONObject(projects(root))
    fun removeProject(dir: String) = JSONObject(deleteProject(dir))
}
