package com.horizon.modconverter

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Runs one conversion off the main thread, as a foreground-capable job with cancellation. */
class ConversionWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    private val jobId = inputData.getInt("job", 0)

    override suspend fun doWork(): Result = withContext(Dispatchers.Default) {
        val path = inputData.getString("path") ?: return@withContext Result.failure()
        val out = inputData.getString("out") ?: return@withContext Result.failure()
        coroutineContext[kotlinx.coroutines.Job]?.invokeOnCompletion { e ->
            if (e is kotlinx.coroutines.CancellationException) NativeBridge.cancelJob(jobId)
        }
        try { setForeground(info("Converting ${inputData.getString("name") ?: "mod"}")) } catch (_: Exception) { /* notification may be denied */ }
        val poller = CoroutineScope(Dispatchers.Default).launch {
            while (isActive) {
                val p = NativeBridge.jobProgress(jobId)
                if (p.optBoolean("running")) {
                    setProgress(workDataOf("stage" to p.optString("stage"), "done" to p.optLong("done"), "total" to p.optLong("total")))
                }
                delay(250)
            }
        }
        try {
            val r = NativeBridge.convertJar(jobId, path, out, org.json.JSONObject(inputData.getString("options") ?: "{}"))
            if (r.optBoolean("ok")) Result.success(workDataOf("verdict" to r.optString("verdict"), "project" to r.optString("project_dir")))
            else Result.failure(workDataOf("error" to r.optString("error")))
        } finally {
            poller.cancel()
            java.io.File(path).delete() // temp import copy
        }
    }

    override suspend fun getForegroundInfo() = info("Converting mod")

    private fun info(text: String): ForegroundInfo {
        val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("convert", "Conversions", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(applicationContext, "convert")
            .setContentTitle("Horizon Mod Converter").setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download).setOngoing(true).build()
        return if (Build.VERSION.SDK_INT >= 29) ForegroundInfo(jobId + 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else ForegroundInfo(jobId + 1, n)
    }

}
