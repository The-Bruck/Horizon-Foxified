package com.horizon.modconverter

import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.json.JSONObject

@Composable
fun Card2(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) { Column(Modifier.padding(14.dp), content = content) }
}

@Composable
fun hasNoNetworkPermission(): Boolean {
    val ctx = LocalContext.current
    val info = ctx.packageManager.getPackageInfo(ctx.packageName, PackageManager.GET_PERMISSIONS)
    return info.requestedPermissions?.contains("android.permission.INTERNET") != true
}

@Composable
fun ImportButton(vm: MainViewModel) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.importUris(it) }
    Button(onClick = { picker.launch(arrayOf("application/java-archive", "application/zip", "application/octet-stream")) }, modifier = Modifier.padding(12.dp)) {
        Text("IMPORT MOD")
    }
}

@Composable
fun DashboardScreen(vm: MainViewModel, m: Modifier, go: (Screen) -> Unit) {
    val offline = hasNoNetworkPermission()
    val done = vm.projects.size
    val failed = vm.jobs.values.count { it.state == "FAILED" }
    LazyColumn(m) {
        item {
            Card2 {
                Text("Horizon Mod Converter (HMC)", style = MaterialTheme.typography.titleLarge)
                Text(if (offline) "OFFLINE: this app holds no network permission and cannot send your files anywhere." else "Network permission present (unexpected for this build).")
                Text("Default source: NeoForge Minecraft 1.21.1")
                Text("Default target: Horizon 26.3 (content mods, API 0.2)")
            }
            ImportButton(vm)
            Card2 {
                Text("Completed conversions: $done   Failed this session: $failed   Saved projects: $done")
            }
            Card2 {
                Text("Conversion components", style = MaterialTheme.typography.titleMedium)
                val st = vm.selfTest.value
                if (st == null) Text("checking...") else {
                    val c = st.getJSONArray("checks")
                    for (i in 0 until c.length()) { val o = c.getJSONObject(i); Text((if (o.getBoolean("ok")) "OK   " else "FAIL ") + o.getString("name") + " " + o.optString("note")) }
                }
            }
            Card2 { Text("Recent conversions", style = MaterialTheme.typography.titleMedium) }
        }
        items(vm.projects.take(5)) { p -> Card2 { Text(p.name + " (" + p.modId + ")"); Text(p.verdict, style = MaterialTheme.typography.bodySmall) } }
    }
}

@Composable
fun ConvertScreen(vm: MainViewModel, m: Modifier, batch: Boolean) {
    LazyColumn(m) {
        item {
            ImportButton(vm)
            if (batch) {
                vm.dependencyReport.value?.let { r ->
                    Card2 {
                        Text("Dependency report", style = MaterialTheme.typography.titleMedium)
                        Text(r.optJSONObject("report")?.toString(2) ?: "")
                    }
                }
                Text("Workers: ${vm.workers} (change in Settings). Jobs run at most ${vm.workers} at a time.", Modifier.padding(horizontal = 12.dp))
            }
        }
        items(vm.imports.toList()) { it0 ->
            Card2 {
                Text(it0.name, style = MaterialTheme.typography.titleMedium)
                val a = it0.analysis
                if (a == null) Text("Cannot import: ${it0.error}") else {
                    val meta = a.getJSONObject("meta"); val ver = a.getJSONObject("version")
                    Text("Mod: ${meta.optString("display_name")} (${meta.optString("mod_id")}) ${meta.optString("version")}")
                    Text("Loader: ${meta.optString("loader")}   Minecraft: ${ver.optString("minecraft", "?")}   NeoForge: ${ver.optString("neoforge", "?")}")
                    Text("Target: Horizon 26.3   Source supported: ${ver.optBoolean("supported")}")
                    val conf = ver.optJSONArray("conflicts"); if (conf != null && conf.length() > 0) Text("Version conflicts: $conf")
                    Text("Features: " + a.getJSONObject("census").toString())
                    val deps = meta.optJSONArray("dependencies")
                    if (deps != null) for (i in 0 until deps.length()) { val d = deps.getJSONObject(i); Text("dependency ${d.optString("mod_id")} (${d.optString("kind")})") }
                }
                val j = vm.jobs[it0.id]
                if (j != null) {
                    Text("${j.state} ${j.stage} ${j.message}")
                    if (j.total > 0) LinearProgressIndicator(progress = { (j.done.toFloat() / j.total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                }
                Row {
                    if (a != null && (j == null || j.state in listOf("SUCCEEDED", "FAILED", "CANCELLED"))) {
                        Button(onClick = { vm.convert(listOf(it0)) }) { Text(if (j == null) "Convert" else "Retry") }
                        Spacer(Modifier.width(8.dp))
                    }
                    if (j != null && j.state in listOf("RUNNING", "ENQUEUED", "QUEUED", "BLOCKED")) {
                        OutlinedButton(onClick = { vm.cancel(it0.id) }) { Text("Cancel") }
                        Spacer(Modifier.width(8.dp))
                    }
                    TextButton(onClick = { vm.remove(it0) }) { Text("Remove") }
                }
            }
        }
        if (batch) item {
            Button(onClick = { vm.convert(vm.imports.toList()) }, modifier = Modifier.padding(12.dp), enabled = vm.imports.any { it.analysis != null }) { Text("Convert all") }
        }
    }
}

@Composable
fun AnalyzerScreen(vm: MainViewModel, m: Modifier) {
    LazyColumn(m) {
        item { ImportButton(vm) }
        items(vm.imports.toList()) { i ->
            Card2 {
                Text(i.name, style = MaterialTheme.typography.titleMedium)
                val a = i.analysis
                if (a == null) Text(i.error ?: "") else {
                    val code = a.getJSONObject("code")
                    Text("Classes: ${code.optInt("total_classes")}   Minecraft refs: ${code.optInt("minecraft_refs")}   NeoForge refs: ${code.optInt("neoforge_refs")}")
                    Text("Event handlers: ${a.getJSONArray("handler_mappings").length()}   Mixins: ${code.getJSONArray("mixin_classes").length()}")
                    Text("Networking classes: ${code.getJSONArray("networking_classes").length()}   Config: ${code.getJSONArray("config_classes").length()}")
                    val hm = a.getJSONArray("handler_mappings")
                    for (k in 0 until hm.length()) {
                        val h = hm.getJSONObject(k); val ev = h.getJSONObject("event")
                        Text("${h.getString("class").substringAfterLast('/')}.${h.getString("method")} -> " + (if (ev.isNull("hook")) "no catalog hook" else ev.getString("hook")))
                    }
                    val to = a.getJSONObject("timings_ms"); Text("Timings (ms): $to")
                    val rej = a.getJSONArray("rejected_entries"); if (rej.length() > 0) Text("Rejected archive entries: $rej")
                }
            }
        }
    }
}

@Composable
fun ProjectsScreen(vm: MainViewModel, m: Modifier, history: Boolean, openEditor: (ProjectUi) -> Unit) {
    var report by remember { mutableStateOf<Pair<ProjectUi, String>?>(null) }
    var exporting by remember { mutableStateOf<ProjectUi?>(null) }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val p = exporting; if (uri != null && p != null) vm.exportTo(p, uri)
    }
    val r = report
    if (r != null) {
        Column(m.verticalScroll(rememberScrollState()).padding(12.dp)) {
            TextButton(onClick = { report = null }) { Text("Back") }
            Text(r.second)
        }
        return
    }
    LazyColumn(m) {
        items(vm.projects.toList()) { p ->
            Card2 {
                Text("${p.name} (${p.modId})", style = MaterialTheme.typography.titleMedium)
                Text(p.verdict)
                Row {
                    TextButton(onClick = { report = p to vm.readReport(p) }) { Text("View report") }
                    if (!history) TextButton(onClick = { openEditor(p) }) { Text("View code") }
                    TextButton(onClick = { exporting = p; saver.launch(p.hmod) }) { Text("Export mod") }
                    TextButton(onClick = { vm.deleteProject(p) }) { Text("Delete") }
                }
            }
        }
        if (vm.projects.isEmpty()) item { Card2 { Text("No conversions yet.") } }
    }
}

@Composable
fun CompatibilityScreen(vm: MainViewModel, m: Modifier) {
    Column(m.verticalScroll(rememberScrollState())) {
        Card2 {
            Text("What converts (Horizon 26.3 content mods)", style = MaterialTheme.typography.titleMedium)
            Text("Converted: textures, models, blockstates, sounds, lang, tags, loot tables, recipes (rewritten to 26.3 shape), generated block/item declarations, creative tab, item definitions.")
            Text("Partial: block/item numbers and behaviour come from vanilla templates, not from the Java code. Worldgen is opt-in and unvalidated.")
            Text("Manual: event handlers, block entities, menus/screens, config, mob effects (Horizon native mods; built on a PC).")
            Text("Unsupported: Mixins, custom entities and renderers, networking, capabilities, custom recipe types, embedded jars.")
            Text("An .hnmod cannot be built on this device: Horizon builds native mods with its PC launcher.")
        }
        Card2 {
            Text("Validation", style = MaterialTheme.typography.titleMedium)
            Text("Packages are checked by HMC against Horizon's documented rules. HMC's own check is not Horizon's loader: run `cargo horizon-mod check` before publishing.")
        }
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel, m: Modifier) {
    var workers by remember { mutableStateOf(vm.workers) }
    var wg by remember { mutableStateOf(vm.carryWorldgen) }
    var tab by remember { mutableStateOf(vm.creativeTab) }
    var ov by remember { mutableStateOf(vm.overrideSource) }
    Column(m.verticalScroll(rememberScrollState())) {
        Card2 {
            Text("Concurrent conversions: $workers")
            Slider(value = workers.toFloat(), onValueChange = { workers = it.toInt().coerceIn(1, 4); vm.workers = workers }, valueRange = 1f..4f, steps = 2)
            Text("Lower this on devices with little memory.", style = MaterialTheme.typography.bodySmall)
        }
        Card2 {
            Row { Switch(checked = wg, onCheckedChange = { wg = it; vm.carryWorldgen = it }); Spacer(Modifier.width(8.dp)); Text("Carry worldgen data (unvalidated)") }
            Row { Switch(checked = tab, onCheckedChange = { tab = it; vm.creativeTab = it }); Spacer(Modifier.width(8.dp)); Text("Generate creative tab") }
            Row { Switch(checked = ov, onCheckedChange = { ov = it; vm.overrideSource = it }); Spacer(Modifier.width(8.dp)); Text("Convert unsupported/ambiguous source versions anyway") }
        }
    }
}

@Composable
fun AboutScreen(m: Modifier) {
    Column(m.verticalScroll(rememberScrollState())) {
        Card2 {
            Text("Horizon Mod Converter 0.1.0", style = MaterialTheme.typography.titleMedium)
            Text("Offline NeoForge 1.21.1 to Horizon 26.3 content-mod converter. Imported jars are treated as untrusted, analysed statically and never executed or uploaded.")
            Text("Not affiliated with Mojang, Microsoft or the Horizon project.")
        }
    }
}
