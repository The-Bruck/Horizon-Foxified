package com.horizon.modconverter

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

private val KEYWORDS = Regex("\\b(fn|pub|mod|use|let|mut|const|struct|enum|impl|trait|match|if|else|for|while|loop|return|todo|crate|self|as|in)\\b")
private val COMMENT = Regex("//[^\\n]*")
private val STRING = Regex("\"(\\\\.|[^\"\\\\])*\"")

/** Minimal Rust highlighting: comments, strings, keywords. */
class RustHighlight : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val s = text.text
        val a = buildAnnotatedString {
            append(s)
            KEYWORDS.findAll(s).forEach { addStyle(SpanStyle(color = Color(0xFFCC7832)), it.range.first, it.range.last + 1) }
            STRING.findAll(s).forEach { addStyle(SpanStyle(color = Color(0xFF6A8759)), it.range.first, it.range.last + 1) }
            COMMENT.findAll(s).forEach { addStyle(SpanStyle(color = Color(0xFF808080)), it.range.first, it.range.last + 1) }
        }
        return TransformedText(a, OffsetMapping.Identity)
    }
}

@Composable
fun EditorScreen(vm: MainViewModel, project: ProjectUi?, m: Modifier) {
    if (project == null) { Card2 { Text("Open a project from Projects, then choose View code.") }; return }
    val root = File(project.dir, "native-port")
    val files = remember(project) { root.walkTopDown().filter { it.isFile && (it.extension == "rs" || it.extension == "toml" || it.extension == "md") }.sortedBy { it.path }.toList() }
    if (files.isEmpty()) { Card2 { Text("This conversion generated no Rust scaffold (nothing required manual porting).") }; return }
    var current by remember(project) { mutableStateOf(files.first()) }
    var text by remember(current) {
        // First open keeps a pristine copy so "Restore original" works.
        val orig = File(current.path + ".orig"); if (!orig.exists()) current.copyTo(orig)
        mutableStateOf(current.readText())
    }
    var query by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    Column(m.fillMaxSize()) {
        LazyColumn(Modifier.heightIn(max = 140.dp)) {
            items(files) { f -> TextButton(onClick = { current = f }) { Text(f.relativeTo(root).path + if (f == current) "  (open)" else "") } }
        }
        OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Search in file") }, modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp))
        if (query.isNotEmpty()) Text("${Regex(Regex.escape(query)).findAll(text).count()} match(es)", Modifier.padding(horizontal = 12.dp))
        Row {
            Button(onClick = { current.writeText(text); status = "Saved" }, modifier = Modifier.padding(8.dp)) { Text("Save") }
            OutlinedButton(onClick = { text = File(current.path + ".orig").readText(); current.writeText(text); status = "Restored generated original" }, modifier = Modifier.padding(8.dp)) { Text("Restore original") }
            Text(status, Modifier.padding(8.dp))
        }
        Box(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(8.dp)) {
            BasicTextField(value = text, onValueChange = { text = it }, visualTransformation = RustHighlight(),
                textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = Color(0xFFE0E0E0)),
                cursorBrush = SolidColor(Color.White), modifier = Modifier.fillMaxWidth())
        }
    }
}
