#!/usr/bin/env python3
"""Builds ruby-1.0.0.jar: a synthetic NeoForge 1.21.1 mod with REAL compiled class files
(compiled against tiny stubs of the Minecraft/NeoForge API) and 1.21.1-format data."""
import json, os, shutil, struct, subprocess, sys, tempfile, zipfile, zlib

def png(w, h):
    def chunk(t, b):
        c = struct.pack(">I", len(b)) + t + b
        return c + struct.pack(">I", zlib.crc32(t + b) & 0xFFFFFFFF)
    raw = b"".join(b"\x00" + b"\xff\x00\x00\xff" * w for _ in range(h))
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b"")

STUBS = {
 "net/minecraft/world/level/block/Block.java": "package net.minecraft.world.level.block; public class Block { public Block(){} }",
 "net/minecraft/world/level/block/entity/BlockEntity.java": "package net.minecraft.world.level.block.entity; public class BlockEntity { }",
 "net/minecraft/world/entity/Entity.java": "package net.minecraft.world.entity; public class Entity { }",
 "net/minecraft/world/item/Item.java": "package net.minecraft.world.item; public class Item { public Item(){} }",
 "net/neoforged/bus/api/SubscribeEvent.java": "package net.neoforged.bus.api; import java.lang.annotation.*; @Retention(RetentionPolicy.RUNTIME) public @interface SubscribeEvent {}",
 "net/neoforged/fml/common/Mod.java": "package net.neoforged.fml.common; import java.lang.annotation.*; @Retention(RetentionPolicy.RUNTIME) public @interface Mod { String value(); }",
 "net/neoforged/neoforge/event/server/ServerStoppingEvent.java": "package net.neoforged.neoforge.event.server; public class ServerStoppingEvent {}",
 "net/neoforged/neoforge/event/FooEvent.java": "package net.neoforged.neoforge.event; public class FooEvent {}",
 "net/neoforged/neoforge/network/PayloadRegistrar.java": "package net.neoforged.neoforge.network; public class PayloadRegistrar {}",
 "org/spongepowered/asm/mixin/Mixin.java": "package org.spongepowered.asm.mixin; import java.lang.annotation.*; @Retention(RetentionPolicy.RUNTIME) public @interface Mixin { Class<?>[] value(); }",
}
MOD = {
 "com/example/ruby/RubyMod.java": 'package com.example.ruby; import net.neoforged.fml.common.Mod; @Mod("ruby") public class RubyMod { static final String A = "ruby_block"; static final String B = "ruby"; }',
 "com/example/ruby/RubyEvents.java": 'package com.example.ruby; import net.neoforged.bus.api.SubscribeEvent; import net.neoforged.neoforge.event.server.ServerStoppingEvent; import net.neoforged.neoforge.event.FooEvent; public class RubyEvents { @SubscribeEvent public void onStop(ServerStoppingEvent e){} @SubscribeEvent public static void onFoo(FooEvent e){} }',
 "com/example/ruby/MachineBlock.java": "package com.example.ruby; import net.minecraft.world.level.block.Block; public class MachineBlock extends Block { public void use(){ System.out.println(1); } }",
 "com/example/ruby/PlainBlock.java": "package com.example.ruby; import net.minecraft.world.level.block.Block; public class PlainBlock extends Block { public PlainBlock(){ super(); } }",
 "com/example/ruby/MachineEntity.java": "package com.example.ruby; import net.minecraft.world.level.block.entity.BlockEntity; public class MachineEntity extends BlockEntity { }",
 "com/example/ruby/Golem.java": "package com.example.ruby; import net.minecraft.world.entity.Entity; public class Golem extends Entity { }",
 "com/example/ruby/Net.java": "package com.example.ruby; import net.neoforged.neoforge.network.PayloadRegistrar; public class Net { PayloadRegistrar r; }",
 "com/example/ruby/MixinThing.java": "package com.example.ruby; import org.spongepowered.asm.mixin.Mixin; import net.minecraft.world.level.block.Block; @Mixin(Block.class) public class MixinThing { }",
}

def j(o): return json.dumps(o, indent=1)
RES = {
 "META-INF/neoforge.mods.toml": '''modLoader="javafml"
loaderVersion="[4,)"
license="MIT"
[[mods]]
modId="ruby"
version="1.0.0"
displayName="Ruby Mod"
description="Adds rubies."
authors="Ann, Bob"
[[mixins]]
config="ruby.mixins.json"
[[dependencies.ruby]]
modId="neoforge"
type="required"
versionRange="[21.1.0,)"
[[dependencies.ruby]]
modId="minecraft"
type="required"
versionRange="[1.21.1]"
[[dependencies.ruby]]
modId="geolib"
type="required"
versionRange="[1,)"
''',
 "pack.mcmeta": j({"pack": {"pack_format": 34, "description": "ruby"}}),
 "LICENSE": "MIT License\n",
 "assets/ruby/blockstates/ruby_block.json": j({"variants": {"": {"model": "ruby:block/ruby_block"}}}),
 "assets/ruby/blockstates/machine.json": j({"variants": {"lit=false": {"model": "ruby:block/machine"}, "lit=true": {"model": "ruby:block/machine"}}}),
 "assets/ruby/blockstates/ruby_door.json": j({"variants": {"facing=east,half=lower,hinge=left,open=false,powered=false": {"model": "ruby:block/ruby_door"}, "facing=north,half=upper,hinge=right,open=true,powered=true": {"model": "ruby:block/ruby_door"}}}),
 "assets/ruby/models/block/ruby_block.json": j({"parent": "minecraft:block/cube_all", "textures": {"all": "ruby:block/ruby_block"}}),
 "assets/ruby/models/block/machine.json": j({"parent": "minecraft:block/cube_all", "textures": {"all": "ruby:block/ruby_block"}}),
 "assets/ruby/models/block/ruby_door.json": j({"parent": "minecraft:block/cube_all", "textures": {"all": "ruby:block/ruby_block"}}),
 "assets/ruby/models/item/ruby.json": j({"parent": "minecraft:item/generated", "textures": {"layer0": "ruby:item/ruby"}}),
 "assets/ruby/models/item/ruby_block.json": j({"parent": "ruby:block/ruby_block"}),
 "assets/ruby/models/item/machine.json": j({"parent": "ruby:block/machine"}),
 "assets/ruby/lang/en_us.json": j({"block.ruby.ruby_block": "Ruby Block", "item.ruby.ruby": "Ruby"}),
 "assets/ruby/sounds.json": j({}),
 "assets/ruby/shaders/x.fsh": "void main(){}",
 "data/ruby/recipe/ruby_block.json": j({"type": "minecraft:crafting_shaped", "category": "building", "key": {"R": {"item": "ruby:ruby"}}, "pattern": ["RRR", "RRR", "RRR"], "result": {"count": 1, "id": "ruby:ruby_block"}}),
 "data/ruby/recipe/ruby_from_block.json": j({"type": "minecraft:crafting_shapeless", "ingredients": [{"item": "ruby:ruby_block"}], "result": {"count": 9, "id": "ruby:ruby"}}),
 "data/ruby/recipe/smelt.json": j({"type": "minecraft:smelting", "ingredient": {"tag": "c:ores/ruby"}, "result": {"id": "ruby:ruby"}, "experience": 1.0, "cookingtime": 200}),
 "data/ruby/recipe/machine_recipe.json": j({"type": "ruby:machine", "input": "ruby:ruby"}),
 "data/ruby/recipe/conditional.json": j({"neoforge:conditions": [{"type": "neoforge:mod_loaded", "modid": "jei"}], "type": "minecraft:smelting", "ingredient": {"item": "a:b"}, "result": {"id": "a:c"}}),
 "data/ruby/loot_table/blocks/ruby_block.json": j({"type": "minecraft:block", "pools": [{"rolls": 1, "entries": [{"type": "minecraft:item", "name": "ruby:ruby_block"}]}]}),
 "data/minecraft/tags/block/mineable/pickaxe.json": j({"values": ["ruby:ruby_block"]}),
 "data/c/tags/item/gems/ruby.json": j({"values": ["ruby:ruby"]}),
 "data/ruby/worldgen/configured_feature/ore.json": j({"type": "minecraft:ore", "config": {"targets": [{"state": {"Name": "ruby:ruby_block"}}]}}),
 "data/neoforge/loot_modifiers/global_loot_modifiers.json": j({"entries": []}),
 "data/minecraft/recipe/override.json": j({"type": "minecraft:crafting_shapeless", "ingredients": [], "result": {"id": "a:b"}}),
}
BIN = {
 "assets/ruby/textures/item/ruby.png": png(16, 16),
 "assets/ruby/textures/block/ruby_block.png": png(16, 16),
 "assets/ruby/textures/block/BadName.png": png(16, 16),
 "assets/ruby/textures/block/corrupt.png": png(16, 16)[:-9] + b"xxxxxxxxx",
}

def main(out):
    tmp = tempfile.mkdtemp()
    src, cls = os.path.join(tmp, "src"), os.path.join(tmp, "cls")
    os.makedirs(cls)
    files = []
    for d in (STUBS, MOD):
        for p, t in d.items():
            fp = os.path.join(src, p); os.makedirs(os.path.dirname(fp), exist_ok=True)
            open(fp, "w").write(t); files.append(fp)
    subprocess.check_call(["javac", "--release", "21", "-d", cls] + files)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        zi = lambda n: zipfile.ZipInfo(n, (2020, 1, 1, 0, 0, 0))
        for root, _, fs in os.walk(os.path.join(cls, "com")):
            for f in sorted(fs):
                full = os.path.join(root, f)
                z.writestr(zi(os.path.relpath(full, cls)), open(full, "rb").read(), zipfile.ZIP_DEFLATED)
        for n, t in {**RES, **BIN}.items():
            z.writestr(zi(n), t if isinstance(t, bytes) else t.encode(), zipfile.ZIP_DEFLATED)
        # hostile entries
        z.writestr(zi("../evil.txt"), b"x")
    shutil.rmtree(tmp)

main(sys.argv[1] if len(sys.argv) > 1 else "ruby-1.0.0.jar")
