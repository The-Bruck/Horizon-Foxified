rootProject.name = "hmc-bootstrap"
