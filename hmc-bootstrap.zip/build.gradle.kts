// Unzips HorizonModConverter-source.zip (next to this file) and builds the APKs from it.
// Usage:  ./gradlew buildApp      -> APKs land in ./out/
// Needs: JDK 17+, Rust (cargo), `cargo install cargo-ndk`, `rustup target add aarch64-linux-android`,
//        Android SDK + NDK with ANDROID_HOME and ANDROID_NDK_HOME set. Linux/macOS (uses `sh`).

val sourceZip = layout.projectDirectory.file("HorizonModConverter-source.zip")
val srcDir = layout.buildDirectory.dir("src")

fun hasCmd(vararg cmd: String) = try {
    ProcessBuilder(*cmd).redirectErrorStream(true).start().also { it.inputStream.readBytes() }.waitFor() == 0
} catch (e: Exception) { false }

val checkTools = tasks.register("checkTools") {
    doLast {
        val problems = mutableListOf<String>()
        if (!sourceZip.asFile.exists()) problems += "HorizonModConverter-source.zip not found next to build.gradle.kts"
        if (!hasCmd("cargo", "--version")) problems += "cargo not found (install Rust: https://rustup.rs)"
        if (!hasCmd("cargo", "ndk", "--version")) problems += "cargo-ndk missing: cargo install cargo-ndk"
        if (System.getenv("ANDROID_HOME").isNullOrEmpty() && System.getenv("ANDROID_SDK_ROOT").isNullOrEmpty())
            problems += "ANDROID_HOME is not set"
        if (System.getenv("ANDROID_NDK_HOME").isNullOrEmpty()) problems += "ANDROID_NDK_HOME is not set"
        if (problems.isNotEmpty()) throw GradleException("Missing prerequisites:\n - " + problems.joinToString("\n - "))
    }
}

val unzipSource = tasks.register<Copy>("unzipSource") {
    dependsOn(checkTools)
    from(zipTree(sourceZip))
    into(srcDir)
}

val rustTests = tasks.register<Exec>("rustTests") {
    dependsOn(unzipSource)
    workingDir = srcDir.get().dir("rust-core").asFile
    commandLine("cargo", "test", "--workspace")
}

val buildApk = tasks.register<Exec>("buildApk") {
    dependsOn(rustTests)
    workingDir = srcDir.get().dir("android").asFile
    commandLine("sh", "gradlew", "assembleDebug", "assembleRelease")
}

tasks.register<Copy>("buildApp") {
    group = "build"
    description = "Unzip the source, test the Rust engine, build debug+release APKs into ./out"
    dependsOn(buildApk)
    from(srcDir.map { it.dir("android/app/build/outputs/apk/debug/app-debug.apk") }) { rename { "HorizonModConverter-debug.apk" } }
    from(srcDir.map { it.dir("android/app/build/outputs/apk/release/app-release.apk") }) { rename { "HorizonModConverter.apk" } }
    into(layout.projectDirectory.dir("out"))
}
