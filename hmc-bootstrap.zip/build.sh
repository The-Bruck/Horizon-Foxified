#!/bin/sh
# Same thing without Gradle-in-Gradle: unzip, test, build.
set -e
cd "$(dirname "$0")"
rm -rf build/src && mkdir -p build/src out
unzip -q HorizonModConverter-source.zip -d build/src
(cd build/src/rust-core && cargo test --workspace)
(cd build/src/android && sh gradlew assembleDebug assembleRelease)
cp build/src/android/app/build/outputs/apk/debug/app-debug.apk out/HorizonModConverter-debug.apk
cp build/src/android/app/build/outputs/apk/release/app-release.apk out/HorizonModConverter.apk
echo "APKs in $(pwd)/out"
