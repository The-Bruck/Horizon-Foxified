1. Install: JDK 17, Rust, `cargo install cargo-ndk`, `rustup target add aarch64-linux-android`,
   Android SDK + NDK (set ANDROID_HOME and ANDROID_NDK_HOME).
2. Keep HorizonModConverter-source.zip in this folder.
3. Run:  ./gradlew buildApp     (or ./build.sh)
4. APKs appear in ./out/
